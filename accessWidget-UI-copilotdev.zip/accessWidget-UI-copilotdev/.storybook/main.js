const TsconfigPathsPlugin = require("tsconfig-paths-webpack-plugin");

export default {
  stories: [
    "../src/**/*.mdx",
    "../src/**/*.stories.@(js|jsx|mjs|ts|tsx)",
  ],
  addons: [
    
    "@storybook/addon-links",
    "@storybook/addon-essentials",
    "@storybook/addon-interactions",
    "@storybook/preset-scss",
    "storybook-addon-fetch-mock",
    "@chromatic-com/storybook",
    "@storybook/addon-webpack5-compiler-babel"

  ],
  framework: "@storybook/preact-webpack5",
  babel: async (options) => ({
    ...options,
    presets: [
     "preact",
      ["@babel/typescript", { jsxPragma: "h" }]
    ],
  }),
  webpackFinal: async (config) => {
    config.resolve.plugins = [
      ...(config.resolve.plugins || []),
      new TsconfigPathsPlugin({
        extensions: config.resolve.extensions,
      }),
    ];

    const ruleIndex = config.module.rules.findIndex((rule) => rule.test.test(".scss"));
    
    config.module.rules[ruleIndex].use = ["raw-loader", "sass-loader"];

    config.module.rules = config.module.rules.filter((rule) => !rule.test?.test(".css"));

    const svgLoaderRule = config.module.rules.find((rule) => rule.test.test("file.svg"));

    if (svgLoaderRule) {
      svgLoaderRule.exclude = /\.svg$/;
    }

    config.module.rules.push({
      test: /\.svg$/,
      use: ["raw-loader"],
    });
    return config;
  },
};
