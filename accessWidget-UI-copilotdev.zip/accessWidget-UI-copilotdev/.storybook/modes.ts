export const allModes = {
  sm: {
    viewport: "sm",
  },
  lg: {
    viewport: "lg",
  },
};
