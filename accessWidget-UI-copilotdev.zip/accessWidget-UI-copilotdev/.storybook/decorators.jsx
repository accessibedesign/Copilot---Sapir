import { Fragment, h, render } from "preact";
import globalCss from "~/styles/global.scss";
import AccessWidgetUiModule from "~/index.module";
import { useStylesheet, ShadowRootStateProvider } from "~/hooks/useStylesheet";

export const globalStyles = (Story) => {
  const appRoot = document.querySelector("#app-root");
  return (
    <ShadowRootStateProvider shadowRoot={appRoot.shadowRoot}>
      <WithGlobalStyles>
        <Story />
      </WithGlobalStyles>
    </ShadowRootStateProvider>
  );
};
const WithGlobalStyles = ({ children }) => {
  useStylesheet(globalCss);
  return <Fragment>{children}</Fragment>;
};

export const addShadow = (Story) => {
  const container = document.querySelector("#storybook-root");

  /** since the story is wrapped in a shadow, storybook can't do a correct snapshot since it cant calculate the height of the component */
  container.style.height = "100vh";

  const appRoot = document.createElement(`div`);
  appRoot.id = "app-root";

  /** on each arg change we want to remove the shadow dom entirely, this fixes an issue when on each arg change, the previous rendered story appears */
  container.innerHTML = "";

  appRoot.attachShadow({ mode: "open" });

  container.appendChild(appRoot);
  return render(<Story />, appRoot.shadowRoot);
};

/**
 * adds an option to change language on all stories and also fixes issue where translation texts disappears when switching between stories
 * if the story does not have a language arg it will return the story without adding dictionary
 */
export const addLanguageSelection = (story, { args, parameters, argTypes }) => {
  if (!argTypes.language) {
    return story();
  }
  const language = args.language || "en"; // default language is "en" which is American English (US)

  const folder = parameters.fileName.match(/(?<=\/components\/)(.*)(?=\/index\.stories\.tsx)/gm)?.[0];

  const data = require(`../src/components/${folder}/locale/${language}.json`);

  AccessWidgetUiModule.setDictionary(data, language);
  return story();
};

/**
 * global decorator that adds styles "on top" of our shadow component,
 * simulating when parent site causes UI changes in our widget.
 * this is used for testing purposes to see that UI is the same regardless of parent website style changes.
 * the source of inheritable properties is from:
 * @see https://web.dev/learn/css/inheritance/
 */
export const outsideStyles = (Story) => {
  return (
    <div>
      <style>
        {`body *,
          body {
            font-weight: bold !important;
            font-size: 24px !important;
            line-height: 50px !important;
            color: red !important;
            border-collapse: collapse !important;
            border-spacing: 30px !important;
            caption-side: bottom !important;
            cursor: crosshair !important;
            direction: revert !important;
            empty-cells: hide !important;
            font-family: system-ui !important;
            font-style: italic !important;
            font-variant: common-ligatures tabular-nums !important;
            font: small-caps bold 24px/1 sans-serif !important;
            letter-spacing: .2rem !important;
            list-style-image: linear-gradient(to left bottom, red, blue) !important;
            list-style-position: outside !important;
            list-style: georgian inside !important;
            list-style-type: circle !important;
            orphans: 3 !important;
            quotes: "„" "“" "‚" "‘" !important;
            text-align: center !important;
            text-indent: 30% !important;
            text-transform: uppercase !important;
            visibility: collapse !important;
            white-space: pre-wrap !important;
            widows: 3 !important;
            word-spacing: -.4ch !important;
        }
        `}
      </style>
      <Story />
    </div>
  );
};
