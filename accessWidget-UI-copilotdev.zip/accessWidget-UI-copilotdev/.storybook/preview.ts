import { SupportedLanguageCode } from "../src/types";
import { addShadow, globalStyles, addLanguageSelection, outsideStyles } from "./decorators";
import { INITIAL_VIEWPORTS } from "@storybook/addon-viewport";
import { allModes } from "./modes";

const parameters = {
  viewport: {
    /**
     * list of defined viewports
     * @see https://storybook.js.org/docs/essentials/viewport#use-a-detailed-set-of-devices
     */
    viewports: {
      sm: { name: "Small", styles: { width: "480px", height: "900px" } },
      lg: { name: "Large", styles: { width: "1024px", height: "900px" } },
    },
  },
  chromatic: {
    modes: {
      sm: allModes.sm,
      lg: allModes.lg,
    },
  },
  controls: {
    matchers: {
      color: /(background|color)$/i,
      date: /Date$/,
    },
  },
  //TODO: an empty fetchMock is added here since fetchMock library is searching for it on all stories. this is a patch that needs to be removed once the maintainers of the package resolve this.
  fetchMock: {},
};

/**
 * the order of the decorators here is important,
 * for example, outsideStyles needs to come after addShadow, and globalStyles (which are a part of widget-ui)
 * because we want to simulate host site's styles affect on our UI.
 */
const decorators = [globalStyles, addShadow, addLanguageSelection, outsideStyles];

export default {
  parameters,
  decorators,
};
