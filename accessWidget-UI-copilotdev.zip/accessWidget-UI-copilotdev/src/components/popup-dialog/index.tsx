import { h, VNode } from "preact";
import styles from "./style.scss";
import { useStylesheet } from "~/hooks/useStylesheet";
import BaseIcon from "~/components/base-icon";
import { BaseButton } from "~/components/base-button";
import { useLayoutEffect, useRef, useState } from "preact/hooks";
import { PopupDialogEventData, PopupDialogEventType } from "~/components/popup-dialog/types";
import Images from "./assets/index";
import Icon from "../base-icon";
import { useTranslation } from "~/hooks/useTranslation";
import defaultDictionary from "./locale/en.json";

export {PopupDialogEventData, PopupDialogEventType};

type PopupDialogHorizontalPosition = "left" | "right";
type PopupDialogVerticalPosition = "up" | "down";

export type PopupDialogProps = {
  refAnchorRect: DOMRect;
  onEvent: (event: PopupDialogEventData) => void;
  visible?: boolean;
  content: {
    text: string;
    icon: string;
  };
};

/**
 * Calculates the dialog position (x, y) relative to an anchor element
 * and determines whether the pointer should face up or down.
 *
 * @param {DOMRect} refAnchorRect - The bounding rectangle of the anchor element.
 * @param {number} totalPopupHeight - The total height of the popup dialog.
 * @param [dialogElementMargin=7] - The margin between the anchor and the dialog.
 * @returns {{y: number, pointerVerticalDirection: PopupDialogVerticalPosition}}
 * An object containing:
 * - `y`: The vertical coordinate of the dialog.
 * - `pointerVerticalDirection`: The direction in which the dialog pointer should face ("up" or "down").
 */
const getPopupDialogVerticalPositionData = (
  refAnchorRect: DOMRect,
  totalPopupHeight: number,
  dialogElementMargin = 7
): { y: number; pointerVerticalDirection: PopupDialogVerticalPosition } => {
  const { top: refAnchorTop, height: refAnchorHeight } = refAnchorRect;
  // if ref element is in the upper half of the screen, place the dialog below it pointing up
  if (refAnchorTop < window.innerHeight / 2) {
    return {
      y: refAnchorRect.y + refAnchorHeight + dialogElementMargin,
      pointerVerticalDirection: "up",
    };
  }
  // if ref element is in the lower half of the screen, place the dialog above it pointing down
  return {
    y: refAnchorRect.y - totalPopupHeight - dialogElementMargin,
    pointerVerticalDirection: "down",
  };
};

const getPopupDialogHorizontalPositionData = (
  refAnchorRect: DOMRect,
  totalPopupWidth: number,
): { x: number; pointerHorizontalDirection: PopupDialogHorizontalPosition } => {
  const { left: refAnchorLeft } = refAnchorRect;
  // if the button is in the right half of the screen, place the popup dialog to extend to the left
  if (refAnchorLeft > window.innerWidth / 2) {
    return { x: refAnchorLeft - totalPopupWidth / 2, pointerHorizontalDirection: "left" };
  }
  // if the button is in the left half of the screen, place the popup dialog to extend to the right
  return { x: refAnchorLeft, pointerHorizontalDirection: "right" };
};

const PopupDialog = ({ visible, refAnchorRect, content, onEvent }: PopupDialogProps): VNode => {
  useStylesheet(styles);
  const {t, direction} = useTranslation(defaultDictionary);
  const [left, setLeft] = useState(0);
  const [top, setTop] = useState(0);
  // in which direction the pointy part of the dialog should be placed (left/right)
  const [popupDialogHorizontalPosition, setPopupDialogHorizontalPosition] =
    useState<PopupDialogHorizontalPosition>("left");
  // in which direction the pointy part of the dialog should point (up/down)
  const [popupDialogVerticalPosition, setPopupDialogVerticalPosition] = useState<PopupDialogVerticalPosition>("up");
  const popupDialogRef = useRef<HTMLDivElement>(null);
  const closeIconRef = useRef<SVGSVGElement | HTMLImageElement>(null);

  useLayoutEffect(() => {
    if (!visible) return;
    const popupDialog = popupDialogRef.current;
    const closeIcon = closeIconRef.current;
    // Calculate total popup dialog width, including the close icon size
    const closeIconWidth = closeIcon.getBoundingClientRect().width;
    const totalPopupDialogWidth = popupDialog.offsetWidth + closeIconWidth;
    // include size of the pointer element to its total height (borderWidth is also its height) for better accuracy
    const pointerElementSize = parseFloat(window.getComputedStyle(popupDialog, "::after").borderWidth);
    const totalPopupDialogHeight = popupDialog.offsetHeight + pointerElementSize;

    const popupDialogVerticalPosition = getPopupDialogVerticalPositionData(refAnchorRect, totalPopupDialogHeight);
    const popupDialogHorizontalPosition = getPopupDialogHorizontalPositionData(refAnchorRect, totalPopupDialogWidth);
    setLeft(popupDialogHorizontalPosition.x);
    setTop(popupDialogVerticalPosition.y);

    setPopupDialogVerticalPosition(popupDialogVerticalPosition.pointerVerticalDirection);
    setPopupDialogHorizontalPosition(popupDialogHorizontalPosition.pointerHorizontalDirection);
  }, [refAnchorRect, visible]);

  return (
    <div
      {...{inert: !visible}}
      ref={popupDialogRef}
      role={"dialog"}
      data-testid={"popup-dialog"}
      aria-hidden={!visible}
      class={`popup-dialog ${visible ? "popup-dialog--visible" : ""} popup-dialog--${popupDialogHorizontalPosition} popup-dialog--${popupDialogVerticalPosition}`}
      style={{ top: `${top}px`, left: `${left}px` }}
    >
      <span class="popup-dialog__content" dir={direction}>
        <BaseIcon>{content.icon}</BaseIcon>
        {t(content.text)}
      </span>
      <BaseButton
        data-testid={"popup-dialog-close-button"}
        class={`popup-dialog__close popup-dialog__close--${popupDialogHorizontalPosition}`}
        onClick={() => onEvent({ type: PopupDialogEventType.Close })}
      >
        <Icon ref={closeIconRef}>{Images.close}</Icon>
      </BaseButton>
    </div>
  );
};

export { PopupDialog };
