/** @jsx h */
import { h } from "preact";
import { PopupDialog, PopupDialogProps } from "./index";
import { Meta, StoryFn } from "@storybook/preact";
import popupDialogConfig from "~/mock/popup-dialog-config";

import { SupportedLanguageCode } from "~/types";
import { text_simplifier_popup_dialog } from "~/external-assets/icons";

export default {
  title: "Example/PopupDialog",
  component: PopupDialog,
  args: popupDialogConfig.data,
  argTypes: {
    language: { control: "select", options: Object.values(SupportedLanguageCode) },
    onEvent: { action: "onEvent" },
  },
} as Meta<typeof PopupDialog>;

const Template: StoryFn<typeof PopupDialog> = (args) => <PopupDialog {...(args as any)} />;

export const TopLeft = Template.bind({});
TopLeft.args = {
  refAnchorRect: new DOMRect(0, 0, 40, 40),
  visible: true,
  content: {
    text: "simplifyText",
    icon: text_simplifier_popup_dialog,
  },
} as PopupDialogProps;

export const BottomLeft = Template.bind({});
BottomLeft.args = {
  refAnchorRect: new DOMRect(0, window.innerHeight, 40, 40),
  visible: true,
  content: {
    text: "simplifyText",
    icon: text_simplifier_popup_dialog,
  },
} as PopupDialogProps;

export const TopRight = Template.bind({});
TopRight.args = {
  refAnchorRect: new DOMRect(window.innerWidth - 100, 0, 40, 40),
  visible: true,
  content: {
    text: "simplifyText",
    icon: text_simplifier_popup_dialog,
  },
} as PopupDialogProps;

export const BottomRight = Template.bind({});
BottomRight.args = {
  refAnchorRect: new DOMRect(window.innerWidth - 100, window.innerHeight - 100, 40, 40),
  visible: true,
  content: {
    text: "simplifyText",
    icon: text_simplifier_popup_dialog,
  },
} as PopupDialogProps;

export const BottomRightRTL = Template.bind({});
BottomRightRTL.args = {
  refAnchorRect: new DOMRect(window.innerWidth - 100, window.innerHeight - 100, 40, 40),
  visible: true,
  content: {
    text: "simplifyText",
    icon: text_simplifier_popup_dialog,
  },
  language: SupportedLanguageCode.HE
};
