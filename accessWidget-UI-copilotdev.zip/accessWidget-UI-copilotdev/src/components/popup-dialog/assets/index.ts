import close from "./close.svg";

export default {
  close
};
