import { h } from "preact";
import { render } from "~/utils/test-utils";
import { PopupDialog, PopupDialogEventType } from "./index";
import { fireEvent } from "@testing-library/preact";
import { text_simplifier_popup_dialog } from "~/external-assets/icons";

describe("Tests `PopupDialog` component functionality", () => {
  it(`should not show if visible is set to false`, () => {
    const component = render(
      <PopupDialog
        visible={false}
        refAnchorRect={{x: 0, y: 0} as DOMRect}
        onEvent={jest.fn()}
        content={{
          text: "simplifyText",
          icon: text_simplifier_popup_dialog,
        }}
      />,
    );
    expect(component.getByTestId("popup-dialog")).not.toHaveClass("is-visible");
  });

  it(`should show the dialog on an element on the left side of the screen (expanding right)`, () => {
    const component = render(
      <PopupDialog
        visible={true}
        onEvent={jest.fn()}
        refAnchorRect={{x: 100, y: 100, left: 100, right: 100, height: 100, width: 100} as DOMRect}
        content={{
          text: "simplifyText",
          icon: text_simplifier_popup_dialog,
        }}
      />,
    );
    expect(component.getByTestId("popup-dialog")).toBeInTheDocument();
    // ref anchor rect is on the left side of the screen, so the dialog should open to the right
    expect(component.getByTestId("popup-dialog")).toHaveClass("popup-dialog--right");
  });

  it(`should show the dialog on an element on the right side of the screen (expanding left)`, () => {
    const component = render(
      <PopupDialog
        visible={true}
        onEvent={jest.fn()}
        refAnchorRect={{x: 0, y: 100, left: 1800, right: 0, height: 100, width: 100} as DOMRect}
        content={{
          text: "simplifyText",
          icon: text_simplifier_popup_dialog,
        }}
      />,
    );
    expect(component.getByTestId("popup-dialog")).toBeInTheDocument();
    // ref anchor rect is on the left side of the screen, so the dialog should open to the right
    expect(component.getByTestId("popup-dialog")).toHaveClass("popup-dialog--left");
  });

  it(`should show the dialog on an element on the upper side of the screen (pointing up, below the element)`, () => {
    const component = render(
      <PopupDialog
        visible={true}
        onEvent={jest.fn()}
        refAnchorRect={{x: 0, y: 100, left: 1800, top: 100, right: 0, height: 100, width: 100} as DOMRect}
        content={{
          text: "simplifyText",
          icon: text_simplifier_popup_dialog,
        }}
      />,
    );
    expect(component.getByTestId("popup-dialog")).toBeInTheDocument();
    // ref anchor rect is on the left side of the screen, so the dialog should open to the right
    expect(component.getByTestId("popup-dialog")).toHaveClass("popup-dialog--up");
  });

  it(`should show the dialog on an element on the lower side of the screen (pointing down, above the element)`, () => {
    const component = render(
      <PopupDialog
        visible={true}
        onEvent={jest.fn()}
        refAnchorRect={{x: 0, y: 100, left: 1800, top: 1200, right: 0, height: 100, width: 100} as DOMRect}
        content={{
          text: "simplifyText",
          icon: text_simplifier_popup_dialog,
        }}
      />,
    );
    expect(component.getByTestId("popup-dialog")).toBeInTheDocument();
    // ref anchor rect is on the left side of the screen, so the dialog should open to the right
    expect(component.getByTestId("popup-dialog")).toHaveClass("popup-dialog--down");
  });

  it(`should trigger close event when clicking on the close button`, () => {
    const onEvent = jest.fn();
    const component = render(
      <PopupDialog
        visible={true}
        onEvent={onEvent}
        refAnchorRect={{x: 0, y: 100, left: 1800, top: 1200, right: 0, height: 100, width: 100} as DOMRect}
        content={{
          text: "simplifyText",
          icon: text_simplifier_popup_dialog,
        }}
      />,
    );
    fireEvent.click(component.getByTestId("popup-dialog-close-button"));
    expect(onEvent).toHaveBeenCalledWith({ type: PopupDialogEventType.Close });
  });

});

