export enum PopupDialogEventType {
  Close = "Close",
}

export interface PopupDialogEventData  {
  type: PopupDialogEventType,
}
