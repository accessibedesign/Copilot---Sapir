/** @jsx h */
import { h } from "preact";
import readingMaskConfig from "~/mock/reading-mask-config";
import { Meta, StoryFn } from "@storybook/preact";
import { ReadingMask } from "./";
export default {
  title: "Example/ReadingMask",
  component: ReadingMask,
  args: { ...readingMaskConfig.data },
  argTypes: {},
} as Meta<typeof ReadingMask>;
const Template: StoryFn<typeof ReadingMask> = (args) => <ReadingMask {...(args as any)} />;

export const Default = Template.bind({});

export const Invisible = Template.bind({});
Invisible.args = {
  visible: false,
};
