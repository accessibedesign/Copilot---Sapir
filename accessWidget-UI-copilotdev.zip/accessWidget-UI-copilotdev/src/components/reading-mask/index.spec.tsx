import { h } from "preact";
import { render } from "~/utils/test-utils";
import { ReadingMask } from "./index";
import { waitFor } from "@testing-library/dom";
describe("Tests `ReadingMask` component functionality", () => {
  it(`should render the ReadingMask`, async () => {
    // testing position doesnt work because jsdom doesnt support pseudo elements
    const component = render(<ReadingMask visible={true} top="150px" />);
    const element = component.container.querySelector(".reading-mask") as HTMLElement;
    await waitFor(() => {
      expect(element).toBeVisible();
      // expect(getComputedStyle(element, ":after").top).toBe("150px"); // this doesnt work and currently commented out because jsdom doesnt support pseudo elements: https://github.com/jsdom/jsdom/issues/1928
    });
  });

  it(`should not the ReadingMask if visible is false`, async () => {
    const component = render(<ReadingMask visible={false} top="150px" />);
    const element = component.container.querySelector(".reading-mask") as HTMLElement;
    await waitFor(() => {
      expect(element).not.toBeVisible();
    });
  });
});
