import { Fragment, h, VNode } from "preact";
import styles from "./style.scss";
import { useStylesheet } from "~/hooks/useStylesheet";

export type ReadingMaskProps = {
  top: string;
  visible: boolean;
};

export function ReadingMask({ top, visible }: ReadingMaskProps): VNode {
  useStylesheet(styles, { top });

  return (
    <Fragment>
      <div class={`reading-mask ${visible ? "reading-mask--visible" : ""}`} />
    </Fragment>
  );
}
