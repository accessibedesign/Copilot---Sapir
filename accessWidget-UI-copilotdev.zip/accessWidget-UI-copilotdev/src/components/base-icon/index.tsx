import { h, VNode, JSX, Ref } from "preact";
import { forwardRef } from "preact/compat";

type Props = {
  children: string,
  variant?: "img" | "svg",
} & Partial<JSX.HTMLAttributes<HTMLImageElement & SVGSVGElement>>;

const BaseIcon = forwardRef<SVGSVGElement | HTMLImageElement, Props>(
  (props, ref): VNode => {
    if (props.variant === "img") {
      const src = `data:image/svg+xml;base64,${btoa(props.children)}`;
      return (
        <img
          ref={ref as Ref<HTMLImageElement>}
          data-testid="base-icon-img"
          {...props}
          src={src}
          alt={props.alt}
        />
      );
    }

    const svg = new DOMParser().parseFromString(props.children, "image/svg+xml");
    const attributes = Array.from(svg.documentElement.attributes).reduce((acc, a) => {
      acc[a.name] = a.value;
      return acc;
    }, {} as Record<string, string>);

    return (
      <svg
        ref={ref as Ref<SVGSVGElement>}
        fill="currentColor"
        style={{ display: "inline-flex", }}
        {...attributes}
        part={props.part}
        className={props.class}
        data-testid="base-icon-svg"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{ __html: svg.documentElement.innerHTML, }}
      />
    );
  },
);

export default BaseIcon;