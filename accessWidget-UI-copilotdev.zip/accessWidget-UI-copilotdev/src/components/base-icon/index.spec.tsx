import { h } from "preact";
import { render } from "~/utils/test-utils";
import Icon from "./index";
import Images from "../button/images";

describe("Tests `BaseIcon` component functionality", () => {
  it(`should render \`Icon\` component as \`img\` tag instead of \`svg\``, async () => {
    const component = render(
      <Icon variant={"img"} alt={"test"}>
        {Images.checkmark}
      </Icon>
    );
    const icon = await component.findByTestId("base-icon-img");

    expect(icon).toBeTruthy();
  });

  it(`should render \`Icon\` component as \`svg\` tag instead of \`img\``, async () => {
    const component = render(<Icon variant={"svg"}>{Images.checkmark}</Icon>);
    const icon = await component.findAllByTestId("base-icon-svg");

    expect(icon).toBeTruthy();
  });
});
