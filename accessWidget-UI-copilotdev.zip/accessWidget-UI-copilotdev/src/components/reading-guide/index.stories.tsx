/** @jsx h */
import { Fragment, h } from "preact";

import { Meta, StoryFn } from "@storybook/preact";
import { ReadingGuide } from "./";
import readingGuideConfig from "~/mock/reading-guide-config";
export default {
  title: "Example/ReadingGuide",
  component: ReadingGuide,
  args: readingGuideConfig.data,
  argTypes: {},
  decorators: [
    (story) => (
      <Fragment>
        <style>
        {
          `.reading-guide {
              position: static !important;
              transform: none !important;
          }
        `}
        </style>
        {story()}
      </Fragment>
    ),
  ],
} as Meta<typeof ReadingGuide>;
const Template: StoryFn<typeof ReadingGuide> = (args) => <ReadingGuide {...(args as any)} />;

export const Default = Template.bind({});
