import { h } from "preact";
import { render } from "~/utils/test-utils";
import { ReadingGuide } from "./index";
describe("Tests `ReadingGuide` component functionality", () => {
  it(`should render the ReadingGuide at a given position`, () => {
    const component = render(<ReadingGuide left="50px" top="50px" />);
    const element = component.container.querySelector(".reading-guide") as HTMLElement;

    expect(element).toBeVisible();
    expect(element.style.top).toBe("50px");
    expect(element.style.left).toBe("50px");
  });
});
