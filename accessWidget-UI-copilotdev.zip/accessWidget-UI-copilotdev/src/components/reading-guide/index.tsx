import { Fragment, h, VNode } from "preact";
import styles from "./style.scss";
import {useStylesheet} from "~/hooks/useStylesheet";

export interface ReadingGuideProps {
  top: string;
  left: string;
}
/**
 * the accepted props are the top and left position of the reading guide, without considering the size of the guide.
 * we have 'transalteX -50%' in styles to make sure the guide is drawn from the center of the cursor placement.
 */
export function ReadingGuide({ top, left }: ReadingGuideProps): VNode {
  useStylesheet(styles);
  return (
    <Fragment>
      <div style={{ top, left }} class="reading-guide" />
    </Fragment>
  );
}
