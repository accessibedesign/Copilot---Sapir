/** @jsx h */
import { Fragment, h } from "preact";
import { SkipLinks } from "./index";
import { Meta, StoryFn } from "@storybook/preact";
import { SupportedLanguageCode } from "~/types";
export default {
  title: "Example/SkipLinks",
  component: SkipLinks,
  argTypes: {
    language: { control: "select", options: Object.values(SupportedLanguageCode) },
  },
  args: {
    activeBreakpoint: "lg",
  },
  parameters: {
    actions: {
      handles: ["click"],
    },
  },
} as Meta<typeof SkipLinks>;

const Template: StoryFn<typeof SkipLinks> = (args) => <SkipLinks {...args} />;
const pressTabToInteractDecorator = (story) => <div>Press tab to interact {story()}</div>;

const openedSkipLinksDecorator = (story) => (
  <Fragment>
    <style>
      {`
      .skip-links {
        display: flex !important;
        flex-flow: column;
        justify-content: space-evenly;
        height: 500px;
      }
        .skip-link {
          position: relative !important;
          opacity: 1 !important;
        }
   `}
    </style>
    {story()}
  </Fragment>
);

export const Default = Template.bind({});
Default.decorators = [pressTabToInteractDecorator];
export const SingleSkipLink = Template.bind({});
SingleSkipLink.args = {
  activeBreakpoint: "sm",
};
SingleSkipLink.decorators = [pressTabToInteractDecorator];

export const Open = Template.bind({});
Open.decorators = [openedSkipLinksDecorator];

export const OpenSingleSkipLink = Template.bind({});
OpenSingleSkipLink.args = {
  activeBreakpoint: "sm",
};
OpenSingleSkipLink.decorators = [openedSkipLinksDecorator];
