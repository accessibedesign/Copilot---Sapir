import { Breakpoint } from "~/types";

interface SkipLinksProps {
  activeBreakpoint?: Breakpoint;
  onPressed?: ({ type }: { type: SkipLinkItemType }) => void;
  onReachedMenuEnd?: () => void;
}

enum SkipLinkItemType {
  Content = "content",
  Menu = "menu",
  Footer = "footer",
}

interface SkipLinkItem {
  type: SkipLinkItemType;
  href: string;
  dictionaryKey: string;
  hideMobile?: boolean;
}

export { SkipLinksProps, SkipLinkItemType, SkipLinkItem };
