import { h } from "preact";
import { render } from "~/utils/test-utils";
import { SkipLinks } from "./index";
import { Breakpoint } from "~/types";
import { fireEvent } from "@testing-library/preact";

describe("Tests `skip-links` component functionality", () => {
  // it(`should be hidden by default`, async () => {
  //   const component = render(<SkipLinks />);
  //   const buttonComponents = await component.findAllByRole("link");

  //   for (let i = 0; i < buttonComponents.length; i++) {
  //     expect(buttonComponents.at(i)).not.toBeVisible();
  //   }
  // });

  it(`should emit the \`onPressed\` event when button is clicked`, async () => {
    const interaction = jest.fn();

    const component = render(<SkipLinks onPressed={interaction} />);

    const buttonComponents = await component.findAllByRole("link");

    for (let i = 0; i < buttonComponents.length; i++) {
      fireEvent.click(buttonComponents.at(i));

      expect(interaction).toHaveBeenCalledTimes(i + 1);
    }
  });

  it(`should emit the \`onReachedMenuEnd\` event when \`Tab\` is pressed on the last element`, async () => {
    const reachedMenuEnd = jest.fn();

    const component = render(<SkipLinks onReachedMenuEnd={reachedMenuEnd} />);

    const buttonComponents = await component.findAllByRole("link");

    for (let i = 0; i < buttonComponents.length; i++) {
      const currentComponent = buttonComponents.at(i);

      fireEvent.keyDown(currentComponent, { key: "Tab" });
      const isLastButton = i === buttonComponents.length - 1;

      if (!isLastButton) {
        expect(reachedMenuEnd).not.toHaveBeenCalled();
      } else {
        expect(reachedMenuEnd).toHaveBeenCalled();
      }
    }
  });

  it(`should not emit the \`onReachedMenuEnd\` event when \`Tab\` is pressed on the last element`, async () => {
    const reachedMenuEnd = jest.fn();

    const component = render(<SkipLinks onReachedMenuEnd={reachedMenuEnd} />);

    const buttonComponents = await component.findAllByRole("link");

    const lastLink = buttonComponents[buttonComponents.length - 1];

    fireEvent.keyDown(lastLink, { key: "Tab", shiftKey: true });

    expect(reachedMenuEnd).not.toHaveBeenCalled();
  });

  it(`Verifies that the overlay is visible when button is focused`, async () => {
    const component = render(<SkipLinks />);

    const buttonComponent = (await component.findAllByRole("link"))[0];

    expect(component.container.querySelector(".skip-links").classList.contains("active")).toBe(false);

    fireEvent.focus(buttonComponent);

    expect(component.container.querySelector(".skip-links").classList.contains("active")).toBe(true);
    fireEvent.blur(buttonComponent);
    expect(component.container.querySelector(".skip-links").classList.contains("active")).toBe(false);
  });

  it(`should contain 1 skip link and emit the \`onReachedMenuEnd\` event when \`Tab\` is pressed on the first and only element in mobile`, async () => {
    const reachedMenuEnd = jest.fn();
    const component = render(<SkipLinks activeBreakpoint={Breakpoint.SM} onReachedMenuEnd={reachedMenuEnd} />);
    const links = await component.findAllByRole("link");
    expect(links.length).toBe(1);
    const buttonComponent = links[0];

    fireEvent.keyDown(buttonComponent, { key: "Tab" });

    expect(reachedMenuEnd).toHaveBeenCalled();
  });

  it(`should contain 3 skip links and emit the \`onReachedMenuEnd\` event when \`Tab\` is pressed on the last element in desktop`, async () => {
    const reachedMenuEnd = jest.fn();
    const component = render(<SkipLinks activeBreakpoint={Breakpoint.LG} onReachedMenuEnd={reachedMenuEnd} />);

    const links = await component.findAllByRole("link");
    expect(links.length).toBe(3);
    const buttonComponent = links[links.length - 1];

    fireEvent.keyDown(buttonComponent, { key: "Tab" });

    expect(reachedMenuEnd).toHaveBeenCalled();
  });

  it(`should contain 3 skip links and not emit the \`onReachedMenuEnd\` event when \`Tab\` is pressed on anything but the last element`, async () => {
    const reachedMenuEnd = jest.fn();
    const component = render(<SkipLinks activeBreakpoint={Breakpoint.LG} onReachedMenuEnd={reachedMenuEnd} />);
    const links = await component.findAllByRole("link");
    expect(links.length).toBe(3);
    const buttonComponent = links[0];

    fireEvent.keyDown(buttonComponent, { key: "Tab" });
    expect(reachedMenuEnd).not.toHaveBeenCalled();
  });
});
