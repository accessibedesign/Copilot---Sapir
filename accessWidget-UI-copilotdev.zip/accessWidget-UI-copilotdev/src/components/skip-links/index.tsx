import { h, VNode } from "preact";
import { useMemo, useState } from "preact/hooks";
import styles from "./style.scss";
import defaultDictionary from "./locale/en.json";
import { useTranslation } from "../../hooks/useTranslation";
import { SkipLinksProps, SkipLinkItemType, SkipLinkItem } from "./types";
import { SkipLink } from "./components";
import { useStylesheet } from "~/hooks/useStylesheet";
import { Breakpoint } from "~/types";

export * from "./types";

const skipLinkItems: SkipLinkItem[] = [
  {
    href: "#acsbContent",
    type: SkipLinkItemType.Content,
    dictionaryKey: "SKIPLINK_CONTENT",
  },
  {
    href: "#acsbMenu",
    type: SkipLinkItemType.Menu,
    dictionaryKey: "SKIPLINK_MENU",
    hideMobile: true,
  },
  {
    href: "#acsbFooter",
    type: SkipLinkItemType.Footer,
    dictionaryKey: "SKIPLINK_FOOTER",
    hideMobile: true,
  },
];

function SkipLinks(props: SkipLinksProps): VNode {
  const notDesktop = props.activeBreakpoint !== Breakpoint.LG;
  const [isActive, setActive] = useState(false);
  const onClickHandler = (e, type: SkipLinkItemType) => {
    e.preventDefault();
    setActive(true);
    props.onPressed({ type });
  };

  const currentSkipLinks = useMemo(() => {
    if (notDesktop) {
      return skipLinkItems.filter((skipLink) => !skipLink.hideMobile);
    }
    return skipLinkItems;
  }, [notDesktop]);

  const onKeyDownHandler = (event: KeyboardEvent, type: SkipLinkItemType) => {
    if (event.key === "Tab" && !event.shiftKey) {
      const isLastButton =
        currentSkipLinks.findIndex((skipLinkItem) => skipLinkItem.type === type) === currentSkipLinks.length - 1;

      if (isLastButton) {
        props.onReachedMenuEnd();
      }
    }
  };

  const { t } = useTranslation(defaultDictionary);
  useStylesheet(styles);
  return (
    <div>
      <div
        className={`skip-links ${isActive ? "active" : ""}`}
        role="region"
        aria-label={t("SKIP_LINKS")}
        data-acsb="skipLinks"
      >
        {currentSkipLinks.map((skipLink) => (
          <SkipLink
            link={skipLink}
            key={skipLink.href}
            onKeyDown={(e) => onKeyDownHandler(e, skipLink.type)}
            onClick={(e) => onClickHandler(e, skipLink.type)}
            onFocus={() => {
              setActive(true);
            }}
            onBlur={() => setActive(false)}
          />
        ))}
      </div>
    </div>
  );
}

export { SkipLinks };
