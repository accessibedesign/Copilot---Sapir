import { h, VNode, JSX } from "preact";
import { useTranslation } from "~/hooks/useTranslation";
import { SkipLinkItem } from "../types";

import defaultDictionary from "../locale/en.json";
import styles from "./style.scss";
import { useStylesheet } from "~/hooks/useStylesheet";
export type Props = {
  link: SkipLinkItem;
} & JSX.HTMLAttributes;

export const SkipLink = (props: Props): VNode => {
  const { link, onKeyDown, onFocus, onClick, onBlur } = props;
  const { t } = useTranslation(defaultDictionary);
  useStylesheet(styles);
  return (
    <div>
      <a
        key={link.href}
        href={link.href}
        data-acsb-skip-link={link.type}
        class="skip-link"
        {...{ onKeyDown, onFocus, onClick, onBlur }}
      >
        {t(link.dictionaryKey)}
        <div className="content" aria-hidden="true">
          <span className="icon">↵</span>ENTER
        </div>
      </a>
    </div>
  );
};
