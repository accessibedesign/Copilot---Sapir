export interface ScreenReaderButtonProps {
  onPressed?: () => Promise<void>;
  isVisible?: boolean;
  isPressed?: boolean;
}
