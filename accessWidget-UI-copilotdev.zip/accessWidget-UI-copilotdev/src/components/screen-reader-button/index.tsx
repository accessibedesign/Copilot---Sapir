import { h, VNode } from "preact";
import styles from "./style.scss";
import defaultDictionary from "./locale/en.json";
import { useTranslation } from "../../hooks/useTranslation";
import { ScreenReaderButtonProps } from "./types";
import { useStylesheet } from "~/hooks/useStylesheet";

export * from "./types";

function ScreenReaderButton(props: ScreenReaderButtonProps): VNode {
  const { t } = useTranslation(defaultDictionary);

  useStylesheet(styles);

  const cssClass = `screen-reader-button ${props.isVisible ? "" : "hide"}`;

  return (
    <div>
      <button
        onClick={props.onPressed}
        className={cssClass}
        data-acsb-sr-only="true"
        aria-pressed={props.isPressed}
        tabIndex={-1}
      >
        {t("SR_TRIGGER_BUTTON")}
      </button>
    </div>
  );
}

export { ScreenReaderButton };
