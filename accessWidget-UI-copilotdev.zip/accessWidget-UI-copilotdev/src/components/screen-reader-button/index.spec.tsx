import { h } from "preact";
import { render } from "~/utils/test-utils";
import { ScreenReaderButton } from "./index";
import { waitFor } from "@testing-library/dom";

describe("Tests `screen-reader-button` component functionality", () => {
  it(`should be hidden when \`visible: true\` set`, async () => {
    const component = render(<ScreenReaderButton isVisible={true} />);

    expect(await component.findByRole("button")).toHaveStyle({ display: "inline-block" });
  });

  it(`should be hidden when \`visible: false\` set`, async () => {
    const component = render(<ScreenReaderButton isVisible={false} />);

    const button = await component.findByRole("button");
    await waitFor(() => {
      expect(button).toHaveStyle({ display: "none" });
    });
  });

  it(`should emit \`onPressed\` event when the button is clicked`,async () => {
    const interaction = jest.fn();

    const component = render(<ScreenReaderButton onPressed={interaction} />);

    const button = await component.findByRole("button");
    button.click();

    expect(interaction).toHaveBeenCalled();
  });
});
