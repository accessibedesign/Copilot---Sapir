import { Fragment, h, VNode } from "preact";
import { BaseButton } from "../base-button";
import styles from "./style.scss";
import BaseIcon from "~/components/base-icon";
import * as icons from "~/components/widget/assets/icons";
import { useTranslation } from "~/hooks/useTranslation";
import {useStylesheet} from "~/hooks/useStylesheet";

interface Props {
  class?: string;
  ariaLabel: string;
  onClick: (e?: Event) => void;
}

export const CloseButton = (props: Props): VNode => {
  const { t } = useTranslation();
  useStylesheet(styles);
  return (
    <Fragment>
      <BaseButton {...props} class={`close_button ${props.class}`} tabIndex={0} aria-label={t(props.ariaLabel)}>
        <BaseIcon class="icon">{icons.close}</BaseIcon>
      </BaseButton>
    </Fragment>
  );
};
