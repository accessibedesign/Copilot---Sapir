import { h } from "preact";
import { render } from "~/utils/test-utils";
import { Skeleton } from "./index";
describe("Tests `WidgetFooter` component functionality", () => {
  it(`should variant prop to class`, () => {
    const variant = "button";
    const component = render(<Skeleton variant={variant} />);
    const element = component.container.firstChild as HTMLElement;
    expect(element.classList.contains(`skeleton--${variant}`)).toBeTruthy();
  });
});
