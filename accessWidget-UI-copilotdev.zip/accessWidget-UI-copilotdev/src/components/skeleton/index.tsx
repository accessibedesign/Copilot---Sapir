import { Fragment, h, VNode } from "preact";
import styles from "./style.scss";
import {useStylesheet} from "~/hooks/useStylesheet";

interface Props {
  className?: string;
  variant?: "text" | "button" | "avatar";
  height?: string | number;
  width?: string | number;
}

const defualtProps = {
  height: "",
  width: "",
  variant: "text",
  className: "",
};

export function Skeleton({ height, width, variant, className }: Props): VNode {
  useStylesheet(styles)
  return (
    <Fragment>
      <div style={{ height, width }} class={`skeleton skeleton--${variant} ${className}`} />
    </Fragment>
  );
}

Skeleton.defaultProps = defualtProps;
