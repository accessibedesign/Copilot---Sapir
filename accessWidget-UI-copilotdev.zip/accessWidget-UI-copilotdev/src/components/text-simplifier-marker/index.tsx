import { VNode, h, Component } from "preact";
import { useLayoutEffect, useRef, useState } from "preact/hooks";
import { useStylesheet } from "~/hooks/useStylesheet";
import { useTranslation } from "~/hooks/useTranslation";
import { BaseButton } from "~/components/base-button";
import BaseIcon from "~/components/base-icon";
import * as icons from "./assets/icons";
import defaultDictionary from "~/components/text-simplifier-marker/locale/en.json";
import styles from "./style.scss";
import { ButtonTranslate, TextSimplifierMarkerEventData, TextSimplifierMarkerEventType } from "./types";
import { screenEdgesAvoidanceTransform } from "~/components/text-simplifier-marker/utils";

export { TextSimplifierMarkerEventType, TextSimplifierMarkerEventData };

export interface TextSimplifierMarkerProps {
  isVisible: boolean;
  isSelected: boolean;
  leadColor: string;
  onEvent: (event: TextSimplifierMarkerEventData) => void;
  width: number;
  height: number;
  top: number;
  left: number;
}

export const TextSimplifierMarker = ({
  isVisible,
  isSelected,
  leadColor,
  onEvent,
  width,
  height,
  top,
  left,
}: TextSimplifierMarkerProps): VNode => {
  useStylesheet(styles, { "lead-color": leadColor });
  const { t } = useTranslation(defaultDictionary);
  const [buttonTranslate, setButtonTranslate] = useState<ButtonTranslate>({ x: 0, y: 0 });
  const [isHoveringOverSimplifyButton, setIsHoveringOverSimplifyButton] = useState(false);
  /*
   The iconRef is cast as an SVGElement type as the BaseIcon component does not
   have a ref type defined, we need to use forwardRef in the BaseIcon and type it according
   to the variant (svg/img)
   */
  const iconRef = useRef<(HTMLImageElement & Component) | null>(null);
  useLayoutEffect(() => {
    const simplifyButton = iconRef.current;
    const iconSize = simplifyButton.getBoundingClientRect().width;
    const buttonTranslate = screenEdgesAvoidanceTransform({ iconSize, width, height, top, left });
    setButtonTranslate(buttonTranslate);
  }, [width, height, top, left]);

  const markerStyle = {
    width: `${width}px`,
    height: `${height}px`,
    top: `${top}px`,
    left: `${left}px`,
    display: isVisible ? "" : "none",
  };

  const buttonStyle = `transform: translate(${buttonTranslate.x}px, ${buttonTranslate.y}px)`;

  return (
    <div
      data-testid="marker"
      class={`text-simplifier-marker ${isSelected ? "text-simplifier-marker--selected" : ""}`}
      style={markerStyle}
    >
      <div
        class="text-simplifier-marker__button"
        style={buttonStyle}
        data-testid="simplify-button"
        onMouseEnter={() => setIsHoveringOverSimplifyButton(true)}
        onMouseLeave={() => setIsHoveringOverSimplifyButton(false)}
      >
        <BaseButton
          class="text-simplifier-marker__icon"
          onClick={() => onEvent({ type: TextSimplifierMarkerEventType.Simplify })}
        >
          <BaseIcon ref={iconRef} class="icon">
            {icons.text_simplifier}
          </BaseIcon>
          {isHoveringOverSimplifyButton && !isSelected && (
            <div role="tooltip" class="text-simplifier-marker__tooltip">
              {t("TEXT_SIMPLIFIER_MARKER_TOOLTIP")}
            </div>
          )}
        </BaseButton>
      </div>
    </div>
  );
};
