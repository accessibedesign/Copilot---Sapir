import { ButtonTranslate } from "~/components/text-simplifier-marker/types";

/*
BUTTON_PARAGRAPH_MARGIN: The margin between the text and the simplification button
in the marker component. The marker component has a 12px box-shadow outside the text,
and we want 10px space horizontally from the button to the text, so together it is 22px.

DEFAULT_VERTICAL_OFFSET: The default vertical offset for the button when it is positioned.
According to the design it should be 4 pixels below the marked area, but because we have a 12px
box-shadow outside the text, we need to subtract 8px by default.
 */
const BUTTON_PARAGRAPH_MARGIN = 22;
const DEFAULT_VERTICAL_OFFSET = -8;
const EDGE_PROXIMITY_MULTIPLIER = 2;

// Proximity to the 4 edges of the screen
interface Proximity {
  nearLeft: boolean;
  nearRight: boolean;
  nearTop: boolean;
  nearBottom: boolean;
}

// input interface for edge proximity check
export interface PositionMetrics {
  iconSize: number;
  width: number;
  height: number;
  top: number;
  left: number;
}

const getViewportSize = (): { width: number; height: number } => ({
  width: window.innerWidth,
  height: window.innerHeight,
});

/**
 * Checks whether a rectangular element is near any edge of the viewport.
 *
 * This function uses the given element's position and size, along with
 * the viewport dimensions, to determine if the element is within the
 * proximity defined by `iconSize` to the left, right, top, or bottom edges.
 *
 * If left side is less than EDGE_PROXIMITY_MULTIPLIER the icon size
 * it is considered too close the left edge for the icon to show there,
 * so we switch sides to the right side, and vice versa for the right edge.
 *
 * @param {PositionMetrics} params - The metrics of the element to check.
 * @param {number} params.iconSize - The threshold distance from the edge to consider as "near".
 * @param {number} params.width - The width of the element.
 * @param {number} params.height - The height of the element.
 * @param {number} params.top - The distance from the top of the viewport.
 * @param {number} params.left - The distance from the left of the viewport.
 *
 * @returns {Proximity} An object indicating whether the element is near each viewport edge.
 *
 * @example
 * const proximity = checkProximity({
 *   iconSize: 20,
 *   width: 50,
 *   height: 50,
 *   top: 10,
 *   left: 5,
 * });
 * // proximity => { nearLeft: true, nearRight: false, nearTop: true, nearBottom: false }
 */
const checkProximity = ({ iconSize, width, height, top, left }: PositionMetrics): Proximity => {
  const { width: viewportWidth, height: viewportHeight } = getViewportSize();
  return {
    nearLeft: left < (iconSize * EDGE_PROXIMITY_MULTIPLIER),
    nearRight: left + width > viewportWidth - iconSize,
    nearTop: top < iconSize,
    nearBottom: top + height > viewportHeight - iconSize,
  };
};

/**
 * Calculates a safe CSS translate offset for positioning a floating icon
 * while avoiding screen edges.
 *
 * @param metrics - Metrics including icon size, dimensions, and position.
 * @returns A { x, y } offset for CSS `translate(...)`.
 */
export const screenEdgesAvoidanceTransform = (metrics: PositionMetrics): ButtonTranslate => {
  const { iconSize, width, height } = metrics;
  const { nearLeft, nearRight, nearTop, nearBottom } = checkProximity(metrics);

  let x = 0;
  let y = 0;

  if (!nearLeft) {
    x = -iconSize - BUTTON_PARAGRAPH_MARGIN;
    y = DEFAULT_VERTICAL_OFFSET;
  } else if (!nearRight) {
    x = width + BUTTON_PARAGRAPH_MARGIN;
    y = DEFAULT_VERTICAL_OFFSET;
  } else if (!nearTop) {
    x = iconSize;
    y = -iconSize - BUTTON_PARAGRAPH_MARGIN;
  } else if (!nearBottom) {
    x = iconSize;
    y = height + BUTTON_PARAGRAPH_MARGIN;
  }

  return { x, y };
};
