import text_simplifier from "./text_simplifier.svg";

export { text_simplifier };
