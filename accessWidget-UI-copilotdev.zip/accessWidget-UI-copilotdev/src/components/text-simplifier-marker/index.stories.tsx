/** @jsx h */
import { h } from "preact";
import { TextSimplifierMarker, TextSimplifierMarkerProps } from "./index";
import { Meta, StoryFn } from "@storybook/preact";
import { DecoratorFunction } from "@storybook/types";
import { SupportedLanguageCode } from "~/types";

const withOutline: DecoratorFunction = (Story) => {
  return (
    <div style={{ position: "relative", width: "100vw", height: "100vh" }}>
      {Story()}
      <style>
        {`
          .text-simplifier-hover {
            outline: 1px dotted black;
          }
        `}
      </style>
    </div>
  );
};

export default {
  title: "Example/TextSimplifierMarker",
  component: TextSimplifierMarker,
  argTypes: {
    onEvent: { action: "onEvent" },
    language: { control: "select", options: Object.values(SupportedLanguageCode) },
  },
  decorators: [withOutline],
} as Meta<typeof TextSimplifierMarker>;

const Template: StoryFn<typeof TextSimplifierMarker> = (args) => <TextSimplifierMarker {...(args as any)} />;

export const Regular = Template.bind({});
Regular.args = {
  isVisible: true,
  isSelected: false,
  leadColor: "#136ef8",
  width: 500,
  height: 300,
  top: 200,
  left: 200,
} as TextSimplifierMarkerProps;

export const DifferentColor = Template.bind({});
DifferentColor.args = {
  isVisible: true,
  isSelected: false,
  leadColor: "#962ab1",
  width: 500,
  height: 300,
  top: 200,
  left: 200,
} as TextSimplifierMarkerProps;

export const Selected = Template.bind({});
Selected.args = {
  isVisible: true,
  isSelected: true,
  leadColor: "#136ef8",
  width: 500,
  height: 300,
  top: 200,
  left: 200,
} as TextSimplifierMarkerProps;

export const HitLeftEdge = Template.bind({});
HitLeftEdge.args = {
  isVisible: true,
  isSelected: false,
  leadColor: "#136ef8",
  width: 500,
  height: 300,
  top: 200,
  left: 0,
} as TextSimplifierMarkerProps;

export const HitLeftAndRightEdges = Template.bind({});
HitLeftAndRightEdges.args = {
  isVisible: true,
  isSelected: false,
  leadColor: "#136ef8",
  width: 1200,
  height: 300,
  top: 200,
  left: 0,
} as TextSimplifierMarkerProps;

export const HitTopLeftAndRight = Template.bind({});
HitTopLeftAndRight.args = {
  isVisible: true,
  isSelected: false,
  leadColor: "#136ef8",
  width: 1200,
  height: 300,
  top: 0,
  left: 0,
} as TextSimplifierMarkerProps;

export const NotVisible = Template.bind({});
NotVisible.args = {
  isVisible: false,
  isSelected: false,
  leadColor: "#136ef8",
  width: 1200,
  height: 300,
  top: 0,
  left: 0,
} as TextSimplifierMarkerProps;
