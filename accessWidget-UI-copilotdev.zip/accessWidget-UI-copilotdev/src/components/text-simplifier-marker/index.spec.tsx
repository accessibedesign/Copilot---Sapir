import { h } from "preact";
import { fireEvent } from "@testing-library/preact";
import { render } from "~/utils/test-utils";
import { TextSimplifierMarker, TextSimplifierMarkerEventType } from "./index";
import { screenEdgesAvoidanceTransform } from "./utils";

describe("`screenEdgesAvoidanceTransform` utility", () => {
  it("returns translation to the left when not near any edges", () => {
    const result = screenEdgesAvoidanceTransform({ iconSize: 24, width: 500, height: 200, top: 200, left: 200 });
    expect(result).toStrictEqual({ x: -46, y: -8 });
  });

  it("returns translation to the right when near left edge", () => {
    const width = 500;
    const result = screenEdgesAvoidanceTransform({ iconSize: 24, width, height: 200, top: 200, left: 0 });
    expect(result).toStrictEqual({ x: 522, y: -8 });
  });

  it("returns translation to the top when near both left and right edges", () => {
    const result = screenEdgesAvoidanceTransform({
      iconSize: 24,
      width: window.innerWidth,
      height: 200,
      top: 200,
      left: 0,
    });
    expect(result).toStrictEqual({ x: 24, y: -46 });
  });

  it("returns translation to the bottom when near all horizontal and top edges", () => {
    const result = screenEdgesAvoidanceTransform({
      iconSize: 24,
      width: window.innerWidth,
      height: window.innerHeight - 100,
      top: 0,
      left: 0,
    });
    expect(result).toStrictEqual({ x: 24, y: 690 });
  });

  it("returns no translation when near all edges", () => {
    const result = screenEdgesAvoidanceTransform({
      iconSize: 24,
      width: window.innerWidth,
      height: window.innerHeight,
      top: 0,
      left: 0,
    });
    expect(result).toStrictEqual({ x: 0, y: 0 });
  });
});

describe("`TextSimplifierMarker` component", () => {
  const onEvent = jest.fn();

  it("hides marker when `isVisible` is false", () => {
    const component = render(
      <TextSimplifierMarker
        isVisible={false}
        isSelected={false}
        leadColor="#136ef8"
        onEvent={onEvent}
        width={200}
        height={200}
        top={200}
        left={200}
      />,
    );

    const marker = component.queryByTestId("marker");
    expect(marker).toBeInTheDocument();
    expect(marker).not.toBeVisible();
  });

  it("triggers 'Simplify' event when icon is clicked", () => {
    const component = render(
      <TextSimplifierMarker
        isVisible={true}
        isSelected={false}
        leadColor="#136ef8"
        onEvent={onEvent}
        width={200}
        height={200}
        top={200}
        left={200}
      />,
    );

    fireEvent.click(component.queryByRole("button"));
    expect(onEvent).toBeCalledWith({ type: TextSimplifierMarkerEventType.Simplify });
    expect(onEvent).toHaveBeenCalledTimes(1);
  });

  it("should add 'marker-selected' class and hides button when `isSelected` is true", () => {
    const component = render(
      <TextSimplifierMarker
        isVisible={true}
        isSelected={true}
        leadColor="#136ef8"
        onEvent={onEvent}
        width={200}
        height={200}
        top={200}
        left={200}
      />,
    );

    expect(component.queryByTestId("marker")).toHaveClass("text-simplifier-marker--selected");
  });

  it("should show tooltip when hovering on the button", () => {
    const onEvent = jest.fn();

    const component = render(
      <TextSimplifierMarker
        isVisible={true}
        isSelected={false}
        leadColor="#136ef8"
        onEvent={onEvent}
        width={200}
        height={200}
        top={200}
        left={200}
      />,
    );

    // Then, hover over the button
    const button = component.queryByTestId("simplify-button");
    fireEvent.mouseEnter(button);

    // Tooltip should now be visible
    const tooltip = component.queryByRole("tooltip");
    expect(tooltip).toBeInTheDocument();

    fireEvent.mouseLeave(button);
    expect(tooltip).not.toBeInTheDocument();
  });
});
