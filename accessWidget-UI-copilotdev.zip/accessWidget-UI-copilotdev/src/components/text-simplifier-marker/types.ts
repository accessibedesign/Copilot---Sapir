export enum TextSimplifierMarkerEventType {
  Simplify = "Simplify",
}

export type ButtonTranslate = {
  x: number;
  y: number;
};

export type TextSimplifierMarkerEventData = { type: TextSimplifierMarkerEventType.Simplify };
