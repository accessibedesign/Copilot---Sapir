/**
 * Allowed consistent help value types.
 */
export enum ConsistentHelpType {
  TEXT = "text",
  TEL = "tel",
  MAILTO = "mailto",
  URL = "url",
}

/**
 * Allowed consistent help categories.
 */
export enum ConsistentHelpCategory {
  CONTACT_PHONE = "Contact Phone",
  CONTACT_EMAIL = "Contact Email",
  OPERATION_HOURS = "Operation Hours",
  SUPPORT_PAGE = "Support Page",
  CONTACT_PAGE = "Contact Page",
  FAQ_PAGE = "FAQ Page",
  CHAT_SUPPORT = "Chat Support"
}

/**
 * A single help item entry.
 * Contains a title (category), a type, and a description.
 */
export interface ConsistentHelpItem {
  title: `${ConsistentHelpCategory}`;
  type?: `${ConsistentHelpType}`;
  description: string;
}

/**
 * Maps categories to their default type.
 * This replaces the old nested title object.
 */
export const helpItemTypeMap: Record<ConsistentHelpCategory, ConsistentHelpType> = {
  [ConsistentHelpCategory.OPERATION_HOURS]: ConsistentHelpType.TEXT,
  [ConsistentHelpCategory.CONTACT_PHONE]: ConsistentHelpType.TEL,
  [ConsistentHelpCategory.CONTACT_EMAIL]: ConsistentHelpType.MAILTO,
  [ConsistentHelpCategory.SUPPORT_PAGE]: ConsistentHelpType.URL,
  [ConsistentHelpCategory.CONTACT_PAGE]: ConsistentHelpType.URL,
  [ConsistentHelpCategory.FAQ_PAGE]: ConsistentHelpType.URL,
  [ConsistentHelpCategory.CHAT_SUPPORT]: ConsistentHelpType.URL,
};
