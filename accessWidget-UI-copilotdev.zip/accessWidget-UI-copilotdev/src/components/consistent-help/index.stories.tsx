/** @jsx h */
import { h } from "preact";
import { ConsistentHelp, ConsistentHelpProps } from "./index";
import { Meta, StoryFn } from "@storybook/preact";
import { SupportedLanguageCode } from "~/types";
import { helpItemTypeMap, ConsistentHelpCategory } from "~/components/consistent-help/interfaces";

export default {
  title: "Example/ConsistentHelpPopover",
  component: ConsistentHelp,
  args: {
    consistentHelpData: [
      {
        title: ConsistentHelpCategory.OPERATION_HOURS,
        type: helpItemTypeMap[ConsistentHelpCategory.OPERATION_HOURS],
        description: "General text information shown as plain text.",
      },
      {
        title: ConsistentHelpCategory.CONTACT_EMAIL,
        type: helpItemTypeMap[ConsistentHelpCategory.CONTACT_EMAIL],
        description: "support@example.com",
      },
      {
        title: ConsistentHelpCategory.CONTACT_PHONE,
        type: helpItemTypeMap[ConsistentHelpCategory.CONTACT_PHONE],
        description: "+1-800-555-0199",
      },
      {
        title: ConsistentHelpCategory.SUPPORT_PAGE,
        type: helpItemTypeMap[ConsistentHelpCategory.SUPPORT_PAGE],
        description: "https://www.example.com/support",
      },
    ],
    leadColor: "#136EF8",
  },
  argTypes: {
    language: {
      control: "select",
      options: Object.values(SupportedLanguageCode),
    },
  },
} as Meta<typeof ConsistentHelp>;

/**
 * Base template for ConsistentHelp stories.
 */
const TemplateConsistentHelpPopover: StoryFn<typeof ConsistentHelp> = (args) => (
  <ConsistentHelp {...(args as ConsistentHelpProps)} />
);

const DEFAULT_ARGUMENTS: Partial<ConsistentHelpProps> = {
  consistentHelpData: [
    {
      title: ConsistentHelpCategory.OPERATION_HOURS,
      type: helpItemTypeMap[ConsistentHelpCategory.OPERATION_HOURS],
      description: "General text information shown as plain text.",
    },
    {
      title: ConsistentHelpCategory.CONTACT_EMAIL,
      type: helpItemTypeMap[ConsistentHelpCategory.CONTACT_EMAIL],
      description: "product.support@gmail.com",
    },
    {
      title: ConsistentHelpCategory.CONTACT_PHONE,
      type: helpItemTypeMap[ConsistentHelpCategory.CONTACT_PHONE],
      description: "+1-800-555-0199",
    },
    {
      title: ConsistentHelpCategory.SUPPORT_PAGE,
      type: helpItemTypeMap[ConsistentHelpCategory.SUPPORT_PAGE],
      description: "https://www.example.com/support",
    },
  ],
};

/** Default story */
export const Default = TemplateConsistentHelpPopover.bind({});
Default.args = {
  ...DEFAULT_ARGUMENTS,
} as Partial<ConsistentHelpProps>;

/** General Text content */
export const GeneralTextContent = TemplateConsistentHelpPopover.bind({});
GeneralTextContent.args = {
  ...DEFAULT_ARGUMENTS,
  consistentHelpData: [
    {
      title: ConsistentHelpCategory.OPERATION_HOURS,
      type: helpItemTypeMap[ConsistentHelpCategory.OPERATION_HOURS],
      description: "This is a general text entry with no link.",
    },
  ],
} as Partial<ConsistentHelpProps>;

/** Phone (tel) content */
export const PhoneContent = TemplateConsistentHelpPopover.bind({});
PhoneContent.args = {
  ...DEFAULT_ARGUMENTS,
  consistentHelpData: [
    {
      title: ConsistentHelpCategory.CONTACT_PHONE,
      type: helpItemTypeMap[ConsistentHelpCategory.CONTACT_PHONE],
      description: "+1-800-555-0199",
    },
  ],
} as Partial<ConsistentHelpProps>;

/** Email (mailto) content */
export const EmailContent = TemplateConsistentHelpPopover.bind({});
EmailContent.args = {
  ...DEFAULT_ARGUMENTS,
  consistentHelpData: [
    {
      title: ConsistentHelpCategory.CONTACT_EMAIL,
      type: helpItemTypeMap[ConsistentHelpCategory.CONTACT_EMAIL],
      description: "support@example.com",
    },
  ],
} as Partial<ConsistentHelpProps>;

/** Operation Hours content (text) */
export const OperationHoursContent = TemplateConsistentHelpPopover.bind({});
OperationHoursContent.args = {
  ...DEFAULT_ARGUMENTS,
  consistentHelpData: [
    {
      title: ConsistentHelpCategory.OPERATION_HOURS,
      type: helpItemTypeMap[ConsistentHelpCategory.OPERATION_HOURS],
      description: "Mon–Fri: 09:00–18:00",
    },
  ],
} as Partial<ConsistentHelpProps>;

/** Support URL content */
export const SupportUrlContent = TemplateConsistentHelpPopover.bind({});
SupportUrlContent.args = {
  ...DEFAULT_ARGUMENTS,
  consistentHelpData: [
    {
      title: ConsistentHelpCategory.SUPPORT_PAGE,
      type: helpItemTypeMap[ConsistentHelpCategory.SUPPORT_PAGE],
      description: "https://www.example.com/support",
    },
  ],
} as Partial<ConsistentHelpProps>;

/** FAQ URL content */
export const FaqUrlContent = TemplateConsistentHelpPopover.bind({});
FaqUrlContent.args = {
  ...DEFAULT_ARGUMENTS,
  consistentHelpData: [
    {
      title: ConsistentHelpCategory.FAQ_PAGE,
      type: helpItemTypeMap[ConsistentHelpCategory.FAQ_PAGE],
      description: "https://www.example.com/faq",
    },
  ],
} as Partial<ConsistentHelpProps>;

/** Chatbot URL content */
export const ChatbotContent = TemplateConsistentHelpPopover.bind({});
ChatbotContent.args = {
  ...DEFAULT_ARGUMENTS,
  consistentHelpData: [
    {
      title: ConsistentHelpCategory.CHAT_SUPPORT,
      type: helpItemTypeMap[ConsistentHelpCategory.CHAT_SUPPORT],
      description: "https://www.example.com/chat",
    },
  ],
} as Partial<ConsistentHelpProps>;

/** Example with long customer-provided text (text type) */
export const LongTextExample = TemplateConsistentHelpPopover.bind({});
LongTextExample.args = {
  ...DEFAULT_ARGUMENTS,
  consistentHelpData: [
    {
      title: ConsistentHelpCategory.OPERATION_HOURS,
      type: helpItemTypeMap[ConsistentHelpCategory.OPERATION_HOURS],
      description:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
    },
  ],
} as Partial<ConsistentHelpProps>;

/** Popover is expanded by default */
export const Expanded = TemplateConsistentHelpPopover.bind({});
Expanded.args = {
  ...DEFAULT_ARGUMENTS,
  expandedByDefault: true,
} as Partial<ConsistentHelpProps>;

/** Right-to-left language like Hebrew or Arabic */
export const RTL = TemplateConsistentHelpPopover.bind({});
RTL.args = {
  ...DEFAULT_ARGUMENTS,
  language: SupportedLanguageCode.HE,
  consistentHelpData: [
    {
      title: ConsistentHelpCategory.FAQ_PAGE,
      type: helpItemTypeMap[ConsistentHelpCategory.FAQ_PAGE],
      description: "https://www.example.com",
    },
  ],
} as Partial<ConsistentHelpProps>;

/** Languages like German or Spanish where some of the text is longer than English */
export const LongLanguage = TemplateConsistentHelpPopover.bind({});
LongLanguage.args = {
  ...DEFAULT_ARGUMENTS,
  language: SupportedLanguageCode.DE,
} as Partial<ConsistentHelpProps>;

/** Different lead color to match branding */
export const DifferentLeadColor = TemplateConsistentHelpPopover.bind({});
DifferentLeadColor.args = {
  ...DEFAULT_ARGUMENTS,
  leadColor: "#c42525",
} as Partial<ConsistentHelpProps>;

/** Story to demonstrate sticky behavior when scrolling */
const longContent = Array(100)
  .fill(
    `
      <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
      </p>
      <p>
        Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
      </p>
    `,
  )
  .join("");

/**
 * Template used to demonstrate sticky behavior when scrolling.
 */
const TemplateConsistentHelpLongPage: StoryFn<typeof ConsistentHelp> = (args) => (
  <div>
    <ConsistentHelp {...(args as ConsistentHelpProps)} />
    <div
      style={{
        marginTop: "100px",
        padding: "20px",
        border: "1px solid #eee",
        minHeight: "2000px",
      }}
      dangerouslySetInnerHTML={{ __html: longContent }}
    />
  </div>
);

export const ComponentIsStickyWhenScrolling = TemplateConsistentHelpLongPage.bind({});
ComponentIsStickyWhenScrolling.args = {
  ...DEFAULT_ARGUMENTS,
  consistentHelpData: [
    {
      title: ConsistentHelpCategory.OPERATION_HOURS,
      type: helpItemTypeMap[ConsistentHelpCategory.OPERATION_HOURS],
      description: "This is some content for the sticky component example.",
    },
  ],
} as Partial<ConsistentHelpProps>;

/** XSS URL Attempt, if somehow gets past backend should not cause an error that stops ui from loading */
export const AttemptToXssURL = TemplateConsistentHelpPopover.bind({});
AttemptToXssURL.args = {
  ...DEFAULT_ARGUMENTS,
  consistentHelpData: [
    {
      title: ConsistentHelpCategory.SUPPORT_PAGE,
      type: helpItemTypeMap[ConsistentHelpCategory.SUPPORT_PAGE],
      description: "javascript:alert('XSS')",
    },
  ],
} as Partial<ConsistentHelpProps>;