import { h, VNode } from "preact";
import { useStylesheet } from "~/hooks/useStylesheet";
import styles from "./styles.scss";
import BaseIcon from "~/components/base-icon";
import * as icons from "~/components/consistent-help/assets";
import { useTranslation } from "~/hooks/useTranslation";
import defaultDictionary from "~/components/consistent-help/locale/en.json";
import {
  ConsistentHelpItem,
  ConsistentHelpType,
  helpItemTypeMap,
  ConsistentHelpCategory,
} from "~/components/consistent-help/interfaces";
import { formatUrl } from "~/utils/format-url";
import { sanitizeHtmlString } from "~/utils/sanitize-html-string";

export interface ConsistentHelpContentProps {
  /** The content to display when the popover is open */
  consistentHelpData?: ConsistentHelpItem[];
  /** Whether the consistent help content is expanded or collapsed */
  isExpanded: boolean;
  /** Function to update the expanded state of the consistent help content */
  onToggle: () => void;
}

/**
 * Renders the consistent help content list and disclaimer.
 */
export function ConsistentHelpContent({ consistentHelpData, isExpanded, onToggle }: ConsistentHelpContentProps): VNode {
  useStylesheet(styles);
  const { t, direction } = useTranslation(defaultDictionary);

  /**
   * Handles Escape key interaction to collapse the content if expanded.
   */
  const handleEscapeInteraction = (event: KeyboardEvent) => {
    if (event.key === "Escape" && isExpanded) {
      onToggle();
    }
  };

  /**
   * Renders a single item's description based on its type.
   */
  const renderDescription = (item: ConsistentHelpItem): VNode => {
    /** Type is an optional field and tells us what kind of content we are receiving.
     * if not provided we use the helpItemTypeMap to infer it based on the title */
    if (!item.type) {
      item.type = helpItemTypeMap[item.title as ConsistentHelpCategory];
    }

    // Clean the description content, ensure content is safe for rendering
    const trimmedContent = item.description.trim();
    const sanitizedContent = sanitizeHtmlString(trimmedContent);

    switch (item.type) {
      case ConsistentHelpType.TEL: {
        return <a aria-label="Opens phone" href={`tel:${sanitizedContent}`}>{sanitizedContent}</a>;
      }

      case ConsistentHelpType.MAILTO: {
        return <a aria-label="Opens email" href={`mailto:${sanitizedContent}`}>{sanitizedContent}</a>;
      }

      case ConsistentHelpType.URL: {
        const formattedLink = formatUrl(sanitizedContent);
        return (
          <a aria-label="Opens link in a new page" href={formattedLink} target="_blank" rel="noopener noreferrer">
            {sanitizedContent}
          </a>
        );
      }

      case ConsistentHelpType.TEXT:
      default: {
        return <span>{sanitizedContent}</span>;
      }
    }
  };

  return (
    <div
      class={`consistent-help-expandable-content ${isExpanded ? "consistent-help-expandable-content--expanded" : ""}`}
    >
      {/* eslint-disable-next-line jsx-a11y/no-static-element-interactions */}
      <div class="consistent-help-expandable-content__body" dir={direction} onKeyDown={handleEscapeInteraction}>
        {consistentHelpData && (
          <ul>
            {consistentHelpData.map((item, index) => (
              <li key={index}>
                <strong>{item.title}</strong>
                <div>{renderDescription(item)}</div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div class="consistent-help-expandable-content__disclaimer">
        <BaseIcon>{icons.infoIcon}</BaseIcon>
        <span class="text">{t("DISCLAIMER_TEXT")}</span>
      </div>
    </div>
  );
}
