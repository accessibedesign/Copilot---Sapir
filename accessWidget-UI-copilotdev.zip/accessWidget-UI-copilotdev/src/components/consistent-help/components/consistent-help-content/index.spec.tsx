import { h } from "preact";
import { useState } from "preact/hooks";
import { render } from "~/utils/test-utils";
import { ConsistentHelpContent } from "./index";
import { fireEvent, waitFor } from "@testing-library/preact";
import { ConsistentHelpItem, helpItemTypeMap, ConsistentHelpCategory } from "~/components/consistent-help/interfaces";

/** Test helper */
function createSampleData(): ConsistentHelpItem[] {
  return [
    {
      title: ConsistentHelpCategory.OPERATION_HOURS,
      type: helpItemTypeMap[ConsistentHelpCategory.OPERATION_HOURS],
      description: `Need help? Read this!`,
    },
  ];
}

/** Harness to flip isExpanded without unmounting providers */
function Harness(props: { initialExpanded?: boolean; data?: ConsistentHelpItem[] | undefined; onToggle?: () => void }) {
  const [expanded, setExpanded] = useState<boolean>(props.initialExpanded ?? false);
  return (
    <div>
      <button aria-label="expand" onClick={() => setExpanded(true)} />
      <button aria-label="collapse" onClick={() => setExpanded(false)} />
      <ConsistentHelpContent
        isExpanded={expanded}
        consistentHelpData={props.data}
        onToggle={props.onToggle ?? (() => setExpanded((value) => !value))}
      />
    </div>
  );
}

describe("ConsistentHelpContent", () => {
  it("toggles expanded modifier class based on isExpanded", async () => {
    const { container, getByLabelText } = render(<Harness initialExpanded={false} data={createSampleData()} />);

    const wrapper = container.querySelector(".consistent-help-expandable-content") as HTMLDivElement;
    expect(wrapper.className).not.toContain("consistent-help-expandable-content--expanded");

    // Expand
    fireEvent.click(getByLabelText("expand"));
    await waitFor(() => expect(wrapper.className).toContain("consistent-help-expandable-content--expanded"));

    // Collapse
    fireEvent.click(getByLabelText("collapse"));
    await waitFor(() => expect(wrapper.className).not.toContain("consistent-help-expandable-content--expanded"));
  });

  it("renders list with sanitized HTML when data is provided", () => {
    const onToggle = jest.fn();

    const { getByRole, getByText } = render(
      <ConsistentHelpContent isExpanded={true} consistentHelpData={createSampleData()} onToggle={onToggle} />,
    );

    // UL exists with one LI
    const list = getByRole("list");
    expect(list).toBeTruthy();
    const itemTitle = getByText("Operation Hours");
    expect(itemTitle.tagName.toLowerCase()).toBe("strong");

    // Inner HTML is injected; spot-check content presence
    const htmlSpan = list.querySelector("span");
    expect(htmlSpan).toBeTruthy();
    expect(htmlSpan?.textContent).toContain("Need help? Read this!");
  });

  it("handles empty data gracefully (renders empty list) and shows disclaimer", () => {
    const onToggle = jest.fn();

    const { container, getByRole, queryAllByRole } = render(
      <ConsistentHelpContent isExpanded={true} consistentHelpData={[]} onToggle={onToggle} />,
    );

    // Empty <ul>
    const list = getByRole("list");
    expect(list).toBeTruthy();
    expect(queryAllByRole("listitem")).toHaveLength(0);

    // Disclaimer present
    const disclaimer = container.querySelector(".consistent-help-expandable-content__disclaimer");
    expect(disclaimer).toBeTruthy();

    // Body container present
    const body = container.querySelector(".consistent-help-expandable-content__body");
    expect(body).toBeTruthy();
  });

  it("does not render a list when data is undefined, but keeps disclaimer and body", () => {
    const onToggle = jest.fn();

    const { container, queryByRole } = render(
      <ConsistentHelpContent isExpanded={true} consistentHelpData={undefined} onToggle={onToggle} />,
    );

    expect(queryByRole("list")).toBeNull();

    const disclaimer = container.querySelector(".consistent-help-expandable-content__disclaimer");
    expect(disclaimer).toBeTruthy();

    const body = container.querySelector(".consistent-help-expandable-content__body");
    expect(body).toBeTruthy();
  });

  it("calls onToggle on Escape when expanded", () => {
    const onToggle = jest.fn();
    const { container } = render(
      <ConsistentHelpContent isExpanded={true} consistentHelpData={createSampleData()} onToggle={onToggle} />,
    );

    const body = container.querySelector(".consistent-help-expandable-content__body") as HTMLDivElement;
    fireEvent.keyDown(body, { key: "Escape", code: "Escape" });
    expect(onToggle).toHaveBeenCalledTimes(1);
  });

  it("does not call onToggle on Escape when not expanded", () => {
    const onToggle = jest.fn();
    const { container } = render(
      <ConsistentHelpContent isExpanded={false} consistentHelpData={createSampleData()} onToggle={onToggle} />,
    );

    const body = container.querySelector(".consistent-help-expandable-content__body") as HTMLDivElement;
    fireEvent.keyDown(body, { key: "Escape", code: "Escape" });
    expect(onToggle).not.toHaveBeenCalled();
  });

  it("renders a tel link for ConsistentHelpType.TEL", () => {
    const onToggle = jest.fn();
    const telNumber = "123-456-7890";
    const data: ConsistentHelpItem[] = [
      {
        title: ConsistentHelpCategory.CONTACT_PHONE,
        type: helpItemTypeMap[ConsistentHelpCategory.CONTACT_PHONE],
        description: telNumber,
      },
    ];

    const { getByText } = render(
      <ConsistentHelpContent isExpanded={true} consistentHelpData={data} onToggle={onToggle} />,
    );

    const link = getByText(telNumber) as HTMLAnchorElement;
    expect(link).toBeTruthy();
    expect(link.tagName.toLowerCase()).toBe("a");
    expect(link.href).toBe(`tel:${telNumber}`);
  });

  it("renders a mailto link for ConsistentHelpType.MAILTO", () => {
    const onToggle = jest.fn();
    const emailAddress = "test@example.com";
    const data: ConsistentHelpItem[] = [
      {
        title: ConsistentHelpCategory.CONTACT_EMAIL,
        type: helpItemTypeMap[ConsistentHelpCategory.CONTACT_EMAIL],
        description: emailAddress,
      },
    ];

    const { getByText } = render(
      <ConsistentHelpContent isExpanded={true} consistentHelpData={data} onToggle={onToggle} />,
    );

    const link = getByText(emailAddress) as HTMLAnchorElement;
    expect(link).toBeTruthy();
    expect(link.tagName.toLowerCase()).toBe("a");
    expect(link.href).toBe(`mailto:${emailAddress}`);
  });

  it("renders a URL link for ConsistentHelpType.URL", () => {
    const onToggle = jest.fn();
    const url = "https://www.example.com/";
    const data: ConsistentHelpItem[] = [
      {
        title: ConsistentHelpCategory.SUPPORT_PAGE,
        type: helpItemTypeMap[ConsistentHelpCategory.SUPPORT_PAGE],
        description: url,
      },
    ];

    const { getByText } = render(
      <ConsistentHelpContent isExpanded={true} consistentHelpData={data} onToggle={onToggle} />,
    );

    const link = getByText(url) as HTMLAnchorElement;
    expect(link).toBeTruthy();
    expect(link.tagName.toLowerCase()).toBe("a");
    expect(link.href).toBe(url);
    expect(link.target).toBe("_blank");
    expect(link.rel).toBe("noopener noreferrer");
  });

  it("renders a mailto link without specified type", () => {
    const onToggle = jest.fn();
    const emailAddress = "test@example.com";
    const data: ConsistentHelpItem[] = [
      {
        title: ConsistentHelpCategory.CONTACT_EMAIL,
        description: emailAddress,
      },
    ];

    const { getByText } = render(
      <ConsistentHelpContent isExpanded={true} consistentHelpData={data} onToggle={onToggle} />,
    );

    const link = getByText(emailAddress) as HTMLAnchorElement;
    expect(link).toBeTruthy();
    expect(link.tagName.toLowerCase()).toBe("a");
    expect(link.href).toBe(`mailto:${emailAddress}`);
  });

  it("renders a URL link without specified type for SUPPORT_PAGE", () => {
    const onToggle = jest.fn();
    const url = "https://www.example.com/support/";
    const data: ConsistentHelpItem[] = [
      {
        title: ConsistentHelpCategory.SUPPORT_PAGE,
        description: url,
      },
    ];

    const { getByText } = render(
      <ConsistentHelpContent isExpanded={true} consistentHelpData={data} onToggle={onToggle} />,
    );

    const link = getByText(url) as HTMLAnchorElement;
    expect(link).toBeTruthy();
    expect(link.tagName.toLowerCase()).toBe("a");
    expect(link.href).toBe(url);
    expect(link.target).toBe("_blank");
    expect(link.rel).toBe("noopener noreferrer");
  });
});
