import { h, VNode } from "preact";
import { useTranslation } from "~/hooks/useTranslation";
import BaseIcon from "~/components/base-icon";
import * as icons from "~/components/consistent-help/assets";
import styles from "./styles.scss";
import { useStylesheet } from "~/hooks/useStylesheet";
import { BaseButton } from "~/components/base-button";

interface ConsistentHelpButtonProps {
  /** Whether the consistent help content is currently expanded */
  isExpanded: boolean;

  /** Callback to toggle the expanded state */
  onToggle: () => void;
}

/**
 * Button that toggles consistent help (ch) content visibility
 */
export function ConsistentHelpButton({ isExpanded, onToggle }: ConsistentHelpButtonProps): VNode {
  const { t, direction } = useTranslation();
  useStylesheet(styles);

  return (
    <BaseButton
      style={`direction: ${direction}`}
      className="consistent-help-toggle-button"
      aria-expanded={isExpanded}
      aria-label={isExpanded ? t("COLLAPSE_BTN_LABEL") : t("EXPAND_BTN_LABEL")}
      title={isExpanded ? t("COLLAPSE_BTN_LABEL") : t("EXPAND_BTN_LABEL")}
      onClick={onToggle}
    >
      {(isExpanded && <BaseIcon>{icons.collapseIcon}</BaseIcon>) || <BaseIcon>{icons.expandIcon}</BaseIcon>}
      {(isExpanded && <span>{t("COLLAPSE_BTN_TEXT")}</span>) || <span>{t("EXPAND_BTN_TEXT")}</span>}
    </BaseButton>
  );
}
