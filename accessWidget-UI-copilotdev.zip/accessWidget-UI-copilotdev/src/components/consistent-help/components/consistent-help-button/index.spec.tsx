import { h } from "preact";
import { render } from "~/utils/test-utils";
import { ConsistentHelpButton } from "./index";
import { fireEvent } from "@testing-library/preact";

/**
 * Tests for ConsistentHelpButton aligned with current behavior:
 * - Renders correct aria-expanded for collapsed/expanded states
 * - Calls onToggle on click
 */
describe("ConsistentHelpButton", () => {
  const mockOnToggle = jest.fn();

  beforeEach(() => {
    mockOnToggle.mockClear();
  });

  it("renders correctly when not expanded", () => {
    const { getByRole } = render(<ConsistentHelpButton isExpanded={false} onToggle={mockOnToggle} />);
    expect(getByRole("button")).toHaveAttribute("aria-expanded", "false");
  });

  it("renders correctly when expanded", () => {
    const { getByRole } = render(<ConsistentHelpButton isExpanded={true} onToggle={mockOnToggle} />);
    expect(getByRole("button")).toHaveAttribute("aria-expanded", "true");
  });

  it("calls onToggle when clicked", () => {
    const { getByRole } = render(<ConsistentHelpButton isExpanded={false} onToggle={mockOnToggle} />);
    fireEvent.click(getByRole("button"));
    expect(mockOnToggle).toHaveBeenCalledTimes(1);
  });
});
