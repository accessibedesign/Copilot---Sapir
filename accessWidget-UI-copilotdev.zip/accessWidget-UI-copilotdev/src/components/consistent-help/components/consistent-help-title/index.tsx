import { h, VNode } from "preact";
import { useStylesheet } from "~/hooks/useStylesheet";
import styles from "./styles.scss";
import { useTranslation } from "~/hooks/useTranslation";
import defaultDictionary from "~/components/consistent-help/locale/en.json";
import BaseIcon from "~/components/base-icon";
import * as icons from "~/components/consistent-help/assets";
import { CloseButton } from "~/components/close-button";

export interface ConsistentHelpTitleProps {
  /** Lead color of the widget for styling */
  leadColor: string;

  /** Callback to close the consistent help panel */
  onClose: () => void;
}

export function ConsistentHelpTitle({ leadColor, onClose }: ConsistentHelpTitleProps): VNode {
  const { t } = useTranslation(defaultDictionary);
  useStylesheet(styles, { "lead-color": leadColor });

  return (
    <div class="consistent-help-title">
      <CloseButton class="consistent-help-title__close-button" ariaLabel={t("CLOSE_BTN_LABEL")} onClick={onClose} />

      <span className="consistent-help-title__widget-icon" style={`background: ${leadColor}`} role="presentation">
        <BaseIcon>{icons.accessibilityIcon}</BaseIcon>
      </span>

      <span>{t("CONTACT_US_TITLE_TEXT")}</span>
    </div>
  );
}
