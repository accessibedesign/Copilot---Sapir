import { h } from "preact";
import { render } from "~/utils/test-utils";
import { ConsistentHelpTitle } from "./index";
import { fireEvent } from "@testing-library/preact";

/**
 * Factory for props to keep test cases tidy.
 */
function createProps(overrides?: Partial<Parameters<typeof ConsistentHelpTitle>[0]>) {
  return {
    leadColor: "#7c3aed",
    onClose: jest.fn(),
    ...overrides,
  };
}

describe("ConsistentHelpTitle", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("renders container, close button, icon wrapper, and title text", () => {
    const props = createProps();
    const { container, getByRole } = render(<ConsistentHelpTitle {...props} />);

    // Root container
    const root = container.querySelector(".consistent-help-title");
    expect(root).toBeTruthy();

    // Close button exists
    const closeBtn = container.querySelector(".consistent-help-title__close-button");
    expect(closeBtn).toBeTruthy();

    // Close is an actual button in the tree
    expect(getByRole("button")).toBeTruthy();

    // Widget icon wrapper with role="presentation"
    const iconWrapper = container.querySelector(".consistent-help-title__widget-icon") as HTMLSpanElement;
    expect(iconWrapper).toBeTruthy();
    expect(iconWrapper.getAttribute("role")).toBe("presentation");

    // Title text span is present and not empty
    const titleText = container.querySelector(
      ".consistent-help-title > span:not(.consistent-help-title__widget-icon)",
    ) as HTMLSpanElement;
    expect(titleText).toBeTruthy();
    expect((titleText.textContent || "").trim().length).toBeGreaterThan(0);
  });

  it("applies leadColor as inline background style on the icon wrapper", () => {
    const props = createProps({ leadColor: "rgb(255, 0, 0)" });
    const { container } = render(<ConsistentHelpTitle {...props} />);

    const iconWrapper = container.querySelector(".consistent-help-title__widget-icon") as HTMLSpanElement;
    expect(iconWrapper.getAttribute("style")).toContain("background: rgb(255, 0, 0)");
  });

  it("calls setIsClosed(true) when the close button is clicked", () => {
    const onClose = jest.fn();
    const props = createProps({ onClose });
    const { container } = render(<ConsistentHelpTitle {...props} />);

    const close = container.querySelector(".consistent-help-title__close-button") as HTMLElement;
    fireEvent.click(close);

    expect(onClose).toHaveBeenCalledTimes(1);
  });
});
