import { h } from "preact";
import { fireEvent, waitFor } from "@testing-library/preact";
import { render } from "~/utils/test-utils";
import { ConsistentHelp } from "./index";
import { ConsistentHelpItem, helpItemTypeMap, ConsistentHelpCategory } from "~/components/consistent-help/interfaces";

/* ------------------------- Helpers ------------------------- */

/**
 * Gets the expandable content container.
 */
function getExpandable(container: HTMLElement): HTMLDivElement {
  const el = container.querySelector(".consistent-help-expandable-content") as HTMLDivElement | null;
  if (!el) throw new Error("Expandable content not found");
  return el;
}

/**
 * Gets the toggle button via its aria-expanded attribute.
 */
function getToggle(container: HTMLElement): HTMLButtonElement {
  const btn = container.querySelector("button[aria-expanded]") as HTMLButtonElement | null;
  if (!btn) throw new Error("Toggle button not found");
  return btn;
}

/* -------------------------- Tests -------------------------- */

describe("ConsistentHelp", () => {
  it("renders structure with title, close button, toggle, and content", () => {
    const { container } = render(
      <ConsistentHelp
        consistentHelpData={[
          {
            title: ConsistentHelpCategory.CONTACT_EMAIL,
            type: helpItemTypeMap[ConsistentHelpCategory.CONTACT_EMAIL],
            description: "test@example.com",
          },
        ]}
      />,
    );

    // Header structure
    expect(container.querySelector(".consistent-help-title__widget-icon")).toBeTruthy();
    expect(container.querySelector(".consistent-help-title__close-button")).toBeTruthy();
    expect(getToggle(container as HTMLElement)).toBeTruthy();

    // Content data rendered
    const body = container.querySelector(".consistent-help-expandable-content__body") as HTMLElement;
    expect(body).toBeTruthy();
    expect(body.textContent).toContain("Email");
    const link = body.querySelector('a[href="mailto:test@example.com"]');
    expect(link).toBeTruthy();
  });

  it("applies custom leadColor to icon background", () => {
    const color = "rgb(255, 0, 0)";
    const { container } = render(<ConsistentHelp leadColor={color} />);
    const icon = container.querySelector(".consistent-help-title__widget-icon") as HTMLSpanElement;
    expect(icon).toBeTruthy();
    expect(icon.style.background).toContain(color);
  });

  it("starts collapsed by default and expands when toggled", async () => {
    const { container } = render(<ConsistentHelp />);
    const expandable = getExpandable(container as HTMLElement);
    const toggle = getToggle(container as HTMLElement);

    expect(toggle).toHaveAttribute("aria-expanded", "false");
    expect(expandable.className).not.toContain("expanded");

    fireEvent.click(toggle);

    await waitFor(() => {
      expect(toggle).toHaveAttribute("aria-expanded", "true");
      expect(expandable.className).toContain("expanded");
    });
  });

  it("respects expandedByDefault prop", () => {
    const { container } = render(<ConsistentHelp expandedByDefault />);
    const expandable = getExpandable(container as HTMLElement);
    const toggle = getToggle(container as HTMLElement);

    expect(toggle).toHaveAttribute("aria-expanded", "true");
    expect(expandable.className).toContain("expanded");
  });

  it("collapses when toggled again", async () => {
    const { container } = render(<ConsistentHelp expandedByDefault />);
    const expandable = getExpandable(container as HTMLElement);
    const toggle = getToggle(container as HTMLElement);

    expect(toggle).toHaveAttribute("aria-expanded", "true");

    fireEvent.click(toggle);

    await waitFor(() => {
      expect(toggle).toHaveAttribute("aria-expanded", "false");
      expect(expandable.className).not.toContain("expanded");
    });
  });

  it("hides the component when the close button is clicked", async () => {
    const { container } = render(<ConsistentHelp />);
    const closeButton = container.querySelector(".consistent-help-title__close-button") as HTMLButtonElement;
    expect(closeButton).toBeTruthy();

    fireEvent.click(closeButton);

    await waitFor(() => {
      const root = container.querySelector(".consistent-help") as HTMLElement;
      expect(root).toHaveStyle("display: none");
    });
  });

  it("passes consistentHelpData and isExpanded state down correctly", () => {
    const mockData: ConsistentHelpItem[] = [
      {
        title: ConsistentHelpCategory.OPERATION_HOURS,
        type: helpItemTypeMap[ConsistentHelpCategory.OPERATION_HOURS],
        description: "Reach us anytime",
      },
    ];
    const { container } = render(<ConsistentHelp consistentHelpData={mockData} expandedByDefault />);
    const content = container.querySelector(".consistent-help-expandable-content");
    expect(content).toBeTruthy();
    expect(content?.textContent).toContain("Reach us anytime");
  });
});
