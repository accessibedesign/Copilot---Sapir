/* istanbul ignore file */
import accessibilityIcon from "./accessibility-icon.svg";
import expandIcon from "./expand-icon.svg";
import collapseIcon from "./collapse-icon.svg";
import infoIcon from "./info-icon.svg";

export { accessibilityIcon, expandIcon, collapseIcon, infoIcon };
