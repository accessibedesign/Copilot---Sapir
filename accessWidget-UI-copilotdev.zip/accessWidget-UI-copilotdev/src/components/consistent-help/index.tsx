import { h, VNode } from "preact";
import { useState } from "preact/hooks";
import { useStylesheet } from "~/hooks/useStylesheet";
import styles from "./styles.scss";
import { useTranslation } from "~/hooks/useTranslation";
import defaultDictionary from "~/components/consistent-help/locale/en.json";
import {
  ConsistentHelpTitle,
  ConsistentHelpContent,
  ConsistentHelpButton,
} from "~/components/consistent-help/components";
import { ConsistentHelpItem } from "~/components/consistent-help/interfaces";

/**
 * Public props for ConsistentHelpPopover.
 */
export interface ConsistentHelpProps {
  /** The content to display when the popover is open */
  consistentHelpData?: ConsistentHelpItem[];

  /** Lead color of the widget for styling */
  leadColor?: string;

  /** Whether the popover should be open by default */
  expandedByDefault?: boolean;
}

/**
 * Responsible for rendering a consistent help popover that provides users with the customer's contact details
 * The panel is set to show when ADHD / Cognitive profiles are enabled
 */
export function ConsistentHelp({
  consistentHelpData,
  leadColor = "#1e6df2",
  expandedByDefault = false,
}: ConsistentHelpProps): VNode {
  useTranslation(defaultDictionary);
  useStylesheet(styles, { "lead-color": leadColor });

  const [isClosed, setIsClosed] = useState(false);
  const [isExpanded, setIsExpanded] = useState(expandedByDefault);

  /**
   * Toggles the expanded state of the consistent help content.
   */
  const onToggle = (): void => {
    setIsExpanded((prev) => !prev);
  };

  /**
   * Handles closing the consistent help panel, triggered via the "x" button.
   */
  const onClose = (): void => {
    setIsClosed(true);
  };

  return (
    <div className="consistent-help" style={isClosed ? { display: "none" } : {}} role="dialog" aria-modal="false">
      <div class="consistent-help__header">
        <ConsistentHelpTitle onClose={onClose} leadColor={leadColor} />
        <ConsistentHelpButton isExpanded={isExpanded} onToggle={onToggle} />
      </div>

      <ConsistentHelpContent consistentHelpData={consistentHelpData} isExpanded={isExpanded} onToggle={onToggle} />
    </div>
  );
}
