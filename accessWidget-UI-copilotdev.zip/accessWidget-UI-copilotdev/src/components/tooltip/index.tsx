import { Fragment, VNode, h } from "preact";
import styles from "./style.scss";
import { useEffect, useRef, useState } from "preact/hooks";
import {useStylesheet} from "~/hooks/useStylesheet";

export type TooltipPosition = {
  x: number;
  y: number;
};

export type TooltipProps = {
  visible?: boolean;
  position?: TooltipPosition;
  text?: string;
  fontSize?: number;
  viewport: {
    width: number;
    height: number;
  }; // the current viewport width and height that the tooltip should calculate `ammendOveflow` against
};

/**
 * checks weather the tooltip is overflowing the screen given the position and the width of the tooltip
 */
export const ammendOverflow = (
  position: TooltipPosition,
  width: TooltipPosition["x"],
  height: TooltipPosition["y"],
  viewport: TooltipProps["viewport"],
): TooltipPosition => {
  return {
    y: Math.max(height + position.y > viewport.height ? position.y - height : position.y, 5),
    x: Math.max(viewport.width - (width + position.x) < 5 ? viewport.width - width - 5 : position.x, 5),
  };
};

export const Tooltip = ({ text, position, visible, fontSize, viewport }: TooltipProps): VNode => {
  const [left, setLeft] = useState(position.x);
  const [top, setTop] = useState(position.y);
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    const { x, y } = ammendOverflow(position, ref.current.offsetWidth, ref.current.offsetHeight, viewport);
    setLeft(x);
    setTop(y);
  }, [position, viewport]);

  useStylesheet(styles);

  return (
    <Fragment>
      <span
        ref={ref}
        style={{
          top,
          left,
          fontSize,
          display: visible ? "block" : "none",
        }}
        class="tooltip"
        dangerouslySetInnerHTML={{ __html: text }}
        // this is needed since the hover element sometimes contains html and deeply nested elements (e.g. div tag with some text with img inside)
        // SECUITY-NOTE: this can be considered user-input html since it is received from host site
      />
    </Fragment>
  );
};

Tooltip.defaultProps = {
  visible: false,
  text: "",
  position: {
    x: 0,
    y: 0,
  },
  fontSize: 0,
} as TooltipProps;
