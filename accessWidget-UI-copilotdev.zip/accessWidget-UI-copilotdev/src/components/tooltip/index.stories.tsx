/** @jsx h */
import { h } from "preact";
import { Tooltip, TooltipProps } from "./index";
import { Meta, StoryFn } from "@storybook/preact";
import tooltipConfig from "~/mock/tooltip-config";
export default {
  title: "Example/Tooltip",
  component: Tooltip,
  args: tooltipConfig.data,
} as Meta<typeof Tooltip>;

const Template: StoryFn<typeof Tooltip> = (args) => <Tooltip {...(args as any)} />;

export const Default = Template.bind({});

export const NotVisible = Template.bind({});
NotVisible.args = {
  visible: false,
} as TooltipProps;

export const HtmlText = Template.bind({});
HtmlText.args = {
  text: `<div>some text</div>`,
} as TooltipProps;

export const DifferentFontSize = Template.bind({});
DifferentFontSize.args = {
  fontSize: 20,
};

export const DifferentPosition = Template.bind({});
DifferentPosition.args = {
  position: {
    x: 100,
    y: 100,
  },
} as TooltipProps;
