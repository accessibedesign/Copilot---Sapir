import { h } from "preact";
import { render } from "~/utils/test-utils";
import { Tooltip, TooltipProps, ammendOverflow } from "./index";
import { ShadowRootStateProvider } from "~/hooks/useStylesheet";

describe("Tests `Tooltip` component functionality", () => {
  it(`should show the tooltip if it receives visible:true`, () => {
    const component = render(
      <Tooltip
        visible={true}
        fontSize={22}
        position={{ x: 0, y: 0 }}
        viewport={{ width: 1000, height: 1000 }}
        text="123"
      />
    );
    const element = component.container.firstChild as HTMLElement;

    expect(element).toBeVisible();
  });

  it(`should render received plain text content`, () => {
    const component = render(
      <Tooltip
        visible={true}
        fontSize={22}
        position={{ x: 0, y: 0 }}
        viewport={{ width: 1000, height: 1000 }}
        text="123"
      />
    );
    const element = component.container.firstChild as HTMLElement;

    expect(element.textContent).toBe("123");
  });

  it(`should render received html string correctly as html content`, () => {
    render(
      <Tooltip
        visible={true}
        fontSize={22}
        position={{ x: 0, y: 0 }}
        viewport={{ width: 1000, height: 1000 }}
        text="<div>hello</div>"
      />
    );
    expect(document.querySelector("div")?.textContent).toBe("hello");
  });

  it(`should not show the tooltip if it receives visible:false`, () => {
    const component = render(
      <Tooltip
        visible={false}
        fontSize={22}
        position={{ x: 0, y: 0 }}
        viewport={{ width: 1000, height: 1000 }}
        text="123"
      />
    );
    const element = component.container.firstChild as HTMLElement;

    expect(element).not.toBeVisible();
  });

  it(`should move the tooltip to the received position and move to an updated position`, () => {
    const component = render(
      <Tooltip
        visible={true}
        fontSize={22}
        position={{ x: 200, y: 200 }}
        viewport={{ width: 1000, height: 1000 }}
        text="123"
      />
    );

    const element = component.container.firstChild as HTMLElement;

    expect(window.getComputedStyle(element).top).toBe("200px");
    expect(window.getComputedStyle(element).left).toBe("200px");

    const props: TooltipProps = {
      viewport: { width: 1000, height: 1000 },
      position: { x: 300, y: 300 },
    };
    component.rerender(
      <ShadowRootStateProvider shadowRoot={document as unknown as ShadowRoot}>
        <Tooltip {...props} />
      </ShadowRootStateProvider>
    );
    expect(window.getComputedStyle(element).top).toBe("300px");
    expect(window.getComputedStyle(element).left).toBe("300px");
  });

  it(`should ammend the position of the tooltip if it overflows viewport width`, () => {
    const data = ammendOverflow({ x: 200, y: 200 }, 500, 500, { width: 100, height: 100 });
    expect(data).toEqual({ x: 5, y: 5 });
  });

  it(`shouldnt ammend the position of the tooltip if it doesnt overflow viewport width`, () => {
    const data = ammendOverflow({ x: 50, y: 50 }, 200, 200, { width: 1000, height: 1000 });
    expect(data).toEqual({ x: 50, y: 50 });
  });
});
