import checkmark from "./images/checkmark.svg"
import display from "./images/display.svg"
import display2 from "./images/display2.svg"
import display3 from "./images/display3.svg"
import help from "./images/help.svg"
import people from "./images/people.svg"
import people2 from "./images/people2.svg"
import settings from "./images/settings.svg"
import settings2 from "./images/settings2.svg"
import wheels from "./images/wheels.svg"
import wheels2 from "./images/wheels2.svg"
import ai from "./images/ai.svg"
import star from "./images/star.svg"

export default {
    checkmark,
    display,
    display2,
    display3,
    help,
    people,
    people2,
    settings,
    settings2,
    wheels,
    wheels2,
    ai,
    star,
};