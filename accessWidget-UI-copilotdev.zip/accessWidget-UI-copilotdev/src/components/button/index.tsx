import { h, VNode } from "preact";
import { ButtonPositionYType, ButtonPositionXType, ButtonSizeType, ButtonIcon } from "./types";
import styles from "./style.scss";
import { useTranslation } from "~/hooks/useTranslation";
import Images from "./images";
import Icon from "../base-icon";
import defaultDictionary from "./locale/en.json";
import { useStylesheet } from "~/hooks/useStylesheet";
export interface Props {
  color?: string;
  active?: boolean;
  newActionAvailable?: boolean; // shows a badge next to the button when a new action is available (e.g. new content in the widget)
  visible?: boolean;
  positionY?: ButtonPositionYType;
  positionX?: ButtonPositionXType;
  size?: ButtonSizeType;
  radius?: string;
  icon?: ButtonIcon;
  offsetLeft?: number;
  offsetTop?: number;
  onInteraction?: (event: MouseEvent | FocusEvent) => void;
}
type ButtonProps = Props;
export { ButtonProps };

export const defaultButtonProps: Props = {
  visible: true,
  active: false,
  newActionAvailable: false,
  color: "lead",
  positionY: ButtonPositionYType.Bottom,
  positionX: ButtonPositionXType.Right,
  size: ButtonSizeType.Medium,
  radius: "50%",
  icon: ButtonIcon.people,
  offsetLeft: 20,
  offsetTop: 20,
  onInteraction: null,
};

const Button = function Button(props: Props): VNode {
  const { t } = useTranslation(defaultDictionary);
  useStylesheet(styles, {
    "lead-color": props.color,
    radius: props.radius,
    "offset-left": `${props.offsetLeft}px`,
    "offset-top": `${props.offsetTop}px`,
  });

  return (
    <div>
      <button
        part="acsb-trigger"
        data-testid="acsb-trigger"
        onClick={props.onInteraction}
        onMouseEnter={props.onInteraction}
        onFocus={props.onInteraction}
        className={`trigger-button ${props.visible ? "trigger-button--visible" : ""} ${props.newActionAvailable ? "trigger-button--new-action" : ""} ${props.active ? "trigger-button--actions-active" : ""}  size-${
          props.size
        } position-x-${props.positionX} position-y-${props.positionY}  `}
        aria-label={t("openWidget")}
        tabIndex={0}
      >
        <span className="icon" part="acsb-trigger-icon">
          <Icon part="acsb-trigger-icon-svg">{Images[props.icon]}</Icon>
          <span className="active-actions-icon">
            <Icon>{Images.checkmark}</Icon>
          </span>
          <span className="new-action-icon">
            <Icon>{Images.star}</Icon>
          </span>
        </span>
      </button>

    </div>
  );
};

Button.defaultProps = defaultButtonProps;

export { Button, ButtonSizeType, ButtonPositionYType, ButtonPositionXType, ButtonIcon };
