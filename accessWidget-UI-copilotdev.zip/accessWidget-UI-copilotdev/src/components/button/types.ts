/**
 * List of all available positionY values
 */
export enum ButtonPositionYType {
    Top = "top",
    Center = "center",
    Bottom = "bottom",
}

/**
 * List of all available positionY values
 */
export enum ButtonPositionXType {
    Left = "left",
    Right = "right",
}

/**
 * List of all possible Size values
 */
export enum ButtonSizeType {
    Small = "small",
    Medium = "medium",
    Big = "big",
}

/**
 * List of all possible icon values
 */
export enum ButtonIcon {
    checkmark = "checkmark",
    display = "display",
    display2 = "display2",
    display3 = "display3",
    help = "help",
    people = "people",
    people2 = "people2",
    settings = "settings",
    settings2 = "settings2",
    wheels = "wheels",
    wheels2 = "wheels2",
    ai = "ai",
    star = "star",
}