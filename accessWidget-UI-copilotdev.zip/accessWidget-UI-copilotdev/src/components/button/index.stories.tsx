/** @jsx h */
import { h } from "preact";
import { Button, ButtonPositionXType, ButtonPositionYType, ButtonSizeType } from "./index";
import { StoryFn, Meta } from "@storybook/preact";
import images from "./images";
import { SupportedLanguageCode } from "~/types";
export default {
  title: "Example/Button",
  component: Button,
  parameters: {
    actions: {
      handles: ["mouseover", "click", "focusin"],
    },
  },
  args: {
    visible: true,
    active: false,
    newActionAvailable: false,
    color: "#146ff8",
    positionY: ButtonPositionYType.Bottom,
    positionX: ButtonPositionXType.Left,
    size: ButtonSizeType.Medium,
    radius: "50%",
    icon: "people",
    offsetLeft: 20,
    offsetTop: 20,
  },
  argTypes: {
    language: { control: "select", options: Object.values(SupportedLanguageCode) },
    offsetLeft: { control: { type: "range", max: 999 } },
    offsetTop: { control: { type: "range", max: 999 } },
    size: {
      control: "radio",
      options: Object.values(ButtonSizeType),
    },
    positionX: {
      control: "radio",
      options: Object.values(ButtonPositionXType),
    },
    positionY: {
      control: "radio",
      options: Object.values(ButtonPositionYType),
    },
    icon: {
      control: "select",
      options: Object.keys(images),
    },
  },
} as Meta<typeof Button>;

const Template: StoryFn<typeof Button> = (args) => <Button {...args} />;

export const Default = Template.bind({});

export const Hidden = Template.bind({});
Hidden.args = { visible: false };

export const TopLeft = Template.bind({});
TopLeft.args = { positionY: ButtonPositionYType.Top };
export const BottomRight = Template.bind({});
BottomRight.args = { positionX: ButtonPositionXType.Right };
export const TopRight = Template.bind({});
TopRight.args = { positionY: ButtonPositionYType.Top, positionX: ButtonPositionXType.Right };

export const Big = Template.bind({});
Big.args = { size: ButtonSizeType.Big };
export const Small = Template.bind({});
Small.args = { size: ButtonSizeType.Small };

export const LessRounded = Template.bind({});
LessRounded.args = { radius: "10px" };

export const DifferentIcon = Template.bind({});
DifferentIcon.args = { icon: "wheels" };

export const DifferentColor = Template.bind({});
DifferentColor.args = { color: "red" };

export const Active = Template.bind({});
Active.args = { active: true };

export const EyeCatcherBadge = Template.bind({});
EyeCatcherBadge.args = { newActionAvailable: true };

export const ActiveAndEyeCatcherBadge = Template.bind({});
ActiveAndEyeCatcherBadge.args = { active: true, newActionAvailable: true };

