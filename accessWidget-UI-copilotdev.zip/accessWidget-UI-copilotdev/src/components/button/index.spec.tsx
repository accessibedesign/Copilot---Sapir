import { h } from "preact";
import { Button, ButtonSizeType, ButtonPositionXType, ButtonPositionYType } from "./index";
import { waitFor } from "@testing-library/dom";
import { render } from "~/utils/test-utils";
import { userEvent } from "@testing-library/user-event";

describe("Tests `Button` component functionality", () => {
  it(`should invoke the \`onClick\` prop when clicked`, async () => {
    const interaction = jest.fn();
    const component = render(<Button onInteraction={interaction} />);
    const button = await component.findByTestId("acsb-trigger");
    const event = new Event("click");
    button.dispatchEvent(event);
    expect(interaction).toHaveBeenCalled();
  });

  it(`should invoke the \`mouseEnter\` prop when entered`, async () => {
    const interaction = jest.fn();
    const component = render(<Button onInteraction={interaction} />);
    const button = await component.findByTestId("acsb-trigger");
    const event = new Event("mouseenter");
    button.dispatchEvent(event);
    expect(interaction).toHaveBeenCalled();
  });

  it(`should invoke the \`focus\` prop when focused`, async () => {
    const interaction = jest.fn();
    const component = render(<Button onInteraction={interaction} />);
    await component.findByTestId("acsb-trigger");
    await userEvent.tab();
    expect(interaction).toHaveBeenCalled();
  });

  it(`should be hidden when the \`visible\` prop is set to \`false\``, async () => {
    const component = render(<Button visible={false} />);

    const button = await component.findByTestId("acsb-trigger");

    await waitFor(() => {
      expect(button).toHaveStyle({ display: "none" });
    });
  });

  it(`should be shown when the \`visible\` prop is set to \`true\``, async () => {
    const component = render(<Button visible={true} />);
    const button = await component.findByTestId("acsb-trigger");
    await waitFor(() => {
      expect(button).toHaveStyle({ display: "inline-block" });
    });
  });

  it(`should have the correct class when the \`active\` prop is set to \`true\``, async () => {
    const component = render(<Button active={true} />);
    const button = await component.findByTestId("acsb-trigger");

    expect(button.classList.contains("trigger-button--actions-active")).toBe(true);
  });

  it(`should have the correct class when the \`active\` prop is set to \`false\``, async () => {
    const component = render(<Button active={false} />);
    const button = await component.findByTestId("acsb-trigger");

    expect(button.classList.contains("trigger-button--actions-active")).toBe(false);
  });

  it(`should have the correct class when the \`new-action\` prop is set to \`true\``, async () => {
    const component = render(<Button newActionAvailable={true} />);
    const button = await component.findByTestId("acsb-trigger");

    expect(button.classList.contains("trigger-button--new-action")).toBe(true);
  });

  it(`should have the correct class when the \`new-action\` prop is set to \`false\``, async () => {
    const component = render(<Button newActionAvailable={false} />);
    const button = await component.findByTestId("acsb-trigger");

    expect(button.classList.contains("trigger-button--new-action")).toBe(false);
  });

  for (const buttonSize of Object.values(ButtonSizeType)) {
    it(`should have the correct class when \`size\` prop is set to \`${buttonSize}\``, async () => {
      const component = render(<Button size={buttonSize} />);
      const button = await component.findByTestId("acsb-trigger");
      expect(button.classList.contains(`size-${buttonSize}`)).toBe(true);
    });
  }

  for (const buttonPositionY of Object.values(ButtonPositionYType)) {
    it(`should have the correct class when \`positionY\` prop is set to \`${buttonPositionY}\``, async () => {
      const component = render(<Button positionY={buttonPositionY} />);
      const button = await component.findByTestId("acsb-trigger");
      expect(button.classList.contains(`position-y-${buttonPositionY}`)).toBe(true);
    });
  }

  for (const buttonPositionX of Object.values(ButtonPositionXType)) {
    it(`should have the correct class when \`positionX\` prop is set to \`${buttonPositionX}\``, async () => {
      const component = render(<Button positionX={buttonPositionX} />);
      const button = await component.findByTestId("acsb-trigger");

      expect(button.classList.contains(`position-x-${buttonPositionX}`)).toBe(true);
    });
  }
});
