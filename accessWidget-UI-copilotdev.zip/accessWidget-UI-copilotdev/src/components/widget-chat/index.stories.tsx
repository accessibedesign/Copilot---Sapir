/** @jsx h */
import { Fragment, h } from "preact";
import { StoryFn, Meta } from "@storybook/preact";
import { WidgetChat, WidgetChatPosition } from ".";
import { data } from "~/mock/widget-chat-config";
import { userEvent } from "@storybook/test";
import { within } from "shadow-dom-testing-library";
import { SupportedLanguageCode } from "~/types";
import isChromatic from "chromatic/isChromatic";
import { useState } from "preact/hooks";
import { vibrate, eye, target, thought, navigation } from '~/components/widget-chat/assets/icons';

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const { onEvent, hasTransition, ...defaultData } = data;

export default {
  title: "Example/WidgetChat",
  component: WidgetChat,
  args: defaultData,
  argTypes: {
    language: { control: "select", options: Object.values(SupportedLanguageCode) },
    onEvent: { action: "onEvent" },
  },
  decorators: isChromatic()
    ? [
        (story) => {
          return (
            <Fragment>
              <style>{`
    .loader-container__item {
      animation:none !important;
    }
    `}</style>
              {story()}
            </Fragment>
          );
        },
      ]
    : [],
} as Meta<typeof WidgetChat>;

const Template: StoryFn<typeof WidgetChat> = (args) => <WidgetChat {...args} />;

export const Default = Template.bind({});
export const ChangedColor = Template.bind({});
ChangedColor.args = {
  leadColor: "#ad6344",
};
export const OpenLanguageModal = Template.bind({});
export const OpenStatementModal = Template.bind({});
export const CloseWidgetModal = Template.bind({});
const modalButtons = {
  "language-selection-button": OpenLanguageModal,
  statement: OpenStatementModal,
  "acsb-hide-popup": CloseWidgetModal,
};

Object.entries(modalButtons).forEach(([buttonId, story]) => {
  story.play = async ({ canvasElement }) => {
    const root = canvasElement;
    const canvas = within(root);
    const button = canvas.getByShadowTestId(buttonId);
    userEvent.click(button);
  };
});


export const ChangedFlag = Template.bind({});
ChangedFlag.args = {
  languageOptions: {
    en: {
      flag: "gb",
    },
  },
};

export const OpenLanguagesAlt = Template.bind({});
OpenLanguagesAlt.args = {
  languageOptions: {
    en: {
      flag: "gb",
    },
    de: {
      hidden: true,
    },
    pt: {
      flag: "br",
    },
    fr: {
      hidden: true,
    },
  },
};

OpenLanguagesAlt.play = async ({ canvasElement }) => {
  const root = canvasElement;
  const canvas = within(root);
  const button = canvas.getByShadowTestId("language-selection-button");
  userEvent.click(button);
};

export const LoadingState = Template.bind({});
LoadingState.args = {
  loading: true,
};

export const PositionedRight = Template.bind({});
PositionedRight.args = {
  position: WidgetChatPosition.RIGHT,
};

export const RTL = Template.bind({});
RTL.args = { language: "he" };

export const PositionedRightRTL = Template.bind({});
PositionedRightRTL.args = {
  position: WidgetChatPosition.RIGHT,
  language: "he",
};


const handleSendMessage = (text: string, updateState) => {
  // First, add the user message and set loading to true
  updateState((currentState) => {
    const userMsg = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date(),
      buttons: [],
    };

    const newMessages = [...currentState.state.chat.messages, userMsg];
    const newWidgetState = {
      ...currentState.state,
      chat: {
        messages: newMessages,
        loading: true
      }
    };

    if (currentState.onEvent) {
      currentState.onEvent({
        type: 'State',
        data: newWidgetState,
        source: 'ChatOnlyWidget.handleSendMessage',
      });
    }

    return { ...currentState, state: newWidgetState };
  });

  // After 2 seconds, add the assistant response and set loading to false
  setTimeout(() => {
    updateState((currentState) => {
      const exampleOperations = [
        'profile_seizure_safe',
        'profile_vision_impaired',
        'profile_adhd',
        'readable_Font',
        'hide_images',
        'highlight_links',
        'reading_guide',
        'mute_sound',
        'magnifier',
      ];

      const exampleButtons = exampleOperations.map(op => ({
        operation: op,
        onClick: () => alert(`Clicked: ${op}`),
      }));

      const shuffled = [...exampleButtons].sort(() => 0.5 - Math.random());
      const count = Math.floor(Math.random() * 5) + 1;
      const randomButtons = shuffled.slice(0, count);

      const replyMsg = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: 'This is a hardcoded reply!',
        timestamp: new Date(),
        buttons: randomButtons,
      };

      const newMessages = [...currentState.state.chat.messages, replyMsg];
      const newWidgetState = {
        ...currentState.state,
        chat: {
          messages: newMessages,
          loading: false
        }
      };

      if (currentState.onEvent) {
        currentState.onEvent({
          type: 'State',
          data: newWidgetState,
          source: 'ChatOnlyWidget.handleSendMessage',
        });
      }

      return { ...currentState, state: newWidgetState };
    });
  }, 2000); // 2 seconds delay
};

const handleProfileSelect = (profile, updateState) => {
  updateState((currentState) => {
    const newMessages = [
      ...currentState.state.chat.messages,
      {
        id: `user-${Date.now()}`,
        role: 'user',
        content: `Selected: ${profile}`,
        timestamp: new Date(),
        buttons: [],
      },
    ];
    const newWidgetState = { ...currentState.state, chat: { messages: newMessages } };

    if (currentState.onEvent) {
      currentState.onEvent({
        type: 'State',
        data: newWidgetState,
        source: 'ChatOnlyWidget.handleProfileSelect',
      });
    }

    return { ...currentState, state: newWidgetState };
  });
};

export const InteractiveChat = (args) => {
  const [state, setState] = useState(() => {
    const initialState = JSON.parse(JSON.stringify(args));
    initialState.state.chat = {
      messages: [
        {
          id: 'assistant-1',
          role: 'assistant',
          content: 'Welcome! Choose the right accessibility profile for you, or ask me anything to customize your experience.',
          timestamp: new Date(Date.now() - 120000),
          buttons: [
            {
              label: 'Seizure Safe Profile',
              description: 'Clear flashes & reduces color',
              type: "toggle",
              icon: vibrate,
              onClick: () => handleProfileSelect('Seizure Safe Profile', setState)
            },
            {
              label: 'Vision Impaired Profile',
              description: 'Enhances website\'s visuals',
              icon: eye,
              type: "toggle",
              onClick: () => handleProfileSelect('Vision Impaired Profile', setState)
            },
            {
              label: 'ADHD Friendly Profile',
              description: 'More focus & fewer distractions',
              icon: target,
                type: "toggle",
                onClick: () => handleProfileSelect('ADHD Friendly Profile', setState)
            },
            {
              label: 'Cognitive Disability Profile',
              description: 'Assists with reading & focusing',
              icon: thought,
                type: "toggle",
                onClick: () => handleProfileSelect('Cognitive Disability Profile', setState)
            },
            {
              label: 'Keyboard Navigation (Motor)',
              description: 'Use website with the keyboard',
              icon: navigation,
                type: "toggle",
                onClick: () => handleProfileSelect('Keyboard Navigation (Motor)', setState)
            }
          ]
        }
      ],
      loading: false
    };
    initialState.options.chat = {
      ...initialState.options.chat,
      onSendMessage: (text) => handleSendMessage(text, setState),
    };
    return initialState;
  });

  return <WidgetChat {...state} />;
};
InteractiveChat.args = {
  options: {
    chat: {
      hide: false,
    },
  },
  state: {
    ...defaultData.state,
    chat: {
      messages: [],
      loading: false,
    },
  }
};
