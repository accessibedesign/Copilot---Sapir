import { h } from "preact";
import { render } from "~/utils/test-utils";
import { Overlay, Styles } from "./index";
import { fireEvent } from "@testing-library/preact";

describe("Tests `Overylay` component functionality", () => {
  it(`should show overlay if 'show' prop is true`, () => {
    const component = render(<Overlay show={true} />);
    expect(component.container.firstElementChild.classList.contains("overlay--visible")).toBe(true);
  });

  it(`should attach styles prop into inline style`, () => {
    const styles: Styles = {
      position: "absolute",
      opacity: 0.7,
      backgroundColor: "red",
      zIndex: 5,
    };
    const component = render(<Overlay show={true} styles={styles} />);
    const styledContainer = component.container.firstElementChild as HTMLDivElement;
    for (const style in styles) {
      expect(styledContainer.style[style]).toBe(styles[style].toString());
    }
  });

  it(`should fire onClick callback when clicked`, () => {
    const onClick = jest.fn();
    const component = render(<Overlay show={true} onClick={onClick} />);
    const container = component.container.firstElementChild as HTMLDivElement;
    fireEvent.click(container);
    expect(onClick).toHaveBeenCalled();
  });

  it(`should render children right after main div`, () => {
    const child = <div>hello</div>;
    const component = render(<Overlay show={true}>{child}</Overlay>);
    const overlay = component.container.firstElementChild as HTMLDivElement;

    const childrenEl = overlay.nextSibling as HTMLDivElement;

    expect(childrenEl.innerHTML).toContain("hello");
  });
});
