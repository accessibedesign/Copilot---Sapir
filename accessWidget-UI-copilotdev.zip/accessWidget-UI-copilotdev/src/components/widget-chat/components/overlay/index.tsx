/* eslint-disable jsx-a11y/no-static-element-interactions */
import { ComponentChildren, Fragment, h, VNode } from "preact";
import style from "./style.scss";
import {useStylesheet} from "~/hooks/useStylesheet";

export interface Styles {
  position?: "fixed" | "absolute";
  opacity?: number | string;
  backgroundColor?: string;
  zIndex?: number;
}

interface Props {
  show: boolean;
  styles?: Styles;
  onClick?: (_e: Event) => void;
  children?: ComponentChildren;
}
export const Overlay = ({ show, styles = {}, children, onClick }: Props): VNode => {
  const { position = "absolute", opacity = 0.5, backgroundColor = "rgb(51, 51, 51)", zIndex = 2147483646 } = styles;
  useStylesheet(style);
  return (
    <Fragment>
      {/* eslint-disable-next-line jsx-a11y/click-events-have-key-events */}
      <div
        onClick={onClick}
        class={`overlay ${show ? "overlay--visible" : ""}`}
        style={{ position, opacity, backgroundColor, zIndex }}
      />
      {children}
    </Fragment>
  );
};
