import { Fragment, h, VNode } from "preact";
import { useContext } from "preact/hooks";
import { WidgetChatEventType } from "../../types";
import { WidgetChatEventEmitter } from "../../context/event-emitter";
import { CloseButton } from "../close-button";
import { LanguageSelector } from "./components/language-selector";
import { AiModeButton } from "./components/ai-mode-button";
import styles from "./style.scss";
import { useStylesheet } from "~/hooks/useStylesheet";
import { WidgetChatOptions } from "../../index";

interface WidgetChatHeaderProps {
  options?: WidgetChatOptions;
}

export function WidgetChatHeader({ options = {} }: WidgetChatHeaderProps): VNode {
  const emit = useContext(WidgetChatEventEmitter);
  useStylesheet(styles);

  const isAiModeActive = options.chat && !options.chat.hide;

  const handleAiModeToggle = () => {
    emit({
      type: WidgetChatEventType.AIMode,
      data: { enabled: !isAiModeActive }
    });
  };

  return (
    <Fragment>
      <div class="header">
        <CloseButton
          ariaLabel="CLOSE_INTERFACE"
          class="header__option header__option--left"
          onClick={() =>
            emit({
              type: WidgetChatEventType.Close,
            })
          }
        />
        <div class="header__right-group">
          <AiModeButton
            class="header__option"
            isActive={isAiModeActive}
            onClick={handleAiModeToggle}
          />
          <LanguageSelector class="header__option" />
        </div>
      </div>
    </Fragment>
  );
}
