import { h } from "preact";
import { LanguageSelection } from "./index";
import { SupportedLanguageCode } from "~/types";
import { useTranslation } from "~/hooks/useTranslation";
import defaultDictionary from "~/components/widget-chat/locale/en.json";
import { WidgetChatEventType } from "~/index.module";
import { defaultData as defaultLanguageState, LanguageStateProvider } from "~/components/widget-chat/context/language-state";
import { buildProvidedComponent, render } from "~/utils/test-utils";
import { fireEvent } from "@testing-library/preact";

describe("Tests `LanguageSelection` component functionality", () => {
  it(`should render all language buttons with corresponding flags`, async () => {
    const { t } = useTranslation(defaultDictionary);
    const component = render(
      <LanguageStateProvider value={defaultLanguageState}>
        <LanguageSelection />
      </LanguageStateProvider>
    );
    for (const [languageCodeKey] of Object.entries(SupportedLanguageCode)) {
      const button = (await component.findAllByAltText(`${t(languageCodeKey.toLocaleUpperCase())}`))[0];
      expect(button).toBeTruthy();
    }
  });

  it(`should emit selected language data and close modal on language button click`, async () => {
    const emit = jest.fn();
    const toggle = jest.fn();
    const component = buildProvidedComponent(<LanguageSelection />, { onEvent: emit, toggle });

    for (const [_, languageCodeValue] of Object.entries(SupportedLanguageCode)) {
      const button = (await component.findAllByRole(`button`)).find(
        (b) => b.getAttribute("data-language") === languageCodeValue
      );

      fireEvent.click(button);

      expect(emit).toHaveBeenCalledWith({
        type: WidgetChatEventType.Language,
        data: languageCodeValue,
      });
      expect(toggle).toHaveBeenCalledWith({ value: false });
    }
  });

  it(`should not render flag if it has 'hidden' property equal to true`, async () => {
    const hiddenLang = SupportedLanguageCode.TR;

    const component = render(
      <LanguageStateProvider value={{ ...defaultLanguageState, [hiddenLang]: { hidden: true } }}>
        <LanguageSelection />
      </LanguageStateProvider>
    );

    const button = (await component.findAllByRole(`button`)).find(
        (b) => b.getAttribute("data-language") === hiddenLang
      );

    expect(button).toBeFalsy();
  });
});
