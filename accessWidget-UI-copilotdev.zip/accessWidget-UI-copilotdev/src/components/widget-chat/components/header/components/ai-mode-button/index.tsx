import { Fragment, h, VNode } from "preact";
import styles from "./style.scss";
import { useStylesheet } from "~/hooks/useStylesheet";
import { useTranslation } from "~/hooks/useTranslation";
import BaseIcon from "~/components/base-icon";
import sparkleIcon from "~/components/widget-chat/assets/icons/sparkle.svg";
import {BaseButton} from "~/components/base-button";

interface Props {
  class?: string;
  isActive: boolean;
  onClick: () => void;
}

export function AiModeButton({ class: className, isActive, onClick }: Props): VNode {
  const { t } = useTranslation();
  useStylesheet(styles);

  return (
    <Fragment>
      <BaseButton
        onClick={onClick}
        data-testid="ai-mode-button"
        class={`ai-mode-button ${className} ${isActive ? 'ai-mode-button--active' : ''}`}
        aria-label={t(isActive ? 'AI_MODE_OFF' : 'AI_MODE_ON')}
        aria-pressed={isActive}
      >
        <div class="ai-mode-button__content">
          <BaseIcon class="ai-mode-button__icon">
            {sparkleIcon}
          </BaseIcon>
          <span class="ai-mode-button__label">AI</span>
          <div class={`ai-mode-button__toggle ${isActive ? 'ai-mode-button__toggle--active' : ''}`}>
            <div class="ai-mode-button__toggle-track">
              <div class="ai-mode-button__toggle-thumb"></div>
            </div>
          </div>
        </div>
      </BaseButton>
    </Fragment>
  );
}
