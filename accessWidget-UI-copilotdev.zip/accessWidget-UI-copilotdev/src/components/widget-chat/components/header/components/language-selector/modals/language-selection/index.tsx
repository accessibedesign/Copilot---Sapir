import { h, VNode, Fragment } from "preact";
import { SupportedLanguageCode } from "~/types";
import BaseIcon from "~/components/base-icon";
import { BaseButton } from "~/components/base-button";
import styles from "./style.scss";
import { WidgetChatEventEmitter } from "~/components/widget-chat/context/event-emitter";
import { useContext } from "preact/hooks";
import { WidgetChatEventType } from "~/components/widget-chat/types";
import { useTranslation } from "~/hooks/useTranslation";
import { ModalContext } from "~/context/modal-context";
import { LanguageStateContext } from "~/components/widget-chat/context/language-state";
import { useStylesheet } from "~/hooks/useStylesheet";

function LanguageFlag({ alt, flag }: { alt: string; flag: string }): VNode {
  return (
    <span class="language__flag">
      <BaseIcon variant="img" alt={alt} role="presentation">
        {flag}
      </BaseIcon>
    </span>
  );
}
export function LanguageSelection(): VNode {
  const { t } = useTranslation();

  const emit = useContext(WidgetChatEventEmitter);
  const { toggle } = useContext(ModalContext);
  const { flags, availableLanguages: languages } = useContext(LanguageStateContext);
  useStylesheet(styles);
  return (
    <Fragment>
      <div class="language-selection">
        <span class="language-selection__title">{t("LANGUAGE_POPUP_TITLE")}</span>
        <div class="language-selection__content">
          {Object.entries(languages).map(([languageKey, language]) => {
            return (
              <BaseButton
                key={languageKey}
                data-language={language}
                class="language"
                onClick={() => {
                  emit({
                    type: WidgetChatEventType.Language,
                    data: SupportedLanguageCode[languageKey],
                  });
                  toggle({ value: false });
                }}
              >
                <LanguageFlag flag={flags[language]} alt={t(languageKey.toLocaleUpperCase())} />
                <span class="acsb-language-text">{t(languageKey.toLocaleUpperCase())}</span>
              </BaseButton>
            );
          })}
        </div>
      </div>
    </Fragment>
  );
}
