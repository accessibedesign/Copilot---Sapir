import { Fragment, h, VNode } from "preact";
import styles from "./style.scss";
import { useContext } from "preact/hooks";
import { ModalContext } from "~/context/modal-context";
import { LanguageSelection } from "./modals/language-selection";
import BaseIcon from "~/components/base-icon";
import chevronDown from "~/components/widget-chat/assets/icons/chevron_down.svg";
import { useTranslation } from "~/hooks/useTranslation";
import { LanguageStateContext } from "~/components/widget-chat/context/language-state";
import {useStylesheet} from "~/hooks/useStylesheet";
import {BaseButton} from "~/components/base-button";

interface Props {
  class?: string;
}

export function LanguageSelector(props: Props): VNode {
  const { t, language } = useTranslation();

  const { toggle } = useContext(ModalContext);
  const { flags } = useContext(LanguageStateContext);
  const langUpper = language.toLocaleUpperCase();

  useStylesheet(styles);
  return (
    <Fragment>
      <BaseButton
        onClick={() => {
          toggle({
            content: <LanguageSelection />,
          });
        }}
        data-testid="language-selection-button"
        class={`language-selector ${props.class}`}
        aria-label={t(langUpper)}
      >
        <span class="flag">
          <BaseIcon alt={t(langUpper)} variant="img">
            {flags[language]}
          </BaseIcon>
        </span>
        <span class="text">{t(langUpper)}</span>
        <BaseIcon class="appended-icon">{chevronDown}</BaseIcon>
      </BaseButton>
    </Fragment>
  );
}
