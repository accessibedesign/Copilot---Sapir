import { h } from "preact";
import { LanguageSelector } from "./index";
import { buildProvidedComponent } from "~/utils/test-utils";
import { fireEvent } from "@testing-library/preact";

describe("Tests `LanguageSelector` component functionality", () => {
  it(`should open language selection modal on click`, () => {
    const emit = jest.fn();
    const toggle = jest.fn();
    const component = buildProvidedComponent(<LanguageSelector />, { onEvent: emit, toggle });
    const button = component.getByRole("button");
    fireEvent.click(button);

    // TODO: for some reason, this isnt working. need to find solution
    // expect(toggle).toHaveBeenCalledWith({ content: <LanguageSelection /> });
    expect(toggle).toHaveBeenCalled();
  });
});
