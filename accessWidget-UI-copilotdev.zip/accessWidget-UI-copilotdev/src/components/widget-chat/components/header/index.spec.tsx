import { h } from "preact";
import { WidgetChatHeader } from "./index";
import { WidgetChatEventType } from "../../types";
import { buildProvidedComponent } from "~/utils/test-utils";
import { fireEvent } from "@testing-library/preact";

describe("Tests `Header` component functionality", () => {
  it(`should fire close event on close button click`, () => {
    const emit = jest.fn();
    const component = buildProvidedComponent(<WidgetChatHeader />, { onEvent: emit });
    const closeButton = component.getAllByRole("button")[0];
    fireEvent.click(closeButton);

    expect(emit).toHaveBeenCalledWith({
      type: WidgetChatEventType.Close,
    });
  });
});
