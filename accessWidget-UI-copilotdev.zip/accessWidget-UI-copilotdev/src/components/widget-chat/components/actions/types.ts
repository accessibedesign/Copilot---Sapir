import { BoxElement } from './components/action-group'

export enum ProfileType {
  MOTOR = 'motor',
  BLIND = 'blind',
  ADHD = 'adhd',
  COGNITIVE = 'cognitive',
  VISION = 'vision',
  SEIZURES = 'seizures',
}

// export enum AIToolType {
//   TEXT_SIMPLIFIER = "textSimplifier",
// }

export enum BoxElementName {
  zoom = 'zoom',
  readableFont = 'readableFont',
  emphasizeTitles = 'emphasizeTitles',
  emphasizeLinks = 'emphasizeLinks',
  magnifier = 'magnifier',
  fontSize = 'fontSize',
  textAlignCenter = 'textAlignCenter',
  lineHeight = 'lineHeight',
  textAlignLeft = 'textAlignLeft',
  letterSpacing = 'letterSpacing',
  textAlignRight = 'textAlignRight',
  darkContrast = 'darkContrast',
  lightContrast = 'lightContrast',
  highContrast = 'highContrast',
  highSaturation = 'highSaturation',
  textColor = 'textColor',
  monochrome = 'monochrome',
  titleColor = 'titleColor',
  lowSaturation = 'lowSaturation',
  backgroundColor = 'backgroundColor',
  mute = 'mute',
  hideImages = 'hideImages',
  readMode = 'readMode',
  readingGuide = 'readingGuide',
  usefulLinks = 'usefulLinks',
  stopAnimations = 'stopAnimations',
  readingMask = 'readingMask',
  emphasizeHover = 'emphasizeHover',
  emphasizeFocus = 'emphasizeFocus',
  bigBlackCursor = 'bigBlackCursor',
  bigWhiteCursor = 'bigWhiteCursor',
}

export interface ActionBox {
  name: ActionBoxName
  title: string
  elements: BoxElement[]
}

export enum ActionBoxName {
  textAdjustments = 'textAdjustments',
  colorAdjustments = 'colorAdjustments',
  orientationAdjustments = 'orientationAdjustments',
}
