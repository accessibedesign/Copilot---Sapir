/**
 * Types for Chat components
 */

export enum MessageRole {
  User = "user",
  Assistant = "assistant",
}

export enum ButtonType {
  Button = "button",
  Toggle = "toggle",
}

export interface ChatButton {
  label?: string;
  icon?: string;
  description?: string;
  onClick?: (active?: boolean) => void;
  type?: ButtonType;
  active?: boolean;
  operation?: string;
  disabled?: boolean;
}

export interface ChatMessage {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: Date;
  buttons?: ChatButton[];
}

export type ChatMessages = {
    messages: ChatMessage[];
    loading?: boolean;
}

export interface ChatMessagesProps {
  messages: ChatMessage[];
  loading?: boolean;
  actions?: any;
}

export interface ChatMessageProps {
  message: ChatMessage;
}

export interface ChatInputProps {
  onSendMessage: (message: string) => void;
  disabled?: boolean;
}

export interface ChatHeaderProps {
  title: string;
  onClose: () => void;
  onReset: () => void;
  onStatement: () => void;
}

export interface ChatFooterProps {
  webAccessibilityByText: string;
  accessiBeText: string;
  learnMoreText: string;
  learnMoreLink: string;
}

export interface ChatProps {
  messages: ChatMessage[];
  onSendMessage: (msg: string) => void;
}
