import { ComponentChildren, VNode, h } from "preact";

type Props = {
  active: boolean;
  onClick?: (e?: unknown) => void;
  children?: ComponentChildren;
} & h.JSX.HTMLAttributes<HTMLDivElement>;

export function ContentButton(props: Props): VNode {
  const { onClick, active, children } = props;
  return (
    // eslint-disable-next-line jsx-a11y/no-static-element-interactions
    <div
      {...props}
      onClick={onClick}
      onKeyUp={(e) => {
        e.key === "Enter" && onClick?.(e);
      }}
      {...(onClick && { role: "switch", "aria-checked": active ? "true" : "false" })}
      // eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex
      tabIndex={0}
    >
      {children}
    </div>
  );
}
