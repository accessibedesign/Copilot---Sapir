import { h, VNode } from "preact";
import styles from './style.scss';
import { useStylesheet } from "~/hooks/useStylesheet";
import { ChatMessageProps, MessageRole } from "../../types";
import { ChatButton } from "../chat-button";
import { useTranslation } from "~/hooks/useTranslation";


/**
 * Individual chat message bubble component
 */
export const ChatMessage = ({ message, loading, actions }: ChatMessageProps & { loading?: boolean, actions?: any }): VNode => {
  useStylesheet(styles);
  const { t } = useTranslation();

  const isUser = message.role === MessageRole.User;

  const formattedTime = message.timestamp
    ? new Date(message.timestamp).toLocaleTimeString(navigator.language, { hour: '2-digit', minute: '2-digit' })
    : null;

  return (
    <div class={`chat-message-container ${isUser ? "chat-message-user-container" : "chat-message-assistant-container"}`}>
      <div class={`chat-message ${isUser ? "chat-message-user" : "chat-message-assistant"}`}>
        <div class="chat-message-content">
          <div class="chat-message-role-label">
            {isUser ? t('CHAT_MESSAGE_ROLE_USER') : <span style={{ color: 'var(--lead-color)' }}>{t('CHAT_MESSAGE_ROLE_AGENT')}</span>}
          </div>
          {message.content}
          {formattedTime && <div class="chat-message-timestamp">{formattedTime}</div>}
        </div>

        {message.buttons && message.buttons.length > 0 && (
          <div class="chat-message-buttons">
            {message.buttons
              .slice()
              .sort((a, b) => (a.type === 'toggle' ? 1 : -1))
              .map((button, index) => (
                <ChatButton
                  key={index}
                  label={button.label}
                  icon={button.icon}
                  description={button.description}
                  onClick={button.onClick}
                  type={button.type}
                  disabled={loading || button.disabled}
                  operation={button.operation}
                  actions={actions}
                />
              ))}
          </div>
        )}
      </div>
    </div>
  );
};
