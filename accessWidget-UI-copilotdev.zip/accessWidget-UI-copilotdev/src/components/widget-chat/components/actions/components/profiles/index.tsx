import { h, Fragment, VNode } from "preact";
import { Toggle } from "../toggle";
import * as icons from "~/components/widget-chat/assets/icons";
import BaseIcon from "~/components/base-icon";
import styles from "./style.scss";
import { WidgetChatEventEmitter } from "~/components/widget-chat/context/event-emitter";
import { useContext } from "preact/hooks";
import { WidgetChatEventType } from "~/components/widget-chat/types";
import { ActiveProfiles } from "./types";
import { profiles } from "./data";

import { useTranslation } from "~/hooks/useTranslation";
import { ContentButton } from "../content-button";
import { useStylesheet } from "~/hooks/useStylesheet";

interface Props {
  activeProfiles: ActiveProfiles;
}

export function Profiles({ activeProfiles }: Props): VNode {
  const emit = useContext(WidgetChatEventEmitter);
  const clickHandler = (type: string) => {
    emit({
      type: WidgetChatEventType.State,
      data: {
        profiles: { ...activeProfiles, [type]: !activeProfiles[type] },
      },
      source: type,
    });
  };
  const { t } = useTranslation();
  const isActive = (type: string) => activeProfiles[type];
  useStylesheet(styles);
  return (
    <Fragment>
      <div class="profiles">
        {Object.entries(profiles).map(([id, { type, title, message, text, icon, connected }]) => {
          const active = isActive(type);
          return (
            <ContentButton
              onClick={() => clickHandler(type)}
              active={active}
              data-test={id}
              class={`profile profile-${id} ${active ? "profile--active" : ""}`}
              key={id}
            >
              <div class="profile-toggle">
                <Toggle active={active} />
              </div>
              <div class="profile-content">
                <span class="profile-content__name">{t(title)}</span>
                <span class="profile-content__text">{t(text)}</span>
                <div class="profile-content__icon">
                  <BaseIcon class="icon">{icon}</BaseIcon>
                </div>
              </div>

              <div class="profile-description" {...(active ? {} : { "aria-hidden": "true" })}>
                {/* eslint-disable-next-line react/no-danger */}
                <div dangerouslySetInnerHTML={{ __html: t(message) }} />
              </div>
              {connected && (
                <div class="profile-connected-icon">
                  <BaseIcon class="icon">{icons.chain}</BaseIcon>
                </div>
              )}
            </ContentButton>
          );
        })}
      </div>
    </Fragment>
  );
}
