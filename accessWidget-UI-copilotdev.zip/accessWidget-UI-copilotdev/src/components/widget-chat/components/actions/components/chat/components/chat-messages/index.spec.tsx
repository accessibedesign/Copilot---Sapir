import { h } from "preact";
import { render } from "~/utils/test-utils";
import { screen } from "@testing-library/preact";
import { ChatMessages } from "./index";
import {MessageRole} from "~/components/widget-chat/components/actions/components/chat/types";

describe("ChatMessages", () => {
  beforeEach(() => {
    window.HTMLElement.prototype.scrollIntoView = jest.fn();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it("renders empty state when no messages", () => {
    render(<ChatMessages messages={[]} />);
    expect(screen.getByText("Start a conversation...")).toBeInTheDocument();
  });

  it("renders a list of messages", () => {
    const messages = [
      {
        id: "1",
        role: MessageRole.User,
        content: "Hello!",
        timestamp: new Date(),
      },
      {
        id: "2",
        role: MessageRole.Assistant,
        content: "Hi there!",
        timestamp: new Date(),
      },
    ];
    render(<ChatMessages messages={messages} />);
    expect(screen.getByText("Hello!")).toBeInTheDocument();
    expect(screen.getByText("Hi there!")).toBeInTheDocument();
  });

  it("calls scrollIntoView when messages change", () => {
    const messages = [
      {
        id: "1",
        role: MessageRole.User,
        content: "Test message",
        timestamp: new Date(),
      },
    ];
    render(<ChatMessages messages={messages} />);
    expect(window.HTMLElement.prototype.scrollIntoView).toHaveBeenCalled();
  });
});
