import { h } from "preact";
import { render } from "~/utils/test-utils";
import { ContentButton } from "./index";
import { fireEvent } from "@testing-library/preact";
describe("Tests `ContentButton` component functionality", () => {
  const interactions = {
    click: new MouseEvent("click"),
    enter: new KeyboardEvent("keyup", { key: "Enter" }),
  };

  const onClick = jest.fn();
  const component = render(<ContentButton onClick={onClick} active={false} />);
  const element = component.container.firstChild as HTMLElement;
  for (const [key, event] of Object.entries(interactions)) {
    it(`should call onClick callback ${key} interaction is fired`, () => {
      fireEvent(element, event);
      expect(onClick).toHaveBeenCalled();
    });
  }
});
