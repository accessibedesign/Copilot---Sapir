import { Fragment, h, VNode } from "preact";
import BaseIcon from "~/components/base-icon";
import styles from "./style.scss";
import { WidgetChatEventEmitter } from "~/components/widget-chat/context/event-emitter";
import { useContext } from "preact/hooks";
import { WidgetChatEventType } from "~/components/widget-chat/types";
import { ActiveAITools, AIToolState } from "./types";
import { aiTools } from "./data";
import { useTranslation } from "~/hooks/useTranslation";
import { ContentButton } from "../content-button";
import { useStylesheet } from "~/hooks/useStylesheet";

interface Props {
  activeAITools: ActiveAITools;
}

export function AITools({ activeAITools }: Props): VNode {
  const emit = useContext(WidgetChatEventEmitter);
  const clickHandler = (type: string) => {

    const currentState: AIToolState = activeAITools[type];
    let newState: AIToolState;
    switch (currentState) {
      case "on":
        newState = "off";
        break;
      case undefined:
      case "off":
        newState = "on";
        break;
      case "disabled":
        newState = "disabled"
    }

    emit({
      type: WidgetChatEventType.State,
      data: { aiTools: { ...activeAITools, [type]: newState} },
      source: type,
    });
  };
  const { t } = useTranslation();
  const isActive = (type: string) => activeAITools[type] === "on";

  useStylesheet(styles);

  return (
    <Fragment>
      <div class="aitools">
        {Object.entries(aiTools).map(([id, { type, shortcut, icon_off, icon_on, title, text, dynamic_content }]) => {
          const active = isActive(type);

          return (
            <ContentButton
              onClick={() => clickHandler(type)}
              active={active}
              data-test={id}
              class={`aitool aitool-${id} ${active ? "aitool--active" : ""}`}
              key={id}
            >
              <div class="aitool-content">
                {active ? <BaseIcon class="icon">{icon_on}</BaseIcon> : <BaseIcon class="icon">{icon_off}</BaseIcon>}

                <div class="aitool-content__information">
                  <div class="aitool-content__information__title">
                    <span class="aitool-content__information__title__name">{t(title)}</span>
                    <span class="aitool-content__information__title__shortcut">{shortcut}</span>
                  </div>
                  <span class="aitool-content__information__text">{t(text)}</span>
                </div>
              </div>
              {dynamic_content && h(dynamic_content, { activeAITools, active })}
            </ContentButton>
          );
        })}
      </div>
    </Fragment>
  );
}
