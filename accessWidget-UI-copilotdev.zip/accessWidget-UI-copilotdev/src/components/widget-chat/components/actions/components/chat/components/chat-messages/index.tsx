import { h, VNode } from "preact";
import { useEffect, useRef } from "preact/hooks";
import { ChatMessage } from "../chat-message";
import { ChatLoader } from "../chat-loader";
import styles from "./style.scss";
import {useStylesheet} from "~/hooks/useStylesheet";
import {ChatMessagesProps} from "../../types";

/**
 * Scrollable chat messages list component
 */
export const ChatMessages = (props: ChatMessagesProps): VNode => {
  useStylesheet(styles);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth", block: "end" });
    }
  }, [props.messages, props.loading]);

  return (
    <div className="chat-messages" style={{overflowY: 'auto', flex: 1, minHeight: 0, maxHeight: '100%'}}>
      {props.messages.length === 0 ?
          <div className="chat-messages-empty">No messages yet...</div>
          :
          props.messages.map((message) => <ChatMessage key={message.id} message={message} loading={props.loading} actions={props.actions} />)}
      {props.loading && <ChatLoader />}
      <div ref={messagesEndRef} />
    </div>
  );
};
