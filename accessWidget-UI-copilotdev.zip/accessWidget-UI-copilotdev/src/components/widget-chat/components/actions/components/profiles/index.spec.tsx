import { h } from "preact";
import { Profiles } from "./index";
import { render } from "~/utils/test-utils";
import { WidgetChatEventEmitter } from "~/components/widget-chat/context/event-emitter";
import { WidgetChatEventType } from "~/components/widget-chat/types";
import { ProfileType } from "./types";
import { profiles } from "./data";
import { fireEvent } from "@testing-library/preact";

describe("Tests `Header` component functionality", () => {
  it(`should state change event on profile button click`, async () => {
    const activeProfiles = {
      [ProfileType.SEIZURES]: true,
      [ProfileType.ADHD]: true,
      [ProfileType.BLIND]: true,
      [ProfileType.MOTOR]: true,
    };
    const emit = jest.fn();
    const component = render(
      <WidgetChatEventEmitter.Provider value={emit}>
        <Profiles activeProfiles={activeProfiles} />
      </WidgetChatEventEmitter.Provider>
    );
    const profileButtons = component.container.querySelectorAll(".profile");

    profileButtons.forEach((button) => {
      fireEvent.click(button);
      const type = profiles[button.getAttribute("data-test") as ProfileType].type;
      expect(emit).toHaveBeenCalledWith({
        type: WidgetChatEventType.State,
        data: {
          profiles: { ...activeProfiles, [type]: !activeProfiles[type] },
        },
        source: type,
      });
    });
  });
});
