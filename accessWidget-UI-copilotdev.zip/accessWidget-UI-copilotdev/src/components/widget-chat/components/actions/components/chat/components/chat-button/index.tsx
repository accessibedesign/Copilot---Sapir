import { h } from 'preact';
import { useCallback } from 'preact/hooks';
import styles from './style.scss';
import { useStylesheet } from '~/hooks/useStylesheet';
import BaseIcon from '~/components/base-icon';
import { ContentButton } from '~/components/widget-chat/components/actions/components/content-button';
import { Toggle } from '~/components/widget-chat/components/actions/components/toggle';
import { ButtonType } from '../../types';
import {
  vibrate, eye, target, thought, navigation, font, hide, links, heading, focus, reading, keyboard, reset, mute, magnifier, overlay
} from '~/components/widget/assets/icons';

enum ProfileOperation {
  SEIZURES_PROFILE = "profile_seizure_safe",
  VISION_PROFILE = "profile_vision_impaired",
  ADHD_PROFILE = "profile_adhd",
  COGNITIVE_PROFILE = "profile_cognitive",
  MOTOR_PROFILE = "profile_keyboard_nav",
  SCREEN_READER = "profile_screen_reader",
}

enum SimpleAdjustmentOperation {
  READABLE_FONT = "readable_Font",
  HIDE_IMAGES = "hide_images",
  EMPHASIZE_LINKS = "highlight_links",
  EMPHASIZE_TITLES = "highlight_titles",
  EMPHASIZE_HOVER = "highlight_hover",
  EMPHASIZE_FOCUS = "highlight_focus",
  READING_GUIDE = "reading_guide",
  READING_MASK = "reading_mask",
  READ_MODE = "read_mode",
  STOP_ANIMATIONS = "stop_animations",
  MUTE = "mute_sound",
  MAGNIFIER = "magnifier",
}

interface ChatButtonProps {
  label?: string;
  icon?: string;
  description?: string;
  onClick?: (active?: boolean) => void;
  type?: ButtonType;
  disabled?: boolean;
  operation?: string;
  actions?: any;
}

export const WIDGET_OPERATION_BUTTON_MAP: { [key: string]: { label: string; icon?: string; description?: string; type?: ButtonType } } = {
  [ProfileOperation.SEIZURES_PROFILE]: { label: "Seizure Safe Profile", icon: vibrate, description: "Clear flashes & reduces color", type: ButtonType.Toggle },
  [ProfileOperation.VISION_PROFILE]: { label: "Vision Impaired Profile", icon: eye, description: "Enhances website's visuals", type: ButtonType.Toggle },
  [ProfileOperation.ADHD_PROFILE]: { label: "ADHD Friendly Profile", icon: target, description: "More focus & fewer distractions", type: ButtonType.Toggle },
  [ProfileOperation.COGNITIVE_PROFILE]: { label: "Cognitive Disability Profile", icon: thought, description: "Assists with reading & focusing", type: ButtonType.Toggle },
  [ProfileOperation.MOTOR_PROFILE]: { label: "Keyboard Navigation (Motor)", icon: navigation, description: "Use website with the keyboard", type: ButtonType.Toggle },
  [ProfileOperation.SCREEN_READER]: { label: "Screen Reader", icon: navigation, type: ButtonType.Toggle },
  [SimpleAdjustmentOperation.READABLE_FONT]: { label: "Readable Font", icon: font, description: "Use a font that's easier to read", type: ButtonType.Toggle },
  [SimpleAdjustmentOperation.HIDE_IMAGES]: { label: "Hide Images", icon: hide, description: "Remove images from the page", type: ButtonType.Toggle },
  [SimpleAdjustmentOperation.EMPHASIZE_LINKS]: { label: "Highlight Links", icon: links, description: "Make links more visible", type: ButtonType.Toggle },
  [SimpleAdjustmentOperation.EMPHASIZE_TITLES]: { label: "Highlight Titles", icon: heading, description: "Make headings stand out", type: ButtonType.Toggle },
  [SimpleAdjustmentOperation.EMPHASIZE_HOVER]: { label: "Highlight Hover", icon: focus, description: "Highlight elements on hover", type: ButtonType.Toggle },
  [SimpleAdjustmentOperation.EMPHASIZE_FOCUS]: { label: "Highlight Focus", icon: focus, description: "Highlight focused elements", type: ButtonType.Toggle },
  [SimpleAdjustmentOperation.READING_GUIDE]: { label: "Reading Guide", icon: reading, description: "Show a horizontal reading guide", type: ButtonType.Toggle },
  [SimpleAdjustmentOperation.READING_MASK]: { label: "Reading Mask", icon: overlay, description: "Dim the page except for a reading area", type: ButtonType.Toggle },
  [SimpleAdjustmentOperation.READ_MODE]: { label: "Read Mode", icon: keyboard, description: "Simplify layout for easier reading", type: ButtonType.Toggle },
  [SimpleAdjustmentOperation.STOP_ANIMATIONS]: { label: "Stop Animations", icon: reset, description: "Pause or stop all animations", type: ButtonType.Toggle },
  [SimpleAdjustmentOperation.MUTE]: { label: "Mute Sounds", icon: mute, description: "Mute all sounds on the page", type: ButtonType.Toggle },
  [SimpleAdjustmentOperation.MAGNIFIER]: { label: "Magnifier", icon: magnifier, description: "Zoom in on parts of the page", type: ButtonType.Toggle },
};

export const ChatButton = (props: ChatButtonProps) => {
  useStylesheet(styles);
  const { operation, label, icon, description, type, onClick, disabled = false, actions } = props;

  let mapLabel, mapIcon, mapDescription, mapType;
  if (operation && WIDGET_OPERATION_BUTTON_MAP[operation]) {
    mapLabel = WIDGET_OPERATION_BUTTON_MAP[operation].label;
    mapIcon = WIDGET_OPERATION_BUTTON_MAP[operation].icon;
    mapDescription = WIDGET_OPERATION_BUTTON_MAP[operation].description;
    mapType = WIDGET_OPERATION_BUTTON_MAP[operation].type;
  }

  const finalLabel = label ?? mapLabel;
  const finalIcon = icon ?? mapIcon;
  const finalDescription = description ?? mapDescription;
  const finalType = type ?? mapType ?? ButtonType.Button;

  const operationToActionName: Record<string, string> = {
    "profile_seizure_safe": "seizuresProfile",
    "profile_vision_impaired": "visionProfile",
    "profile_adhd": "adhdProfile",
    "profile_cognitive": "cognitiveProfile",
    "profile_keyboard_nav": "motorProfile",
    "profile_screen_reader": "motorProfile", // as in executeActions
    "readable_Font": "readableFont",
    "hide_images": "hideImages",
    "highlight_links": "emphasizeLinks",
    "highlight_titles": "emphasizeTitles",
    "highlight_hover": "emphasizeHover",
    "highlight_focus": "emphasizeFocus",
    "reading_guide": "readingGuide",
    "reading_mask": "readingMask",
    "read_mode": "readMode",
    "stop_animations": "stopAnimations",
    "mute_sound": "mute",
    "magnifier": "magnifier",
  };

  const actionName = operation ? operationToActionName[operation] : undefined;

  const getIsActive = () => {
    if (!actionName || !actions) {
      return false;
    }
    for (const group in actions) {
      if (Object.prototype.hasOwnProperty.call(actions[group], actionName)) {
        return actions[group][actionName] === true;
      }
    }
    return false;
  };

  const isActive = getIsActive();

  const handleClick = useCallback(() => {
    if (disabled) return;
    if (finalType === ButtonType.Toggle) {
      onClick?.(!isActive);
    } else {
      onClick?.();
    }
  }, [onClick, finalType, isActive, disabled]);

  const isProfileButton = finalIcon && finalDescription;

  if (finalType === ButtonType.Toggle) {
    return (
      <div
        class={`chat-button chat-button--toggle${disabled ? ' chat-button--disabled' : ''}`}
        onClick={handleClick}
        role="button"
        tabIndex={disabled ? -1 : 0}
        aria-disabled={disabled}
        onKeyUp={(e) => !disabled && e.key === 'Enter' && handleClick()}
      >
        {finalIcon && (
          <div class="chat-button__icon-wrapper">
            <div class="chat-button__icon">
              {finalIcon.startsWith('<svg') ? <BaseIcon>{finalIcon}</BaseIcon> : <span>{finalIcon}</span>}
            </div>
          </div>
        )}
        <div class="chat-button__content">
          <span class="chat-button__label">{finalLabel}</span>
          {finalDescription && <span class="chat-button__description">{finalDescription}</span>}
        </div>
        <Toggle active={isActive} />
      </div>
    );
  }

  return (
    <ContentButton
      class={`chat-button ${isProfileButton ? 'chat-button--profile' : 'chat-button--simple'}${disabled ? ' chat-button--disabled' : ''}`}
      onClick={handleClick}
      active={isActive}
      tabIndex={disabled ? -1 : 0}
      aria-disabled={disabled}
      disabled={disabled}
    >
      {finalIcon && (
        <div class="chat-button__icon-wrapper">
          <div class="chat-button__icon">
            {finalIcon.startsWith('<svg') ? <BaseIcon>{finalIcon}</BaseIcon> : <span>{finalIcon}</span>}
          </div>
        </div>
      )}
      <div class="chat-button__content">
        <span class="chat-button__label">{finalLabel}</span>
        {finalDescription && <span class="chat-button__description">{finalDescription}</span>}
      </div>
    </ContentButton>
  );
};
