/* eslint-disable @typescript-eslint/no-empty-function */
import { h } from "preact";
import { Color, ColorPicker } from "./index";
import { render } from "~/utils/test-utils";
import { fireEvent } from "@testing-library/preact";

describe("Tests `ColorPicker` component functionality", () => {
  it(`should fire onchange event for each color button click`, async () => {
    const emit = jest.fn();
    const component = render(<ColorPicker activeColor={Color.Red} onChange={emit} />);
    const colorButtons = (await component.findAllByRole("button")).filter((button) => button.getAttribute("data-test"));
    colorButtons.forEach((button) => {
      fireEvent.click(button);
      const color = button.getAttribute("data-test");

      expect(emit).toHaveBeenCalledWith(color);
    });
  });
  it(`should have active class on activeColor button`, async () => {
    const activeColor = Color.Red;
    const component = render(<ColorPicker activeColor={activeColor} onChange={() => {}} />);
    const colorButtons = (await component.findAllByRole("button")).filter((button) => button.getAttribute("data-test"));
    const activeButton = colorButtons.find((button) => button.getAttribute("data-test") === activeColor);
    expect(activeButton.classList.contains("color-picker__selection--active")).toBe(true);
  });

  it(`should fire empty onChange event on cancel button click`, async () => {
    const emit = jest.fn();
    const component = render(<ColorPicker activeColor={Color.Red} onChange={emit} />);
    const colorButtons = component.getAllByRole("button");
    const cancelButton = colorButtons[colorButtons.length - 1];
    fireEvent.click(cancelButton);
    expect(emit).toHaveBeenCalled();
  });
});
