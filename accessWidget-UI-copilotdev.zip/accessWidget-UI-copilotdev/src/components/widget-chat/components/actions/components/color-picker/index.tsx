import { h, VNode, Fragment } from "preact";
import { useTranslation } from "~/hooks/useTranslation";
import { BaseButton } from "../../../base-button";
import styles from "./style.scss";
import {useStylesheet} from "~/hooks/useStylesheet";

export enum Color {
  "Blue" = "#0076B4",
  "Purple" = "#7A549C",
  "Red" = "#C83733",
  "Orange" = "#D07021",
  "Teal" = "#26999F",
  "Green" = "#4D7831",
  "White" = "#ffffff",
  "Black" = "#000000",
}
interface Props {
  activeColor: Color;
  onChange: (color?: Color) => void;
}

export function ColorPicker({ activeColor, onChange }: Props): VNode {
  const { t } = useTranslation();
  useStylesheet(styles);
  return (
    <Fragment>
      <div class="color-picker">
        {Object.entries(Color).map(([colorName, color]) => (
          <BaseButton
            key={colorName}
            data-test={color}
            class={`color-picker__selection ${activeColor === color ? "color-picker__selection--active" : ""}`}
            aria-label={`${t("CHANGE_COLOR_TO")} ${colorName}`}
            style={`background-color: ${color}`}
            onClick={() => onChange(color)}
          />
        ))}
        <BaseButton class="color-picker__cancel" onClick={() => onChange()}>
          {t("CANCEL")}
        </BaseButton>
      </div>
    </Fragment>
  );
}
