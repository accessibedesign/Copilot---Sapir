import * as icons from "~/components/widget-chat/assets/icons";
import { Profile, ProfileType } from "./types";

export const profiles: Record<ProfileType, Profile> = {
  [ProfileType.SEIZURES]: {
    type: ProfileType.SEIZURES,
    icon: icons.vibrate,
    title: "PROFILE_SEIZURES_TITLE",
    text: "PROFILE_SEIZURES_TEXT",
    message: "PROFILE_SEIZURES_MESSAGE",
  },
  [ProfileType.VISION]: {
    type: ProfileType.VISION,
    icon: icons.eye,
    title: "PROFILE_VISION_TITLE",
    text: "PROFILE_VISION_TEXT",
    message: "PROFILE_VISION_MESSAGE",
  },
  [ProfileType.ADHD]: {
    type: ProfileType.ADHD,
    icon: icons.target,
    title: "PROFILE_ADHD_TITLE",
    text: "PROFILE_ADHD_TEXT",
    message: "PROFILE_ADHD_MESSAGE",
  },
  [ProfileType.COGNITIVE]: {
    type: ProfileType.COGNITIVE,
    icon: icons.thought,
    title: "PROFILE_COGNITIVE_TITLE",
    text: "PROFILE_COGNITIVE_TEXT",
    message: "PROFILE_COGNITIVE_MESSAGE",
  },
  [ProfileType.MOTOR]: {
    type: ProfileType.MOTOR,
    title: "PROFILE_MOTOR_TITLE",
    text: "PROFILE_MOTOR_TEXT",
    icon: icons.navigation,
    message: "PROFILE_MOTOR_MESSAGE",
  },
  [ProfileType.BLIND]: {
    icon: icons.voice,
    connected: true,
    type: ProfileType.MOTOR,
    title: "PROFILE_BLIND_TITLE",
    text: "PROFILE_BLIND_TEXT",
    message: "PROFILE_BLIND_MESSAGE",
  },
};
