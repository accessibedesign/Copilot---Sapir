import { h } from "preact";
import { render } from "~/utils/test-utils";
import { Toggle } from "./index";
describe("Tests `Toggle` component functionality", () => {
  const activeValues = [true, false];
  for (const value of activeValues) {
    it(`should have 'toggle--active' if 'active' prop is true and and not if its false`, () => {
      const component = render(<Toggle active={value} />);
      const element = component.container.firstChild as HTMLElement;
      expect(element.classList.contains("toggle--active")).toBe(value);
    });
  }
});
