import { VNode, h, Fragment } from "preact";
import styles from "./style.scss";

import { useTranslation } from "~/hooks/useTranslation";
import {useStylesheet} from "~/hooks/useStylesheet";

interface Props {
  active: boolean;
}

export function Toggle({ active }: Props): VNode {
  const { t } = useTranslation();
    useStylesheet(styles);
  return (
    <Fragment>
      <div class={`toggle ${active ? "toggle--active" : ""}`} aria-hidden="true">
        <span class="toggle__option">{t("OFF")}</span>
        <span class="toggle__option toggle__option--on">{t("ON")}</span>
      </div>
    </Fragment>
  );
}
