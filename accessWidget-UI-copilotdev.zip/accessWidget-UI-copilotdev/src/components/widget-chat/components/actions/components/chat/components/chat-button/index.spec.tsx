import { h } from 'preact';
import { render, screen, fireEvent } from '@testing-library/preact';
import { ChatButton } from './index';

describe('ChatButton', () => {
  it('renders a simple button with a label', () => {
    const handleClick = jest.fn();
    render(<ChatButton label="Simple Button" onClick={handleClick} />);
    const button = screen.getByRole('button', { name: 'Simple Button' });
    expect(button).toBeInTheDocument();
    fireEvent.click(button);
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it('renders a profile button with label, icon, and description', () => {
    const handleClick = jest.fn();
    render(
      <ChatButton
        label="Profile Button"
        icon="path/to/icon.svg"
        description="A detailed description"
        onClick={handleClick}
      />
    );
    const button = screen.getByRole('button', { name: 'Profile Button A detailed description' });
    expect(button).toBeInTheDocument();
    expect(screen.getByText('Profile Button')).toBeInTheDocument();
    expect(screen.getByText('A detailed description')).toBeInTheDocument();
    expect(screen.getByRole('img', { hidden: true })).toHaveAttribute('src', 'path/to/icon.svg');
    fireEvent.click(button);
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it('does not call onClick if button is disabled (not explicitly supported by ChatButtonProps yet)', () => {
    // Current ChatButtonProps does not have a disabled prop, so this test would be for future expansion
    // For now, we test that onClick is called when enabled.
    const handleClick = jest.fn();
    render(<ChatButton label="Clickable Button" onClick={handleClick} />);
    const button = screen.getByRole('button', { name: 'Clickable Button' });
    fireEvent.click(button);
    expect(handleClick).toHaveBeenCalledTimes(1);
  });
});
