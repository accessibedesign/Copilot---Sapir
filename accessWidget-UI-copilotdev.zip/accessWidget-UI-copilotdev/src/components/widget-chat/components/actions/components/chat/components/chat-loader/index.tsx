import { h, Fragment } from 'preact';
import { useStylesheet } from '~/hooks/useStylesheet';
import styles from './style.scss';

export const ChatLoader = () => {
  useStylesheet(styles);

  return (
    <Fragment>
      <div className="chat-loader">
        <div className="chat-loader__message">
          <div className="chat-loader__dots">
            <div className="chat-loader__dot" />
            <div className="chat-loader__dot" />
            <div className="chat-loader__dot" />
          </div>
        </div>
      </div>
    </Fragment>
  );
};
