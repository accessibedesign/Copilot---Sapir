import { h } from "preact";
import { render } from "~/utils/test-utils";
import { fireEvent, screen } from "@testing-library/dom";
import { jest } from "@jest/globals";
import {ChatInput} from "./index";

describe("ChatInput", () => {
    it("renders input and send button with correct attributes", () => {
        render(<ChatInput onSendMessage={() => {return;}} />);

        const input = screen.getByLabelText("Chat message input") as HTMLInputElement;
        const button = screen.getByLabelText("Send message") as HTMLButtonElement;

        expect(input).toBeTruthy();
        expect(button).toBeTruthy();
        // initial state: empty input => send button disabled
        expect(button.disabled).toBe(true);
    });

    it("calls onSendMessage on click with trimmed value and clears input", () => {
        const onSendMessage = jest.fn();
        render(<ChatInput onSendMessage={onSendMessage} />);

        const input = screen.getByLabelText("Chat message input") as HTMLInputElement;
        const button = screen.getByLabelText("Send message") as HTMLButtonElement;

        fireEvent.input(input, { target: { value: "  hello world  " } });
        expect(button.disabled).toBe(false);

        fireEvent.click(button);

        expect(onSendMessage).toHaveBeenCalledTimes(1);
        expect(onSendMessage).toHaveBeenCalledWith("hello world");
        expect(input.value).toBe("");
        // after send, button should be disabled again
        expect(button.disabled).toBe(true);
    });

    it("sends message when pressing Enter (without Shift)", () => {
        const onSendMessage = jest.fn();
        render(<ChatInput onSendMessage={onSendMessage} />);

        const input = screen.getByLabelText("Chat message input") as HTMLInputElement;

        fireEvent.input(input, { target: { value: "enter message" } });
        fireEvent.keyPress(input, { key: "Enter", code: "Enter", charCode: 13 });

        expect(onSendMessage).toHaveBeenCalledTimes(1);
        expect(onSendMessage).toHaveBeenCalledWith("enter message");
        expect(input.value).toBe("");
    });

    it("does not send when component is disabled", () => {
        const onSendMessage = jest.fn();
        render(<ChatInput onSendMessage={onSendMessage} disabled={true} />);

        const input = screen.getByLabelText("Chat message input") as HTMLInputElement;
        const button = screen.getByLabelText("Send message") as HTMLButtonElement;

        fireEvent.input(input, { target: { value: "should not send" } });

        // button must remain disabled because component is disabled
        expect(button.disabled).toBe(true);

        fireEvent.click(button);
        fireEvent.keyPress(input, { key: "Enter", code: "Enter", charCode: 13 });

        expect(onSendMessage).not.toHaveBeenCalled();
    });
});
