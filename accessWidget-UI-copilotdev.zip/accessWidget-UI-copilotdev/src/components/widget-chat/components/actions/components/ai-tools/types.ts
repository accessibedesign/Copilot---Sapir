import { FunctionComponent } from "preact";

export enum AIToolType {
  TEXT_SIMPLIFIER = "textSimplifier",
}

export enum State {
  ON = "on",
  OFF = "off",
  DISABLED = "disabled",
}

export type AIToolState = `${State}`;

export interface AITool {
  type: AIToolType;
  shortcut: string;
  icon_on: string;
  icon_off: string;
  title: string;
  text: string;
  dynamic_content?: FunctionComponent<{ activeAITools: ActiveAITools, active: boolean }>;
}

export type ActiveAITools = { [key in AIToolType]?: AIToolState };
