import { AITool, AIToolType } from "./types";
import * as icons from "~/components/widget-chat/assets/icons";
import {
  TextSimplifierToolComponent
} from "./components/text-simplifier";

export const aiTools: Record<AIToolType, AITool> = {
  [AIToolType.TEXT_SIMPLIFIER]: {
    type: AIToolType.TEXT_SIMPLIFIER,
    shortcut: "CTRL + E",
    icon_on: icons.textSimplifierOn,
    icon_off: icons.textSimplifierOff,
    title: "TEXT_SIMPLIFIER_TITLE",
    text: "TEXT_SIMPLIFIER_TEXT",
    dynamic_content: TextSimplifierToolComponent,
  },
};
