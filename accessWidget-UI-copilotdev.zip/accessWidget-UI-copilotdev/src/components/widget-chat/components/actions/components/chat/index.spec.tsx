import { h } from "preact";
import { render } from "~/utils/test-utils";
import { fireEvent, screen } from "@testing-library/preact";
import { Chat } from "./index";
import { MessageRole } from "./types";

describe("Chat", () => {
    beforeEach(() => {
        window.HTMLElement.prototype.scrollIntoView = jest.fn();
    });

    const messages = [
        {
            id: '1',
            role: MessageRole.Assistant,
            content: 'Welcome!',
            timestamp: new Date(),
            buttons: [
                { label: 'Profile 1', description: 'Description 1' },
                { label: 'Profile 2' },
            ]
        }
    ];

    it("renders initial messages, buttons, and input", () => {
        render(<Chat messages={messages} onSendMessage={() => {}} />);

        expect(screen.getByText("Welcome!")).toBeInTheDocument();
        expect(screen.getByText("Profile 1")).toBeInTheDocument();
        expect(screen.getByText("Description 1")).toBeInTheDocument();
        expect(screen.getByText("Profile 2")).toBeInTheDocument();
        expect(screen.getByRole("textbox")).toBeInTheDocument();
    });

    it("sends a message and adds it to the message list", async () => {
        render(<Chat messages={messages} onSendMessage={() => {}} />);

        const input = screen.getByRole("textbox");
        const sendButton = screen.getByRole("button", { name: /send/i });

        fireEvent.input(input, { target: { value: "Test message" } });
        fireEvent.click(sendButton);

        expect(screen.getByText("Test message")).toBeInTheDocument();
    });

    it("disables send button when input is empty", () => {
        render(<Chat messages={[]} onSendMessage={() => {}} />);
        const sendButton = screen.getByRole("button", { name: /send/i });
        expect(sendButton).toBeDisabled();
    });
});
