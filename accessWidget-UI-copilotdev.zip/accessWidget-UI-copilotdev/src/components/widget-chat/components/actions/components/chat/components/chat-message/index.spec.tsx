import { h } from "preact";
import { render } from "~/utils/test-utils";
import { screen } from "@testing-library/dom";
import { ChatMessage } from "./index";
import {MessageRole} from "~/components/widget-chat/components/actions/components/chat/types";

describe("ChatMessage", () => {
  it("renders user message with correct class", () => {
    render(
      <ChatMessage
        message={{
          id: "1",
          role: MessageRole.User,
          content: "Hello from user!",
          timestamp: new Date(),
        }}
      />
    );
    const messageDiv = screen.getByText("Hello from user!");
    expect(messageDiv).toBeInTheDocument();
    expect(messageDiv.parentElement).toHaveClass("chat-message-user");
  });

  it("renders assistant message with correct class", () => {
    render(
      <ChatMessage
        message={{
          id: "2",
          role: MessageRole.Assistant,
          content: "Hello from assistant!",
          timestamp: new Date(),
        }}
      />
    );
    const messageDiv = screen.getByText("Hello from assistant!");
    expect(messageDiv).toBeInTheDocument();
    expect(messageDiv.parentElement).toHaveClass("chat-message-assistant");
  });
});
