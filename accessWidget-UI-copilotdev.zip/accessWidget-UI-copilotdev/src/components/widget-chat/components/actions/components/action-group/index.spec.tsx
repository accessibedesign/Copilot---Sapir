/* eslint-disable no-case-declarations */
import { h } from "preact";
import { ActionGroup } from "./index";
import { render } from "~/utils/test-utils";
import { ActionBoxName } from "../../types";
import { Color, ColorPicker } from "../color-picker";
import { actionBoxes } from "../../data";
import { WidgetChatEventEmitter } from "~/components/widget-chat/context/event-emitter";
import { WidgetChatEventType } from "~/index.module";
import { BaseSelect, Option } from "../../../base-select";
import { data as widgetConfigData } from "~/mock/widget-config";
import { fireEvent } from "@testing-library/dom";

describe("Tests `ActionGroup` component functionality", () => {
  const activeActions = widgetConfigData.state.actions;
  const actionTypes = Object.values(ActionBoxName);
  for (const actionType of actionTypes) {
    const currentActiveActions = activeActions[actionType];
    const actions = actionBoxes.find(({ name }) => actionType === name).elements;
    const emit = jest.fn();
    const component = render(
      <WidgetChatEventEmitter.Provider value={emit}>
        <ActionGroup activeActions={activeActions} actions={actions} actionType={actionType} />;
      </WidgetChatEventEmitter.Provider>,
    );
    const actionRefs = component.container.querySelectorAll(".action-box");

    it(`should have active class on enabled actions in ${actionType}`, async () => {
      // get all action boxes that are buttons
      const buttonActionsEelments = actions.filter((item) => !item.component);

      const buttonActiveActions = Object.fromEntries(
        Object.entries(currentActiveActions).filter(([key]) => buttonActionsEelments.some((item) => item.name == key)),
      );
      for (const activeAction of Object.keys(buttonActiveActions)) {
        const activeActionEl = component.container.querySelector(`.action-box.action-box-${activeAction}`);
        expect(activeActionEl.classList.contains("action-box--active")).toBe(true);
      }
    });

    it(`should fire correct event data on action box interaction in ${actionType}`, () => {
      actionRefs.forEach((action) => {
        const actionName = action.getAttribute("data-test");
        const componentName = actions.find((item) => item.name == actionName).component?.name;
        const element = actions.find((item) => actionName == item.name);
        switch (componentName) {
          case BaseSelect.name:
            const select = action.querySelector("select");
            const options = activeActions[actionType][element.name] as Option[][];
            const flatOptions = options.flat();
            flatOptions.forEach((option) => {
              fireEvent.change(select, { target: { value: option.value } });

              expect(emit).toHaveBeenCalledWith({
                ...element.component.emitData.onChange,
                data: flatOptions.find((option) => option.value == select.value),
              });
            });

            fireEvent.focusIn(select);
            expect(emit).toHaveBeenCalledWith({
              ...element.component.emitData.onFocus,
            });
            break;

          case ColorPicker.name:
            const colorPicker = action.querySelector(`[aria-label*="Red"]`);
            fireEvent.click(colorPicker);

            expect(emit).toHaveBeenCalledWith({
              type: WidgetChatEventType.State,
              data: {
                actions: {
                  [actionType]: { ...currentActiveActions, [element.name]: Color.Red },
                },
              },
              source: element.name,
            });

            const cancel = action.querySelector(".color-picker__cancel");
            fireEvent.click(cancel);
            expect(emit).toHaveBeenCalledWith({
              type: WidgetChatEventType.State,
              data: {
                actions: {
                  [actionType]: { ...currentActiveActions, [element.name]: undefined },
                },
              },
              source: element.name,
            });
            break;
          case Range.name:
            const range = action.querySelector(".range__plus-button");
            fireEvent.click(range);

            expect(emit).toHaveBeenCalledWith({
              type: WidgetChatEventType.State,
              data: {
                actions: {
                  [actionType]: { ...currentActiveActions, [element.name]: 10 },
                },
              },
              source: element.name,
            });
            break;

          default:
            fireEvent.click(action);
            const data = {
              actions: {
                [actionType]: {
                  ...activeActions?.[actionType],
                  [actionName]: !activeActions?.[actionType]?.[actionName],
                },
              },
            };

            expect(emit).toHaveBeenCalledWith({
              type: WidgetChatEventType.State,
              data,
              source: actionName,
            });
            break;
        }
      });
    });
  }
});
