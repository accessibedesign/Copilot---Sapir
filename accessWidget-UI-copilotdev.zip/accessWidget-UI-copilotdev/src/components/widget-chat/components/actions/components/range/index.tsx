import { h, VNode, Fragment } from "preact";
import * as icons from "~/components/widget-chat/assets/icons";
import { BaseButton } from "../../../base-button";
import styles from "./style.scss";
import BaseIcon from "~/components/base-icon";

import { useTranslation } from "~/hooks/useTranslation";
import {useStylesheet} from "~/hooks/useStylesheet";

interface Props {
  value?: number;
  onChange: (_value: number) => void;
}

export function Range({ value = 0, onChange }: Props): VNode {
  const { t } = useTranslation();
  useStylesheet(styles);
  return (
    <Fragment>
      <div class="range">
        <BaseButton class="range__plus-button" aria-label={t("INCREASE")} onClick={() => onChange(value + 10)}>
          <BaseIcon class="icon">{icons.chevronUp}</BaseIcon>
        </BaseButton>
        <BaseButton class="range__minus-button" aria-label={t("DECREASE")} onClick={() => onChange(value - 10)}>
          <BaseIcon class="icon">{icons.chevronDown}</BaseIcon>
        </BaseButton>
        <div class="range__base">{value ? `${value}%` : t("DEFAULT")}</div>
      </div>
    </Fragment>
  );
}
