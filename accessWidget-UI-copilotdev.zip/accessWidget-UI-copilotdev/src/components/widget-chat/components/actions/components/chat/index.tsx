import {Fragment, h} from 'preact';
import { useEffect, useState } from 'preact/hooks';
import styles from "./style.scss";
import { useStylesheet } from '~/hooks/useStylesheet';
import { ChatMessages } from './components/chat-messages';
import { ChatInput } from './components/chat-input';
import { ChatMessage } from './types';
import {BoxElementName} from "~/components/widget-chat/components/actions/types";

export interface ChatProps {
  messages: ChatMessage[];
  onSendMessage: (msg: string) => void;
  loading?: boolean;
  actions?: any;
}

export { ChatMessage, MessageRole, ChatButton } from "./types";
export {
  vibrate,
  eye,
  target,
  thought,
  navigation,
  font,
  hide,
  links,
  heading,
  focus,
  reading,
  keyboard,
  reset,
  mute,
  magnifier,
  overlay
} from '~/components/widget-chat/assets/icons';

export { BoxElementName } from "~/components/widget-chat/components/actions/types";

/**
 * Main Chat component
 */

export const Chat = ({ messages, onSendMessage, loading = false, actions }: ChatProps) => {
  useStylesheet(styles);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(messages);

  useEffect(() => {
    setChatMessages(messages);
  }, [messages]);

  return (
      <Fragment>
          <div class="chat-container">
              <ChatMessages messages={chatMessages} loading={loading} actions={actions} />
              <ChatInput onSendMessage={onSendMessage} />
          </div>
      </Fragment>
  );
};
