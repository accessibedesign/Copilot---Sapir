import { h } from 'preact';
import { useState } from 'preact/hooks';
import styles from './style.scss';
import { useStylesheet } from '~/hooks/useStylesheet';
import { ChatInputProps } from '../../types';
import { useTranslation } from '~/hooks/useTranslation';
import { send } from '~/components/widget-chat/assets/icons';
import BaseIcon from '~/components/base-icon';

export const ChatInput = ({ onSendMessage, disabled = false }: ChatInputProps) => {
  useStylesheet(styles);
  const [inputValue, setInputValue] = useState("");
  const { t } = useTranslation();

  const handleSend = () => {
    const trimmedValue = inputValue.trim();
    if (trimmedValue && !disabled) {
      onSendMessage(trimmedValue);
      setInputValue("");
    }
  };

  const handleKeyPress = (e: KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <form
      class="chat-input"
      onSubmit={e => {
        e.preventDefault();
        if (!disabled && inputValue.trim()) {
          handleSend();
        }
      }}
    >
      <input
        type="text"
        class="chat-input-field"
        placeholder={t('CHAT_PLACEHOLDER')}
        value={inputValue}
        disabled={disabled}
        maxLength={512}
        onInput={e => setInputValue((e.target as HTMLInputElement).value)}
        onKeyPress={handleKeyPress}
        aria-label={t('CHAT_PLACEHOLDER')}
      />
      <button
        type="submit"
        class={`chat-input-send ${inputValue.trim() ? 'active' : ''}`}
        disabled={disabled || !inputValue.trim()}
        aria-label="Send message"
      >
        <BaseIcon>
          {send}
        </BaseIcon>
      </button>
    </form>
  );
};
