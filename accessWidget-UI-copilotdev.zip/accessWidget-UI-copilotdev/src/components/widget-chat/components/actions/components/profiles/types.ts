export enum ProfileType {
  MOTOR = "motor",
  BLIND = "blind",
  ADHD = "adhd",
  COGNITIVE = "cognitive",
  VISION = "vision",
  SEIZURES = "seizures",
}

export interface Profile {
  type: ProfileType;
  icon: string;
  title: string;
  text: string;
  message: string;
  connected?: boolean;
}

export type ActiveProfiles = { [key in ProfileType]?: boolean };
