/* eslint-disable @typescript-eslint/no-empty-function */
import { h } from "preact";
import { render } from "~/utils/test-utils";
import { Range } from "./index";
import { useTranslation } from "~/hooks/useTranslation";
import defaultDictionary from "~/components/widget-chat/locale/en.json";
import { fireEvent } from "@testing-library/preact";
describe("Tests `Range` component functionality", () => {
  const { t } = useTranslation(defaultDictionary);
  const defaultIncrement = 10;
  const defaultValue = 0;

  it(`should decrement by ${defaultIncrement} once clicked`, async () => {
    const interaction = jest.fn();

    const component = render(<Range onChange={interaction} value={defaultValue} />);
    const decrementButton = (await component.findAllByRole("button"))[1];
    fireEvent.click(decrementButton);

    expect(interaction).toHaveBeenCalledWith(defaultValue - defaultIncrement);
  });

  it(`should increment by ${defaultIncrement} once clicked`, async () => {
    const interaction = jest.fn();

    const component = render(<Range onChange={interaction} value={defaultValue} />);
    const incrementButton = (await component.findAllByRole("button"))[0];
    fireEvent.click(incrementButton);

    expect(interaction).toHaveBeenCalledWith(defaultValue + defaultIncrement);
  });

  it(`should render default text, if the initial value is 0`, async () => {
    const component = render(<Range onChange={() => {}} value={defaultValue} />);
    const rangeBaseEl = component.findByText(t("DEFAULT"));
    expect(rangeBaseEl).toBeTruthy();
  });

  const initialValues = [-1, 2];
  for (const initialValue of initialValues) {
    it(`should render the value [${initialValue}], if the initial value is either positive or negative`, () => {
      const component = render(<Range onChange={() => {}} value={initialValue} />);
      const rangeBaseEl = component.findByText(`${initialValue}%`);
      expect(rangeBaseEl).toBeTruthy();
    });
  }

  it(`should render default text, if the initial value is undefined`, () => {
    const component = render(<Range onChange={() => {}} />);
    const rangeBaseEl = component.findByText(t("DEFAULT"));
    expect(rangeBaseEl).toBeTruthy();
  });
});
