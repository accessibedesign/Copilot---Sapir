import { Fragment, h, VNode } from "preact";
import { useContext, useMemo } from "preact/hooks";
import BaseIcon from "~/components/base-icon";
import { ActiveActions, WidgetChatEventData, WidgetChatEventType } from "~/components/widget-chat/types";
import { WidgetChatEventEmitter } from "~/components/widget-chat/context/event-emitter";
import { ActionBoxName, BoxElementName } from "../../types";
import { BaseSelect, Option, Props as BaseSelectProps } from "../../../base-select";
import { ColorPicker } from "../color-picker";
import { Range } from "../range";
import styles from "./style.scss";

import { useTranslation } from "~/hooks/useTranslation";
import { ContentButton } from "../content-button";
import { useStylesheet } from "~/hooks/useStylesheet";
import { WidgetOptions } from "~/components/widget";

export interface BoxElement {
  name: BoxElementName;
  text: string;
  icon?: string;
  // gridArea: string // this replaces bigElement and cssProperty with grid-template-areas system
  // TODO: targetElement should be removed in favor of a callback or an enum
  targetElement?: string; // tells the widget controller which element to perform activeActions on
  hideMobile?: boolean;
  component?: {
    name: string;
    props?: Record<string, unknown>;
    emitData?: Record<string, Partial<WidgetChatEventData> | WidgetChatEventData>;
  };
}

export function ActionGroup({
  actions,
  activeActions,
  actionType,
  options = {},
}: {
  actions: BoxElement[];
  activeActions: ActiveActions;
  actionType: ActionBoxName;
  options?: WidgetOptions["adjustments"];
}): VNode {
  const { t } = useTranslation();
  const emit = useContext(WidgetChatEventEmitter);

  /**
   * Filter out actions that are hidden by the options
   */
  const visibleActions = useMemo(() => actions.filter(({ name }) => !options[name]?.hide), [actions, options]);

  const isActive = (name: BoxElementName, actionType: ActionBoxName) => activeActions?.[actionType]?.[name];

  const actionBoxClickHandler = (name: BoxElementName, actionType: ActionBoxName) => {
    const data = {
      actions: {
        [actionType]: { ...activeActions?.[actionType], [name]: !activeActions?.[actionType]?.[name] },
      },
    };

    emit({
      type: WidgetChatEventType.State,
      data,
      source: name,
    });
  };

  const customComponentChangeHandler = (name: BoxElementName, actionType: ActionBoxName, value: string | number) => {
    const data = {
      actions: {
        [actionType]: { ...activeActions?.[actionType], [name]: value },
      },
    };

    emit({
      type: WidgetChatEventType.State,
      data,
      source: name,
    });
  };

  useStylesheet(styles);

  return (
    <Fragment>
      <div class="action-group">
        {visibleActions.map(({ name, hideMobile, text, icon, component }, index) => {
          const active = isActive(name, actionType);
          const currentActiveActions = activeActions[actionType];
          return (
            <ContentButton
              data-test={name}
              class={`action-box action-box-${name} ${active ? "action-box--active" : ""} ${
                hideMobile ? "action-box--hide-mobile" : ""
              }`}
              {...(!component && {
                onClick: () => actionBoxClickHandler(name, actionType),
                active,
              })}
              style={`order: ${index}`}
              key={name}
            >
              <div class="action__content">
                <div class="content__icon">{icon && <BaseIcon class="icon">{icon}</BaseIcon>}</div>

                <span class="content__title">{t(text)}</span>
              </div>
              {component && (
                <div class={`action__custom-element`}>
                  {component.name === Range.name && (
                    <Range
                      {...{
                        value: currentActiveActions[name],
                        onChange: (value) => customComponentChangeHandler(name, actionType, value),
                      }}
                    />
                  )}
                  {component.name === ColorPicker.name && (
                    <ColorPicker
                      {...{
                        activeColor: currentActiveActions[name],
                        onChange: (value) => customComponentChangeHandler(name, actionType, value),
                      }}
                    />
                  )}
                  {component.name === BaseSelect.name && (
                    <BaseSelect
                      {...{
                        ...({
                          ...component.props,
                          options: currentActiveActions[name],
                          onFocus: () => emit(component.emitData.onFocus as WidgetChatEventData),
                          onChange: (data) => {
                            emit({
                              ...component.emitData.onChange,
                              data,
                            } as { type: WidgetChatEventType.NavigateToUsefulLink; data: Option });
                          },
                        } as BaseSelectProps),
                      }}
                    />
                  )}
                </div>
              )}
            </ContentButton>
          );
        })}
      </div>
    </Fragment>
  );
}
