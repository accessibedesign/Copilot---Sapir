import { FunctionComponent, h } from "preact";
import { Toggle } from "~/components/widget-chat/components/actions/components/toggle";
import { useState } from "preact/hooks";
import { useTranslation } from "~/hooks/useTranslation";
import { AIToolType } from "~/components/widget";
import { ActiveAITools } from "../../types";
import { useStylesheet } from "~/hooks/useStylesheet";
import style from "./style.scss"

interface TextSimplifierProps { activeAITools: ActiveAITools, active: boolean}

export const TextSimplifierToolComponent: FunctionComponent<TextSimplifierProps> = ({ activeAITools, active }: TextSimplifierProps) => {
  const isDisabled = activeAITools[AIToolType.TEXT_SIMPLIFIER] === "disabled";
  const { t, direction } = useTranslation();
  const [isHoveringToggle, setIsHoveringToggle] = useState(false);
  useStylesheet(style)
  return (
    <div
      class={`text-simplifier-toggle ${isDisabled ? "text-simplifier-toggle--disabled" : ""}`}
      data-testid="text-simplifier-toggle"
      onMouseEnter={() => setIsHoveringToggle(true)}
      onMouseLeave={() => setIsHoveringToggle(false)}
    >
      {isDisabled && isHoveringToggle && (
        <div dir={direction} class="text-simplifier-toggle__tooltip" role="tooltip">
          {t("TEXT_SIMPLIFIER_DISABLED_TOOLTIP_MESSAGE")}
        </div>
      )}
      <Toggle active={active} />
    </div>

  );
};