import { h } from "preact";
import { AITools } from "./index";
import { render } from "~/utils/test-utils";
import { WidgetChatEventEmitter } from "~/components/widget-chat/context/event-emitter";
import { WidgetChatEventType } from "~/components/widget-chat/types";
import { ActiveAITools, AIToolType } from "./types";
import { aiTools } from "./data";
import { fireEvent } from "@testing-library/preact";

describe("Tests AI Tool SVGs", () => {
  it("should display the correct SVG when text simplifier is active", () => {
    const activeAITools: ActiveAITools = {
      [AIToolType.TEXT_SIMPLIFIER]: "on",
    };
    const component = render(<AITools activeAITools={activeAITools} />);
    const svg = component.container.querySelector(".icon");
    expect(svg.id).toBe("textSimplifierOn");
  });

  it("should display the correct SVG when text simplifier is inactive", () => {
    const activeAITools: ActiveAITools = {
      [AIToolType.TEXT_SIMPLIFIER]: "off",
    };
    const component = render(<AITools activeAITools={activeAITools} />);
    const svg = component.container.querySelector(".icon");
    expect(svg.id).toBe("textSimplifierOff");
  });

  it("should display the correct state when text simplifier is disabled", () => {
    const activeAITools: ActiveAITools = {
      [AIToolType.TEXT_SIMPLIFIER]: "disabled",
    };
    const component = render(<AITools activeAITools={activeAITools} />);
    const toggle = component.queryByTestId("text-simplifier-toggle");
    fireEvent.mouseEnter(toggle);
    const tooltip = component.getByRole("tooltip");
    expect(tooltip).toBeInTheDocument();
    fireEvent.mouseLeave(toggle);
    expect(tooltip).not.toBeInTheDocument();
  });

});

describe("Tests `Header` component functionality", () => {
  it(`should state change to 'off' event on AI Tool button click`, async () => {
    const activeAITools: ActiveAITools = {
      [AIToolType.TEXT_SIMPLIFIER]: "on",
    };
    const emit = jest.fn();
    const component = render(
      <WidgetChatEventEmitter.Provider value={emit}>
        <AITools activeAITools={activeAITools} />
      </WidgetChatEventEmitter.Provider>,
    );
    const aiToolButton = component.container.querySelectorAll(".aitool");

    aiToolButton.forEach((button) => {
      fireEvent.click(button);
      const type = aiTools[button.getAttribute("data-test") as AIToolType].type;
      expect(emit).toHaveBeenCalledWith({
        type: WidgetChatEventType.State,
        data: {
          aiTools: { ...activeAITools, [type]: "off" },
        },
        source: type,
      });
    });
  });
  it(`should state change to 'on' event on AI Tool button click`, async () => {
    const activeAITools: ActiveAITools = {
      [AIToolType.TEXT_SIMPLIFIER]: "off",
    };
    const emit = jest.fn();
    const component = render(
      <WidgetChatEventEmitter.Provider value={emit}>
        <AITools activeAITools={activeAITools} />
      </WidgetChatEventEmitter.Provider>,
    );
    const aiToolButton = component.container.querySelectorAll(".aitool");

    aiToolButton.forEach((button) => {
      fireEvent.click(button);
      const type = aiTools[button.getAttribute("data-test") as AIToolType].type;
      expect(emit).toHaveBeenCalledWith({
        type: WidgetChatEventType.State,
        data: {
          aiTools: { ...activeAITools, [type]: "on" },
        },
        source: type,
      });
    });
  });
  it(`should state change to 'disable' event on AI Tool button click`, async () => {
    const activeAITools: ActiveAITools = {
      [AIToolType.TEXT_SIMPLIFIER]: "disabled",
    };
    const emit = jest.fn();
    const component = render(
      <WidgetChatEventEmitter.Provider value={emit}>
        <AITools activeAITools={activeAITools} />
      </WidgetChatEventEmitter.Provider>,
    );
    const aiToolButton = component.container.querySelectorAll(".aitool");

    aiToolButton.forEach((button) => {
      fireEvent.click(button);
      const type = aiTools[button.getAttribute("data-test") as AIToolType].type;
      expect(emit).toHaveBeenCalledWith({
        type: WidgetChatEventType.State,
        data: {
          aiTools: { ...activeAITools, [type]: "disabled" },
        },
        source: type,
      });
    });
  });
  it(`should state change to 'on' event on AI Tool button click and it's undefined`, async () => {
    const activeAITools: ActiveAITools = {
    };
    const emit = jest.fn();
    const component = render(
      <WidgetChatEventEmitter.Provider value={emit}>
        <AITools activeAITools={activeAITools} />
      </WidgetChatEventEmitter.Provider>,
    );
    const aiToolButton = component.container.querySelectorAll(".aitool");

    aiToolButton.forEach((button) => {
      fireEvent.click(button);
      const type = aiTools[button.getAttribute("data-test") as AIToolType].type;
      expect(emit).toHaveBeenCalledWith({
        type: WidgetChatEventType.State,
        data: {
          aiTools: { ...activeAITools, [type]: "on" },
        },
        source: type,
      });
    });
  });
});
