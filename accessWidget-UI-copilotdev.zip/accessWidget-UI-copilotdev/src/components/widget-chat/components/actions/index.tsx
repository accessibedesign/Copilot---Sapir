import { Fragment, h, VNode } from "preact";
import styles from "./style.scss";
import { WidgetChatEventDataStateChange } from "../../types";
import { Chat } from "./components/chat";
import { useStylesheet } from "~/hooks/useStylesheet";
import { WidgetChatOptions } from "../..";

interface Props {
  state: WidgetChatEventDataStateChange;
  options?: WidgetChatOptions;
}

export function Actions({ state, options = {} }: Props): VNode {
  useStylesheet(styles);

  return (
    <Fragment>
      <div class="actions">
        {/* Chat */}
          <div class={`action`} name="chat" key="chat">
            <Chat
              messages={state.chat?.messages || []}
              onSendMessage={options.chat?.onSendMessage || (() => {})}
              loading={state.chat?.loading || false}
              actions={state.actions}
            />
          </div>
      </div>
    </Fragment>
  );
}
