import { h } from "preact";
import { render } from "~/utils/test-utils";
import { Actions } from "./index";
import { useTranslation } from "~/hooks/useTranslation";
import defaultDictionary from "~/components/widget-chat/locale/en.json";
import { data as widgetConfigData } from "~/mock/widget-config";
import { actionBoxes } from "./data";

describe("Tests `Actions` component functionality", () => {
  const { t } = useTranslation(defaultDictionary);

  it(`should render the AI tool component on first action container`, () => {
    const component = render(<Actions state={widgetConfigData.state} />);
    const firstActionContainer = component.container.querySelector(".actions");
    const aiToolsRef = firstActionContainer.querySelector(".aitools");
    expect(firstActionContainer.innerHTML.includes(aiToolsRef.innerHTML)).toBe(true);
  });

  it(`should render the first profile component on second action container`, () => {
    const component = render(<Actions state={widgetConfigData.state} />);
    const secondActionContainer = component.container.querySelectorAll(".action")[1];
    const profilesRef = secondActionContainer.querySelector(".profiles");
    expect(secondActionContainer.innerHTML.includes(profilesRef.innerHTML)).toBe(true);
  });

  it(`should render a corresponding title for each actions section`, () => {
    const component = render(<Actions state={widgetConfigData.state} />);

    actionBoxes.forEach(({ name, title }) => {
      const titleRef = component.container.querySelector(`[name="${name}"] .action__title`);

      expect(titleRef.innerHTML).toBe(t(title));
    });
  });

  it("should hide profiles section if `profilesSection.hide` is true", () => {
    const component = render(<Actions state={widgetConfigData.state} options={{ profilesSection: { hide: true } }} />);

    const profiles = component.container.querySelector(".profiles");

    expect(profiles).toBeNull();
  });

  it("should hide AI tools section if `aiToolsSection.hide` is true", () => {
    const component = render(<Actions state={widgetConfigData.state} options={{ aiToolsSection: { hide: true } }} />);

    const profiles = component.container.querySelector(".aitools");

    expect(profiles).toBeNull();
  });
});
