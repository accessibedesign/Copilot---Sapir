import * as icons from "~/components/widget-chat/assets/icons";
import { WidgetChatEventType } from "../../types";
import { BaseSelect } from "../base-select";
import { ColorPicker } from "./components/color-picker";
import { Range } from "./components/range";
import { ActionBox, ActionBoxName, BoxElementName } from "./types";

export const actionBoxes: ActionBox[] = [
  {
    name: ActionBoxName.textAdjustments,
    title: "TEXT_ADJUSTMENTS",
    elements: [
      {
        name: BoxElementName.zoom,
        text: "ACTION_ZOOM",
        icon: icons.zoom,
        targetElement: "body",
        component: { name: Range.name },
      },
      {
        name: BoxElementName.readableFont,
        text: "ACTION_FONT",
        icon: icons.font,
      },
      {
        name: BoxElementName.emphasizeTitles,
        text: "ACTION_TITLES",
        icon: icons.heading,
      },
      {
        name: BoxElementName.emphasizeLinks,
        text: "ACTION_LINKS",
        icon: icons.link,
      },
      {
        name: BoxElementName.magnifier,
        text: "ACTION_MAGNIFIER",
        icon: icons.magnifier,
        hideMobile: true,
      },
      {
        name: BoxElementName.fontSize,
        text: "ACTION_FONT_SIZE",
        icon: icons.size,
        component: { name: Range.name },
      },
      {
        name: BoxElementName.textAlignCenter,
        text: "ACTION_ALIGN_CENTER",
        icon: icons.textCenter,
      },
      {
        name: BoxElementName.lineHeight,
        text: "ACTION_LINE_HEIGHT",
        icon: icons.lineHeight,
        component: { name: Range.name },
      },
      {
        name: BoxElementName.textAlignLeft,
        text: "ACTION_ALIGN_LEFT",
        icon: icons.textLeft,
      },
      {
        name: BoxElementName.letterSpacing,
        text: "ACTION_LETTER_SPACING",
        icon: icons.space,
        component: { name: Range.name },
      },
      {
        name: BoxElementName.textAlignRight,
        text: "ACTION_ALIGN_RIGHT",
        icon: icons.textRight,
      },
    ],
  },
  {
    name: ActionBoxName.colorAdjustments,
    title: "COLOR_DISPLAY_ADJUSTMENTS",
    elements: [
      {
        name: BoxElementName.darkContrast,
        text: "ACTION_DARK",
        icon: icons.dark,
      },
      {
        name: BoxElementName.lightContrast,
        text: "ACTION_LIGHT",
        icon: icons.light,
      },
      {
        name: BoxElementName.highContrast,
        text: "ACTION_HIGH_CONTRAST",
        icon: icons.contrast,
      },

      {
        name: BoxElementName.highSaturation,
        text: "ACTION_HIGH_SATURATION",
        icon: icons.saturation,
      },
      {
        name: BoxElementName.textColor,
        text: "ACTION_TEXT_COLOR",
        component: { name: ColorPicker.name },
      },
      {
        name: BoxElementName.monochrome,
        text: "ACTION_MONOCHROME",
        icon: icons.monochrome,
      },

      {
        name: BoxElementName.titleColor,
        text: "ACTION_TITLE_COLOR",
        component: { name: ColorPicker.name },
      },
      {
        name: BoxElementName.lowSaturation,
        text: "ACTION_LOW_SATURATION",
        icon: icons.invert,
      },
      {
        name: BoxElementName.backgroundColor,
        text: "ACTION_BACKGROUND_COLOR",
        component: { name: ColorPicker.name },
      },
    ],
  },
  {
    name: ActionBoxName.orientationAdjustments,
    title: "ORIENTATION_ADJUSTMENTS",
    elements: [
      {
        name: BoxElementName.mute,
        text: "ACTION_MUTE",
        icon: icons.mute,
      },
      {
        name: BoxElementName.hideImages,
        text: "ACTION_HIDE_IMAGES",
        icon: icons.image,
      },
      {
        name: BoxElementName.readMode,
        text: "ACTION_READ_MODE",
        icon: icons.keyboard,
        hideMobile: true,
      },

      {
        name: BoxElementName.readingGuide,
        text: "ACTION_READING_GUIDE",
        icon: icons.reading,
        hideMobile: true,
      },

      {
        name: BoxElementName.usefulLinks,
        text: "ACTION_USEFUL_LINKS",
        icon: icons.links,
        component: {
          name: BaseSelect.name,
          props: {
            title: "ACTION_USEFUL_LINKS",
          },
          emitData: {
            onFocus: { type: WidgetChatEventType.UsefulLinksFocused },
            onChange: { type: WidgetChatEventType.NavigateToUsefulLink },
          },
        },
      },
      {
        name: BoxElementName.stopAnimations,
        text: "ACTION_STOP_ANIMATIONS",
        icon: icons.vibrate,
      },
      {
        name: BoxElementName.readingMask,
        text: "ACTION_READING_MASK",
        icon: icons.overlay,
        hideMobile: true,
      },
      {
        name: BoxElementName.emphasizeHover,
        text: "ACTION_HIGHLIGHT_HOVER",
        icon: icons.mouse,
        hideMobile: true,
      },
      {
        name: BoxElementName.emphasizeFocus,
        text: "ACTION_HIGHLIGHT_FOCUS",
        icon: icons.focus,
      },
      {
        name: BoxElementName.bigBlackCursor,
        text: "ACTION_HIGHLIGHT_BLACK_CURSOR",
        icon: icons.cursorFull,
        hideMobile: true,
      },
      {
        name: BoxElementName.bigWhiteCursor,
        text: "ACTION_HIGHLIGHT_WHITE_CURSOR",
        icon: icons.cursor,
        hideMobile: true,
      },
    ],
  },
];
