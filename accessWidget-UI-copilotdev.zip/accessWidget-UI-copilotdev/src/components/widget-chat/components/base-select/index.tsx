import { h, VNode, Fragment } from "preact";
import { useTranslation } from "~/hooks/useTranslation";
import styles from "./style.scss";
import {useStylesheet} from "~/hooks/useStylesheet";

export interface Option {
  value: string;
  text: string;
}

export interface Props {
  title: string;
  options: Option[][];
  onChange: (_option: Option) => void;
  onFocus: () => void;
}

export function BaseSelect({ title, options, onChange, onFocus }: Props): VNode {
  const { t } = useTranslation();

  const onChangeHandler = (e: Event) => {
    const el = e.target as HTMLSelectElement;

    const optionEl = el[el.selectedIndex];
    const data: Option = {
      value: el.value,
      text: optionEl.textContent,
    };
    onChange(data);
  };
  useStylesheet(styles);
  return (
    <Fragment>
      <select onFocus={onFocus} onChange={onChangeHandler} class="base-select" aria-label={t(title)}>
        <option disabled value="acsbDefault" selected>
          {t("SELECT_OPTION")}
        </option>
        {options.map((options, index) => {
          /* all items in first array should be option, after that they should go inside optgroup */
          if (index == 0) {
            return options.map(({ value, text }) => (
              <option key={value} value={value}>
                {text}
              </option>
            ));
          }
          return (
            <optgroup key={index} label="──────────">
              {options.map(({ value, text }) => (
                <option key={value} value={value}>
                  {text}
                </option>
              ))}
            </optgroup>
          );
        })}
      </select>
    </Fragment>
  );
}
