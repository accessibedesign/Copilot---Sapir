/* eslint-disable @typescript-eslint/no-empty-function */
import { h } from "preact";
import { render } from "~/utils/test-utils";
import { BaseSelect, Option } from "./index";
import { useTranslation } from "~/hooks/useTranslation";
import defaultDictionary from "~/components/widget-chat/locale/en.json";
import { fireEvent } from "@testing-library/preact";

const baseSelectMock: Option[][] = [
  [
    {
      value: "homepage",
      text: "HOMEPAGE",
    },
    {
      value: "top",
      text: "HEADER",
    },
    {
      value: "bottom",
      text: "FOOTER",
    },
    {
      value: "content",
      text: "NAVIGATOR_MAIN_CONTENT",
    },
  ],
  [
    {
      value: "bottom",
      text: "FOOTER",
    },
  ],
];
describe("Tests `BaseSelect` component functionality", () => {
  const { t } = useTranslation(defaultDictionary);
  it(`should render render translated 'title' as aria-label`, async () => {
    const component = render(
      <BaseSelect title="ACTION_USEFUL_LINKS" options={[]} onChange={() => {}} onFocus={() => {}} />
    );
    const selectEl = await component.findByRole("combobox");
    expect(selectEl.attributes.getNamedItem("aria-label").value === t("ACTION_USEFUL_LINKS")).toBeTruthy();
  });

  it(`should call close onChange event with data upon selection`, async () => {
    const onChange = jest.fn();

    const component = render(
      <BaseSelect title="ACTION_USEFUL_LINKS" options={baseSelectMock} onChange={onChange} onFocus={() => {}} />
    );
    const selectEl = (await component.findByRole("combobox")) as HTMLSelectElement;
    fireEvent.change(selectEl, { target: { value: "bottom" } });

    expect(onChange).toHaveBeenCalledWith({
      value: selectEl.value,
      text: selectEl.children[selectEl.selectedIndex].innerHTML,
    });
  });
});
