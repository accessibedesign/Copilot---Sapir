import { h, VNode, Fragment, ComponentChildren } from 'preact'
import styles from './style.scss'
import {useStylesheet} from "~/hooks/useStylesheet";

interface Props {
  children: ComponentChildren
}
export function BaseCard({ children }: Props): VNode {
    useStylesheet(styles);
  return (
    <Fragment>
      <div class="base-card">{children}</div>
    </Fragment>
  )
}
