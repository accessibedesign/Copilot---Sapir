import { h } from "preact";
import { BaseModal } from "./index";
import { LanguageSelection } from "../header/components/language-selector/modals/language-selection";
import { buildProvidedComponent } from "~/utils/test-utils";
import { fireEvent } from "@testing-library/preact";
describe("Tests `BaseModal` component functionality", () => {
  it(`should call close callback on close button click`, async () => {
    const onEvent = jest.fn();
    const component = buildProvidedComponent(
      <BaseModal isOpen={true} close={onEvent} children={<LanguageSelection />} />,
      { onEvent }
    );

    const closeButton = (await component.findAllByRole("button"))[0];

    fireEvent.click(closeButton);

    expect(onEvent).toHaveBeenCalled();
  });

  const isOpenValues = [true, false];
  for (const isOpen of isOpenValues) {
    it(`should show/hide dialog if isOpen prop is true/false`, async() => {
      const onEvent = jest.fn();
      const component = buildProvidedComponent(
        <BaseModal isOpen={isOpen} close={onEvent} children={<LanguageSelection />} />,
        { onEvent }
      );
      const dialogEl = await component.findByRole("dialog");

      expect(dialogEl.classList.contains("base-modal--active")).toBe(isOpen);
    });
  }

  it(`should render received children`, () => {
    const onEvent = jest.fn();
    const component = buildProvidedComponent(
      <BaseModal isOpen={true} close={onEvent} children={<LanguageSelection />} />,
      { onEvent }
    );
    expect(component.container.innerHTML).toContain("language");
  });

  // TODO: this is temporarily removed till event propogation issue in useKeyPress is fixed.
  // it(`should emit 'close' event on escape button click`, () => {
  //   const onClose = jest.fn();
  //   const component = render(<BaseModal isOpen={true} close={onClose} children={<LanguageSelection />} />, { attachTo: document.body });
  //   const dialogEl = component.find('[role="dialog"]');
  //   dialogEl.simulate("keydown", { key: "Escape" });

  //   expect(onClose).toHaveBeenCalled();
  // });
});
