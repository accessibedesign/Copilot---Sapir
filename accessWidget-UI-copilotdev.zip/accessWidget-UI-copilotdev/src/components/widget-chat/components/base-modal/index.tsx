import { h, VNode, Fragment, ComponentChildren } from "preact";
import { BaseCard } from "../base-card";
import { CloseButton } from "../close-button";
import styles from "./style.scss";
import { Overlay } from "../overlay";
import { FocusTrap } from "../focus-trap";
import { useStylesheet } from "~/hooks/useStylesheet";
interface Props {
  children: ComponentChildren;
  isOpen: boolean;
  close: () => void;
}

export function BaseModal({ children, close, isOpen }: Props): VNode {
  useStylesheet(styles);
  return (
    <Fragment>
      <Overlay
        data-test="overlay"
        onClick={close}
        show={isOpen}
      >
        <FocusTrap active={isOpen} focusFirstElement={true}>
          <div role="dialog" class={`base-modal ${isOpen ? "base-modal--active" : ""}`}>
            {/* close button is conditionally rendered because when we have multiple focus traps,
             the focusableElements query selector captures it as a focusable element even though it's not visible */}
            {isOpen && <CloseButton ariaLabel="CLOSE" onClick={close} />}
            <BaseCard data-test="base-card">{children}</BaseCard>
          </div>
        </FocusTrap>
      </Overlay>
    </Fragment>
  );
}
