import { h } from "preact";
import { buildProvidedComponent, render } from "~/utils/test-utils";
import { Hero, heroButtons } from "./index";
import { fireEvent } from "@testing-library/preact";

describe("Tests `Hero` component functionality", () => {
  it(`should render all hero buttons from 'heroButtons' array`, async () => {
    const component = render(<Hero />);
    const actions = await component.findAllByRole("button");
    expect(actions).toBeTruthy();
  });

  const emit = jest.fn();
  const toggle = jest.fn();
  it(`should emit corresponding event of each hero button`, async () => {
    const component = buildProvidedComponent(<Hero />, { onEvent: emit, toggle });
    const buttons = await component.findAllByRole("button");
    buttons.forEach((button, index) => {
      const spies = { toggle, emit };
      fireEvent.click(button);

      for (const [actionName, actionArguments] of Object.entries(heroButtons[index].actions)) {
        expect(spies[actionName]).toHaveBeenCalledWith(actionArguments);
      }
    });
  });

  it(`should open link if it is provided for a hero button`, async () => {
    const open = jest.spyOn(window, "open");
    const statementLink = "https://google.com";
    const links = { statement: statementLink };
    const component = buildProvidedComponent(<Hero links={links} />, { onEvent: emit, toggle });
    const buttons = await component.findAllByRole("button");
    fireEvent.click(buttons[1]);
    expect(open).toHaveBeenCalledWith(statementLink, "_blank", "noopener,noreferrer");
  });

  it("should not call emit or toggle and log error for invalid link", async () => {
    const consoleError = jest.spyOn(console, "error").mockImplementation(() => {
      console.error = jest.fn();
    });
    emit.mockClear();
    toggle.mockClear();

    const component = buildProvidedComponent(<Hero links={{ statement: "javascript:alert('XSS')" }} />, { onEvent: emit, toggle });

    const buttons = await component.findAllByRole("button");
    fireEvent.click(buttons[1]);

    expect(consoleError).toHaveBeenCalledWith(`'javascript:alert('XSS')' is not a valid URL!`);
    expect(emit).not.toHaveBeenCalled();
    expect(toggle).not.toHaveBeenCalled();
    consoleError.mockRestore();
  });
});
