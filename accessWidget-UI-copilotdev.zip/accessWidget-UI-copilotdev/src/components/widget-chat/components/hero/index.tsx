import { Fragment, h, VNode } from "preact";
import { HeroButton } from "./components/hero-button";
import styles from "./style.scss";
import * as icons from "~/components/widget-chat/assets/icons";
import { ModalContext } from "~/context/modal-context";
import { useContext } from "preact/hooks";
import { AccessibilityStatementModal } from "./components/accessibility-statement-modal";
import { HideInterfaceModal } from "./components/hide-interface-modal";
import { WidgetChatEventEmitter } from "../../context/event-emitter";
import { WidgetChatEventType } from "../../types";
import { HeroButtonType } from "./types";

import { useTranslation } from "~/hooks/useTranslation";
import { useStylesheet } from "~/hooks/useStylesheet";
import { isUrlValid } from "~/utils/is-url-valid";

export enum HeroButtonName {
  Reset = "reset",
  Statement = "statement",
  HidePopup = "acsb-hide-popup",
}

export const heroButtons: HeroButtonType[] = [
  {
    name: HeroButtonName.Reset,
    icon: icons.reset,
    label: "REFRESH_SETTINGS",
    actions: {
      emit: {
        type: WidgetChatEventType.Reset
      }
    }
  },
  {
    name: HeroButtonName.Statement,
    icon: icons.bookmark,
    actions: {
      toggle: {
        content: <AccessibilityStatementModal />
      },
      emit: {
        type: WidgetChatEventType.StatementOpened
      }
    },
    label: "STATEMENT"
  },
  {
    name: HeroButtonName.HidePopup,
    icon: icons.hide,
    actions: {
      toggle: {
        content: <HideInterfaceModal />
      }
    },
    label: "HIDE_INTERFACE"
  }
];

interface Props {
  links?: { [key: string]: string };
  options?: Partial<
    Record<
      HeroButtonName,
      {
        hide?: boolean;
      }
    >
  >;
}

export function Hero({ links = {}, options = {} }: Props): VNode {
  const { toggle } = useContext(ModalContext);
  const emit = useContext(WidgetChatEventEmitter);

  /**
   * filter out the buttons that are set to be hidden via the options prop
   */
  const filteredLinks = heroButtons.filter((button) => !options[button.name]?.hide);

  const { t } = useTranslation();

  const handleButton = (button: HeroButtonType): void => {
    if (button.actions.toggle) {
      toggle(button.actions.toggle);
    }

    if (button.actions.emit) {
      emit(button.actions.emit);
    }
  };

  const handleClick = (button: HeroButtonType, link?: string): void => {
    if (link) {
      if (isUrlValid(link)) {
        window.open(link, "_blank", "noopener,noreferrer");
      } else {
        console.error(`'${link}' is not a valid URL!`);
      }
      return;
    }

    handleButton(button);
  };

  useStylesheet(styles);

  return (
    <Fragment>
      <div class="hero">
        <span class="title">{t("HERO_TITLE")}</span>
        <div class="actions">
          {filteredLinks.map((button) => (
            <HeroButton key={button.name} {...button} onClick={() => handleClick(button, links[button.name])} />
          ))}
        </div>
      </div>
    </Fragment>
  );
}
