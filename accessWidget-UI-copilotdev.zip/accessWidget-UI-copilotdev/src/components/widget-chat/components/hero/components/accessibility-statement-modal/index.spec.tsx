import { h } from "preact";
import { AccessibilityStatementModal } from "./index";
import { render } from "~/utils/test-utils";
import { StatementVariantContext } from "~/components/widget-chat/context/statement-variant";
import { StatementVariant } from "~/components/widget-chat/types";


describe("Tests `AccessibilityStatementModal` component functionality", () => {
  it(`should render content according to language`, async () => {
    const component = render(<AccessibilityStatementModal />);
    const data = await component.findByText("Accessibility Statement");
    expect(data.classList[0]).toBe("acsb-title-main");
  });

  it(`should render default statement if no variant is specified`, async () => {
    const component = render(
      <AccessibilityStatementModal />
    );
    const data = await component.findByText("Disability profiles supported on our website");
    expect(data).toBeTruthy();
  });

  it(`should render default statement according to variant`, async () => {
    const component = render(
      <StatementVariantContext.Provider value={StatementVariant.DEFAULT}>
        <AccessibilityStatementModal />
      </StatementVariantContext.Provider>
    );
    const data = await component.findByText("Disability profiles supported on our website");
    expect(data).toBeTruthy();
  });

  it(`should render no-profiles statement according to variant`, async () => {
    const component = render(
      <StatementVariantContext.Provider value={StatementVariant.NO_PROFILES}>
        <AccessibilityStatementModal />
      </StatementVariantContext.Provider>
    );

    // Wait for the async modal content to load by waiting for something expected to appear
    await component.findByText("Accessibility Statement");

    // Now check that the profile-related text is NOT present
    const profileText = component.queryByText("Disability profiles supported on our website");
    expect(profileText).toBeNull();
  });
});
