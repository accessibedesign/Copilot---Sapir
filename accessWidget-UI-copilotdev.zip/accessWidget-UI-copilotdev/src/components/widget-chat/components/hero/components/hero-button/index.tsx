import BaseIcon from "~/components/base-icon";
import { Fragment, VNode, h } from "preact";
import { BaseButton } from "../../../base-button";
import styles from "./style.scss";

import { useTranslation } from "~/hooks/useTranslation";
import {useStylesheet} from "~/hooks/useStylesheet";

type Props = {
  label: string;
  icon: string;
  onClick: (_e: Event) => void;
  name: string;
};

export function HeroButton(props: Props): VNode {
  const { icon, label, onClick, name } = props;
  const { t } = useTranslation();
  useStylesheet(styles);
  return (
    <Fragment>
      <BaseButton data-testid={name} name={name} onClick={onClick} class="hero-button">
        <BaseIcon class="icon">{icon}</BaseIcon>
        <span>{t(label)}</span>
      </BaseButton>
    </Fragment>
  );
}
