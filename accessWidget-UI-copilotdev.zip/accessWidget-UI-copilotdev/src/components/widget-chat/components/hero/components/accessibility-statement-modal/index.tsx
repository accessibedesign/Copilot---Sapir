import { h, VNode, Fragment } from "preact";
import { useState, useContext } from "preact/hooks";
import { Skeleton } from "~/components/skeleton";
import styles from "./style.scss";
import { useStylesheet } from "~/hooks/useStylesheet";
import { StatementVariantContext } from "~/components/widget-chat/context/statement-variant";
import { StatementVariant } from "~/components/widget-chat/types";

export function AccessibilityStatementModal(): VNode {
  const [content, setContent] = useState("");
  const statementVariant = useContext(StatementVariantContext);

  // lazy load for a large string to improve performance
  switch (statementVariant) {
    case StatementVariant.NO_PROFILES:
      import(
        /* webpackChunkName: "accessibility_statement_content_no_profile_dictionary" */ "./accessibility-statement-content-no-profiles.json"
        ).then(dictionary => setContent(dictionary.statementContent));
      break;
    default:
      import(
        /* webpackChunkName: "accessibility_statement_content_dictionary" */ "./accessibility-statement-content.json"
        ).then(dictionary => setContent(dictionary.statementContent));
  }

  useStylesheet(styles);
  /**
   * show a skeleton loader while dictionary is being loaded
   */
  if (!content) {
    return (
      <Fragment>
        <Skeleton variant="text" height={"30px"} width={"60%"} />
        <br />
        <br />
        <Skeleton variant="text" height={"20px"} width={"40%"} />
        <br />
        <Skeleton variant="text" height={"87px"} />
        <br />
        <Skeleton variant="text" height={"184px"} />
        <br />
        <Skeleton variant="text" height={"104px"} />
        <br />
        <Skeleton variant="text" height={"124px"} />
        <br />
        <Skeleton variant="text" height={"42px"} />
      </Fragment>
    );
  }

  return (
    <Fragment>
      <div
        class="accessibility-statement-modal-content"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{
          __html: content
        }}
      />
    </Fragment>
  );
}
