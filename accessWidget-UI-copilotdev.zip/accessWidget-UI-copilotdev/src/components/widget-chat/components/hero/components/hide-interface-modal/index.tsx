import { h, VNode, Fragment } from "preact";
import { useContext } from "preact/hooks";
import { ModalContext } from "~/context/modal-context";
import { BaseButton } from "~/components/widget-chat/components/base-button";

import styles from "./style.scss";
import { WidgetChatEventEmitter } from "~/components/widget-chat/context/event-emitter";
import { WidgetChatEventType } from "~/components/widget-chat/types";
import { useTranslation } from "~/hooks/useTranslation";
import {useStylesheet} from "~/hooks/useStylesheet";

export function HideInterfaceModal(): VNode {
  const { t } = useTranslation();
  const { toggle } = useContext(ModalContext);
  const emit = useContext(WidgetChatEventEmitter);
  useStylesheet(styles);
  return (
    <Fragment>
      <div class="hide-interface-modal">
        <span class="hide-interface-modal__title">{t("POPUP_HIDE_TITLE")}</span>
        <span class="hide-interface-modal__content">{t("POPUP_HIDE_TEXT")}</span>
        <div class="hide-interface-modal__actions">
          <BaseButton
            class="button button--primary"
            onClick={() => {
              emit({ type: WidgetChatEventType.Hide });
              toggle({ value: false });
            }}
          >
            {t("ACCEPT")}
          </BaseButton>
          <BaseButton class="button button--secondary" onClick={toggle}>
            {t("CANCEL")}
          </BaseButton>
        </div>
      </div>
    </Fragment>
  );
}
