import { h } from "preact";
import { HideInterfaceModal } from "./index";
import { WidgetChatEventType } from "~/components/widget-chat";
import { buildProvidedComponent } from "~/utils/test-utils";
import { fireEvent } from "@testing-library/preact";

describe("Tests `Hide Interface Modal` component functionality", () => {
  it(`should emit hide event toggle modal to close on accept button click`, async () => {
    const onEvent = jest.fn();
    const toggle = jest.fn();
    const component = buildProvidedComponent(<HideInterfaceModal />, { onEvent, toggle });
    const acceptButton = (await component.findAllByRole("button"))[0];
    fireEvent.click(acceptButton);

    expect(onEvent).toHaveBeenCalledWith({ type: WidgetChatEventType.Hide });
    expect(toggle).toHaveBeenCalledWith({
      value: false,
    });
  });

  it(`should emit toggle on cancel button click`, async () => {
    const onEvent = jest.fn();
    const toggle = jest.fn();
    const component = buildProvidedComponent(<HideInterfaceModal />, { onEvent, toggle });
    const cancelButton = (await component.findAllByRole("button"))[1];
    fireEvent.click(cancelButton);

    expect(toggle).toHaveBeenCalled();
  });
});
