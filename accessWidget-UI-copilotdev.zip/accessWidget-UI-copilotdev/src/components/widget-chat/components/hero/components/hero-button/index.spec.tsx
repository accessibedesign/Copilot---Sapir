import { h } from "preact";
import { render } from "~/utils/test-utils";
import { HeroButton } from "./index";
import { useTranslation } from "~/hooks/useTranslation";
import defaultDictionary from "~/components/widget-chat/locale/en.json";
import * as icons from "~/components/widget-chat/assets/icons";
import { fireEvent } from "@testing-library/preact";

describe("Tests `HeroButton` component functionality", () => {
  it(`should call close callback on close button click`, async () => {
    const onClick = jest.fn();

    const component = render(<HeroButton name="x" label="hi" onClick={onClick} icon="g" />);
    const button = await component.findByTestId("x");

    fireEvent.click(button);

    expect(onClick).toHaveBeenCalled();
  });

  it(`should render translated label prop`, async () => {
    const { t } = useTranslation(defaultDictionary);
    const onClick = jest.fn();

    const component = render(<HeroButton name="x" label="STATEMENT" onClick={onClick} icon={icons.bookmark} />);
    const span = await component.findByTestId("x");

    expect(span.textContent).toBe(t("STATEMENT"));
  });
});
