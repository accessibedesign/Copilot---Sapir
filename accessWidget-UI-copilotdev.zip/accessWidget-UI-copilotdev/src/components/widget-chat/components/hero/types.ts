import { VNode } from "preact";
import { WidgetChatEventData } from "../../types";

enum ActionType {
  Toggle = "toggle",
  Emit = "emit",
}

type Actions = {
  [ActionType.Toggle]?: { content?: VNode; value?: boolean };
  [ActionType.Emit]?: WidgetChatEventData;
};
export interface HeroButtonType {
  name: string;
  icon: string;
  label: string;
  actions: Actions;
}
