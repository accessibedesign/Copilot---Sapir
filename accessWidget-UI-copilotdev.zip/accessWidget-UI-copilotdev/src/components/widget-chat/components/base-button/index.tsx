import { ComponentChildren, h, VNode, Fragment } from "preact";
import styles from "./style.scss";
import {useStylesheet} from "~/hooks/useStylesheet";

interface Props {
  class?: string;
  children?: ComponentChildren;
  tabIndex?: number;
  onClick: (e: unknown) => void;
  style?: string;
  name?: string;
  ariaLabel?: string;
}

const defaultProps = {
  tabIndex: 0,
};

export const BaseButton = (props: Props): VNode => {
  useStylesheet(styles);
  return (
    <Fragment>
      <button {...props}>{props.children}</button>
    </Fragment>
  );
};

BaseButton.defaultProps = defaultProps;
