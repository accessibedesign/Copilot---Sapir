import { SearchResult, WikipediaRawResults } from "./service";

export const wikipediaSearchResponse = {
  batchcomplete: "",
  continue: {
    gpsoffset: 3,
    continue: "gpsoffset||",
  },
  warnings: {
    main: {
      "*": "Unrecognized parameter: extracts.",
    },
    query: {
      "*": 'Unrecognized value for parameter "prop": exintro',
    },
  },
  query: {
    pages: {
      340541: {
        pageid: 340541,
        ns: 0,
        title: "GG",
        index: 1,
        pageprops: {
          disambiguation: "",
          "wikibase-shortdesc": "Topics referred to by the same term",
          wikibase_item: "Q225564",
        },
        extract: "GG may refer to:\n\n",
        description: "Topics referred to by the same term",
        descriptionsource: "local",
      },
      433017: {
        pageid: 433017,
        ns: 0,
        title: "GG Allin",
        index: 2,
        pageprops: {
          defaultsort: "Allin, Gg",
          page_image: "Punk_Rock_GG_Allin.jpg",
          "wikibase-shortdesc": "American punk rock musician (1956–1993)",
          wikibase_item: "Q366719",
        },
        extract:
          'Kevin Michael "GG" Allin (born Jesus Christ Allin; August 29, 1956 – June 28, 1993) was an American punk rock musician who performed and recorded with many groups during his career. Allin was best known for his controversial live performances, which often featured transgressive acts, including self-mutilation, defecating on stage, and assaulting audience members, for which he was arrested and imprisoned on multiple occasions. AllMusic called him "the most spectacular degenerate in rock n\' roll history", while G4TV\'s That\'s Tough labelled him the "toughest rock star in the world".\nKnown more for his notorious stage antics than for his music, Allin recorded prolifically, not only in the punk rock genre, but also in spoken word, country, and more traditional-style rock. His lyrics often expressed themes of violence and misanthropy.Allin\'s music was often poorly recorded and produced, given limited distribution, and met with mostly negative reviews from critics, although he maintained a cult following throughout and after his career. Allin promised for several years that he would commit suicide on stage during one of his concerts, but he instead died from an accidental drug overdose on June 28, 1993, at age 36.',
        description: "American punk rock musician (1956–1993)",
        descriptionsource: "local",
      },
      31580610: {
        pageid: 31580610,
        ns: 0,
        title: "GGPO",
        index: 3,
        pageprops: {
          wikibase_item: "Q5513383",
        },
        extract:
          "GGPO (Good Game Peace Out) is middleware designed to help create a near-lagless online experience for various emulated arcade games and fighting games. The program was created by Tony Cannon, co-founder of fighting game community site Shoryuken and the popular Evolution Championship Series.",
      },
    },
  },
};

export const wikipediaSearchEmptyResults = {
  batchcomplete: "",
  warnings: {
    main: {
      "*": 'A POST request was made without a "Content-Type" header. This does not work reliably.\nSubscribe to the mediawiki-api-announce mailing list at <https://lists.wikimedia.org/postorius/lists/mediawiki-api-announce.lists.wikimedia.org/> for notice of API deprecations and breaking changes. Use [[Special:ApiFeatureUsage]] to see usage of deprecated features by your application.\nUnrecognized parameter: extracts.',
    },
    query: {
      "*": 'Unrecognized value for parameter "prop": exintro',
    },
  },
};

export const mockResult: SearchResult[] = [
  {
    index: "01",
    id: 340541,
    title: "GG",
    description: "Topics referred to by the same term",
  },
  {
    index: "02",
    id: 433017,
    title: "GG Allin",
    description: "American punk rock musician (1956–1993)",
  },
  {
    index: "03",
    id: 31580610,
    title: "GGPO",
    description: "",
  },
];

export const mockRawResponse: WikipediaRawResults = {
  340541: {
    pageid: 340541,
    ns: 0,
    title: "GG",
    index: 1,
    pageprops: {
      disambiguation: "",
      "wikibase-shortdesc": "Topics referred to by the same term",
      wikibase_item: "Q225564",
    },
    extract: "GG may refer to:\n\n",
    description: "Topics referred to by the same term",
    descriptionsource: "local",
  },
  433017: {
    pageid: 433017,
    ns: 0,
    title: "GG Allin",
    index: 2,
    pageprops: {
      defaultsort: "Allin, Gg",
      page_image: "Punk_Rock_GG_Allin.jpg",
      "wikibase-shortdesc": "American punk rock musician (1956–1993)",
      wikibase_item: "Q366719",
    },
    extract:
      'Kevin Michael "GG" Allin (born Jesus Christ Allin; August 29, 1956 – June 28, 1993) was an American punk rock musician who performed and recorded with many groups during his career. Allin was best known for his controversial live performances, which often featured transgressive acts, including self-mutilation, defecating on stage, and assaulting audience members, for which he was arrested and imprisoned on multiple occasions. AllMusic called him "the most spectacular degenerate in rock n\' roll history", while G4TV\'s That\'s Tough labelled him the "toughest rock star in the world".\nKnown more for his notorious stage antics than for his music, Allin recorded prolifically, not only in the punk rock genre, but also in spoken word, country, and more traditional-style rock. His lyrics often expressed themes of violence and misanthropy.Allin\'s music was often poorly recorded and produced, given limited distribution, and met with mostly negative reviews from critics, although he maintained a cult following throughout and after his career. Allin promised for several years that he would commit suicide on stage during one of his concerts, but he instead died from an accidental drug overdose on June 28, 1993, at age 36.',
    description: "American punk rock musician (1956–1993)",
    descriptionsource: "local",
  },
  31580610: {
    pageid: 31580610,
    ns: 0,
    title: "GGPO",
    index: 3,
    pageprops: {
      wikibase_item: "Q5513383",
    },
    extract:
      "GGPO (Good Game Peace Out) is middleware designed to help create a near-lagless online experience for various emulated arcade games and fighting games. The program was created by Tony Cannon, co-founder of fighting game community site Shoryuken and the popular Evolution Championship Series.",
  },
};

export const mockRawResponseUnsorted: WikipediaRawResults = {
  340541: {
    pageid: 340541,
    ns: 0,
    title: "GG",
    index: 2,
    pageprops: {
      disambiguation: "",
      "wikibase-shortdesc": "Topics referred to by the same term",
      wikibase_item: "Q225564",
    },
    extract: "GG may refer to:\n\n",
    description: "Topics referred to by the same term",
    descriptionsource: "local",
  },
  433017: {
    pageid: 433017,
    ns: 0,
    title: "GG Allin",
    index: 1,
    pageprops: {
      defaultsort: "Allin, Gg",
      page_image: "Punk_Rock_GG_Allin.jpg",
      "wikibase-shortdesc": "American punk rock musician (1956–1993)",
      wikibase_item: "Q366719",
    },
    extract:
      'Kevin Michael "GG" Allin (born Jesus Christ Allin; August 29, 1956 – June 28, 1993) was an American punk rock musician who performed and recorded with many groups during his career. Allin was best known for his controversial live performances, which often featured transgressive acts, including self-mutilation, defecating on stage, and assaulting audience members, for which he was arrested and imprisoned on multiple occasions. AllMusic called him "the most spectacular degenerate in rock n\' roll history", while G4TV\'s That\'s Tough labelled him the "toughest rock star in the world".\nKnown more for his notorious stage antics than for his music, Allin recorded prolifically, not only in the punk rock genre, but also in spoken word, country, and more traditional-style rock. His lyrics often expressed themes of violence and misanthropy.Allin\'s music was often poorly recorded and produced, given limited distribution, and met with mostly negative reviews from critics, although he maintained a cult following throughout and after his career. Allin promised for several years that he would commit suicide on stage during one of his concerts, but he instead died from an accidental drug overdose on June 28, 1993, at age 36.',
    description: "American punk rock musician (1956–1993)",
    descriptionsource: "local",
  },
  31580610: {
    pageid: 31580610,
    ns: 0,
    title: "GGPO",
    index: 3,
    pageprops: {
      wikibase_item: "Q5513383",
    },
    extract:
      "GGPO (Good Game Peace Out) is middleware designed to help create a near-lagless online experience for various emulated arcade games and fighting games. The program was created by Tony Cannon, co-founder of fighting game community site Shoryuken and the popular Evolution Championship Series.",
  },
};
