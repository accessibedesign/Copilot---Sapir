import { SearchService } from "./service";
import {
  mockRawResponse,
  mockRawResponseUnsorted,
  mockResult,
  wikipediaSearchEmptyResults,
  wikipediaSearchResponse,
} from "./mock";
import { SupportedLanguageCode } from "~/types";

describe("Tests `SearchService` service functionality", () => {
  it(`should return parsed results when receiveng raw wikipedia results`, () => {
    expect(SearchService.parseResults(mockRawResponse)).toStrictEqual(mockResult);
  });

  it(`should return sort parsed results by index`, () => {
    const results = SearchService.parseResults(mockRawResponseUnsorted);
    const isSorted = results.every((v, i, a) => !i || a[i - 1].index <= v.index);
    expect(isSorted).toBe(true);
  });

  const lang = SupportedLanguageCode.EN;
  const input = "gg";
  beforeAll(() => jest.spyOn(window, "fetch"));
  it("should retrive parsed data from wikipedia search", async () => {
    (window.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => wikipediaSearchResponse,
    });
    const results = await SearchService.getResults(input, lang, new AbortController().signal);
    expect(results).toStrictEqual(mockResult);
  });

  it("should return null if wikipedia results are empty", async () => {
    (window.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => wikipediaSearchEmptyResults,
    });
    const results = await SearchService.getResults(input, lang, new AbortController().signal);
    expect(results).toBeFalsy();
  });
});
