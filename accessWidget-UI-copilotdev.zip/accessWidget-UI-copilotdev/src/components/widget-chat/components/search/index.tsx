import { Fragment, h, VNode } from "preact";
import { CloseButton } from "../close-button";
import styles from "./style.scss";
import { useRef, useState } from "preact/hooks";
import { SearchResult, SearchService } from "./service";
import BaseIcon from "~/components/base-icon";
import * as icons from "~/components/widget-chat/assets/icons";

import { useTranslation } from "~/hooks/useTranslation";
import { useStylesheet } from "~/hooks/useStylesheet";

export function Search(): VNode {
  const [searchResults, setSearchResults] = useState<SearchResult[]>(null);
  const { t, language } = useTranslation();
  let controller = new AbortController(); // initialize abortcontroller and signal
  let signal = controller.signal;
  const ref = useRef(null);
  const onSearch = async () => {
    const inputEl = ref.current as HTMLInputElement;
    if (inputEl.value.length <= 1) {
      controller.abort(); // abort the request
      controller = new AbortController(); // reset abort controller and signal
      signal = controller.signal;
      setSearchResults(null);
      return;
    }
    const results = await SearchService.getResults(inputEl.value, language, signal);
    setSearchResults(results);
  };
  useStylesheet(styles);
  return (
    <Fragment>
      <div class="search">
        <div class="search-form">
          <input
            ref={ref}
            class="input"
            type="text"
            tabIndex={0}
            data-testid="search-input"
            name="acsb_search"
            autocomplete="off"
            placeholder={t("SEARCH_PLACEHOLDER_TITLE")}
            aria-label={t("SEARCH_PLACEHOLDER_TITLE")}
            onInput={onSearch}
          />
          <BaseIcon class="prepended-icon">{icons.search}</BaseIcon>
          <BaseIcon class="appended-icon">{icons.chevronDown}</BaseIcon>
        </div>
        {searchResults && (
          <div class="search-results">
            <CloseButton ariaLabel="CLOSE" onClick={() => setSearchResults(null)} />
            <div class="search-results__list">
              {Object.entries(searchResults).map(([_, result]) => (
                <div class="search-result" key={result.id}>
                  <span class="search-result__title">{`${result.index} ${result.title}`}</span>
                  <p class="search-result__description">{result.description}</p>
                  <a
                    class="search-result__link"
                    target="_blank"
                    href={`https://${language}.wikipedia.org/wiki/${result.title}`}
                    rel="noreferrer"
                  >
                    {t("MORE_IN_WIKIPEDIA")}
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </Fragment>
  );
}
