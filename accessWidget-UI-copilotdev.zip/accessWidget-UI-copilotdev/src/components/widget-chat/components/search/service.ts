import { SupportedLanguageCode } from "../../../../types";

export interface WikipediaSearchResult {
  pageid: number;
  ns: number;
  title: string;
  index: number;
  pageprops: {
    defaultsort?: string;
    disambiguation?: string;
    displaytitle?: string;
    page_image?: string;
    "wikibase-shortdesc"?: string;
    wikibase_item?: string;
  };
  extract: string;
  description?: string;
  descriptionsource?: string;
}

export type WikipediaRawResults = { [key: string]: WikipediaSearchResult };

export interface SearchResult {
  index: string;
  id: number;
  title: string;
  description: string;
}

export class SearchService {
  static async getResults(input: string, lang: SupportedLanguageCode, signal: AbortSignal): Promise<SearchResult[]> {
    const res = await fetch(
      `https://${lang}.wikipedia.org/w/api.php?action=query&format=json&utf8=&explaintext=&extracts=&exintro=&generator=prefixsearch&prop=pageprops|extracts|exintro|extracts|description&redirects=&gpssearch=${encodeURIComponent(input)}&gpslimit=3&origin=*`,
      { signal }
    );

    const data = await res.json();

    const searchResults = data?.query?.pages as {
      [key: string]: WikipediaSearchResult;
    };

    if (searchResults) {
      return this.parseResults(searchResults);
    }
  }

  static parseResults(rawResults: WikipediaRawResults): SearchResult[] {
    return Object.values(rawResults)
      .sort((a, b) => (a.index > b.index ? 1 : -1))
      .map((result) => ({
        index: `0${result.index}`,
        id: result.pageid,
        title: result.title,
        description: result.description ?? "",
      }));
  }
}
