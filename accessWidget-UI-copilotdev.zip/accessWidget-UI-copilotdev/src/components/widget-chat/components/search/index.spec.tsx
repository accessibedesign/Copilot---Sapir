import { h } from "preact";
import { render } from "~/utils/test-utils";
import { Search } from "./index";
import { SearchService } from "./service";
import { runAllPromises } from "~/utils/run-all-promises";
import { fireEvent } from "@testing-library/preact";
const mockResponse = [
  {
    index: "01",
    id: 2013813,
    title: "QQQ (disambiguation)",
    description: "Topics referred to by the same term",
  },
  {
    index: "02",
    id: 10335484,
    title: "QQQ",
    description: "Television station in Queensland",
  },
  {
    index: "03",
    id: 2390006,
    title: "QQQQ",
    description: "Topics referred to by the same term",
  },
];
describe("Tests `Search` component functionality", () => {
  beforeEach(() => {
    jest.restoreAllMocks();
  });
  it(`should not fire 'getResults' and should clear previous results if input's length is 1 or less`, async () => {
    jest.spyOn(SearchService, "getResults").mockResolvedValue(mockResponse);
    const component = render(<Search />);
    const input = await component.findByRole("textbox");
    fireEvent.input(input, { target: { value: "1" } });
    expect(SearchService.getResults).not.toHaveBeenCalled();

    fireEvent.input(input, { target: { value: "asd" } });
    await runAllPromises();
    expect(component.container.innerHTML.includes("Television station in Queensland")).toBeTruthy();

    fireEvent.input(input, { target: { value: "a" } });
    await runAllPromises();
    const resultsContainer = component.container.querySelector(".search-results");
    expect(resultsContainer).toBeFalsy();
  });

  it(`should show wikipedia search results on input`, async () => {
    jest.spyOn(SearchService, "getResults").mockResolvedValue(mockResponse);
    const component = render(<Search />);
    const input = await component.findByRole("textbox");
    fireEvent.input(input, { target: { value: "asd" } });
    const resultsContainer = component.container.querySelector(".search-results");
    console.log(resultsContainer);

    await runAllPromises();
    expect(component.container.innerHTML.includes("Television station in Queensland")).toBeTruthy();
  });

  it(`should close search results on close button click`, async () => {
    const component = render(<Search />);
    const input = await component.findByRole("textbox");
    fireEvent.input(input, { target: { value: "asd" } });
    await runAllPromises();
    const closeButton = await component.findByRole("button");
    fireEvent.click(closeButton);

    const resultsContainer = component.container.querySelector(".search-results");
    expect(resultsContainer).toBeFalsy();
  });
});
