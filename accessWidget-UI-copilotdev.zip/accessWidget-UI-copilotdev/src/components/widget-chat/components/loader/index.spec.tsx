import { h } from "preact";
import { render } from "~/utils/test-utils";
import { Loader, State } from "./index";
import { delay } from "~/utils/delay";
import { ShadowRootStateProvider } from "~/hooks/useStylesheet";

describe("Tests `Loader` component functionality", () => {
  it(`should show loader if 'show' prop is true`, async () => {
    const component = render(<Loader show={true} />);
    const loaderEL = await component.findByTestId("loader");
    expect(loaderEL.classList.contains(`loader--${State.PENDING}`)).toBeTruthy();
  });

  it(`should not show loader if 'show' prop is false`, async () => {
    const component = render(<Loader show={false} />);
    const loaderEL = await component.findByTestId("loader");
    expect(loaderEL.classList.contains(`loader--${State.IDLE}`)).toBeTruthy();
  });

  it(`should show success state if 'hasSuccessState' is true and 'show' became true and then false, and after 300ms turns to idle`, async () => {
    const component = render(<Loader show={true} />);
    component.rerender(
      <ShadowRootStateProvider shadowRoot={document as unknown as ShadowRoot}>
        <Loader show={false} />
      </ShadowRootStateProvider>
    );
    const loaderEL = await component.findByTestId("loader");
    expect(loaderEL.classList.contains(`loader--${State.SUCCESS}`)).toBeTruthy();

    await delay(300);

    expect(loaderEL.classList.contains(`loader--${State.IDLE}`)).toBeTruthy();
  });
});
