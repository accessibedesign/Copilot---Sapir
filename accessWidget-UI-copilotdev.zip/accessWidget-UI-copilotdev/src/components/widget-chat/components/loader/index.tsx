import { Fragment, h, VNode } from "preact";
import { useState, useEffect } from "preact/hooks";
import BaseIcon from "~/components/base-icon";
import styles from "./style.scss";
import * as icons from "~/components/widget-chat/assets/icons";
import { useStylesheet } from "~/hooks/useStylesheet";

export enum State {
  IDLE = "idle",
  PENDING = "pending",
  SUCCESS = "success",
}

export interface Props {
  show: boolean;
}

export const Loader = ({ show }: Props): VNode => {
  const [state, setState] = useState(State.IDLE);
  const [prevShow, setPrevShow] = useState(false);

  useEffect(() => {
    /**
     * if the prop 'show' = true, set State to PENDING and set prevShow to true, in order to track for previous show value on next render.
     * if show is false, check if prevShow is true => show SUCCESS state and reset state and prevShow to default states after 300ms.
     */
    if (show) {
      setPrevShow(true);
      setState(State.PENDING);
    } else if (prevShow) {
      setState(State.SUCCESS);
      setTimeout(() => {
        setPrevShow(false);
        setState(State.IDLE);
      }, 300);
    }
  }, [prevShow, show, state]);
  useStylesheet(styles);
  return (
    <Fragment>
      <div data-testid="loader" class={`loader ${`loader--${state}`}`}>
        <div class="loader-container">
          <span class={`loader-container__item loader-container__item--pending`} />
          <BaseIcon class={`loader-container__item loader-container__item--success icon`}>{icons.checkmark}</BaseIcon>

          {/* TODO:  this approach is better since it doesnt pollute the DOM, use this once react-transition-group is implemented */}
          {/* {state == State.PENDING && <span class="loader-container__item loader-container__item--pending" />}
          {state == State.SUCCESS && <BaseIcon class="loader-container__item">{icons.checkmark}</BaseIcon>} */}
        </div>
      </div>
    </Fragment>
  );
};
