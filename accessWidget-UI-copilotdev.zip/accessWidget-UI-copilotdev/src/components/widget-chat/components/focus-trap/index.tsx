/* eslint-disable jsx-a11y/click-events-have-key-events */
import { h, VNode, ComponentChildren, Ref } from "preact";
import { useEffect, useRef } from "preact/hooks";

class FocusTrapLogic {
  private focusableElements: NodeListOf<HTMLElement>;
  /**
   * The first focusable element in the trap
   */
  private firstFocusableEl: HTMLElement;
  /**
   * The last focusable element in the trap
   */
  private lastFocusableEl: HTMLElement;

  /**
   * The Html element that serves as boundary for the trap
   */
  private trapContainer: HTMLElement;

  /**
   * list of all possible selectors for focusable elements
   * @see https://github.com/focus-trap/tabbable/blob/master/src/index.js
   */
  private static focusableElementsSelector = `input,
  select,
  textarea,
  a[href],
  button,
  audio[controls],
  video[controls],
  [contenteditable]:not([contenteditable="false"]),
  details>summary:first-of-type,
  [tabindex]:not([tabindex="-1"]),
  details`;

  constructor(trapContainer: HTMLElement) {
    this.focusableElements = trapContainer.querySelectorAll<HTMLElement>(FocusTrapLogic.focusableElementsSelector);
    this.firstFocusableEl = this.focusableElements[0];
    this.lastFocusableEl = this.focusableElements[this.focusableElements.length - 1];
    this.trapContainer = trapContainer;
    this.handleFocus = this.handleFocus.bind(this);
  }

  /**
   * Sets `keydown` event on the document to intercept keyboard navigation
   */
  listen() {
    document.addEventListener("keydown", this.handleFocus);
  }

  /**
   * Clears the `keydown` event
   */
  clear() {
    document.removeEventListener("keydown", this.handleFocus);
  }

  /**
   * Focuses given html element `el` and prevents default event default behviour
   */
  private handleTabNavigation(e: KeyboardEvent, el: HTMLElement) {
    el.focus();
    e.preventDefault();
  }

  /**
   * Focus the first focusable element in the trap
   * this timeout is done since the transition delay is causing the focus not to work.
   */
  focusFirstElement() {
    setTimeout(() => {
      this.firstFocusableEl.focus();
    }, 500);
  }

  /**
   * Callback listener for the `keydown` event
   * -
   */
  handleFocus(e: KeyboardEvent) {
    const root = this.trapContainer.getRootNode() as ShadowRoot;
    const isTabPressed = e.key === "Tab";

    if (!isTabPressed) {
      return;
    }

    const isContainedInTrap = this.trapContainer.contains(root.activeElement);

    if (!isContainedInTrap) {
      this.handleTabNavigation(e, this.firstFocusableEl);
      return;
    }

    if (this.firstFocusableEl == this.lastFocusableEl) {
      // handles an edge case where the first element is the last element as well, we do not want to allow tab event
      e.preventDefault();
    }

    switch (root.activeElement) {
      /**
       * Handling case when `Shift+Tab` is pressed on the first focusable element in the trap
       */
      case this.firstFocusableEl:
        if (e.shiftKey) {
          this.handleTabNavigation(e, this.lastFocusableEl);
        }
        break;

      /**
       * Handling case when `Tab` is pressed on the last focusable element in the trap
       */
      case this.lastFocusableEl:
        if (!e.shiftKey) {
          this.handleTabNavigation(e, this.firstFocusableEl);
        }
        break;
    }

    /**
     * this is done to prevent from double handling in instances where there are nested focus traps
     */
    e.stopPropagation();
  }
}

const useFocusTrap = (trap: boolean, focusFirstElement: boolean): Ref<Element> => {
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    if (!trap) return; // do not trap children if this is disabled, this is done because our current modals are always in DOM

    const focusTrap = new FocusTrapLogic(ref.current);

    if (focusFirstElement) focusTrap.focusFirstElement();

    focusTrap.listen();

    return () => focusTrap.clear();
  }, [focusFirstElement, trap]);

  return ref;
};

type Props = {
  children: ComponentChildren;
  focusFirstElement: boolean; // an optional argument to prevent default behaviour of focusing the first focusable element
  className?: string;
  active: boolean; // this is done because our modals are always in the DOM, once we change transition mechanism we can conditionally render the modals and this wont be necessary.
} & h.JSX.HTMLAttributes<HTMLDivElement>;

export function FocusTrap(props: Props): VNode {
  const { children, active, focusFirstElement } = props;
  const trap = useFocusTrap(active, focusFirstElement);

  return (
    <div class={props.class} ref={trap as Ref<HTMLDivElement>}>
      {children}
    </div>
  );
}
