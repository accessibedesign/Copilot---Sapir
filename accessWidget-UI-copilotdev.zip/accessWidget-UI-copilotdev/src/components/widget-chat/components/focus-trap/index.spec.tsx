import { h } from "preact";
import { render } from "~/utils/test-utils";
import { FocusTrap } from "./index";
import { delay } from "~/utils/delay";
import userEvent from "@testing-library/user-event";

describe("Tests `FocusTrap` component functionality", () => {
  it(`should render children in first div`, () => {
    const component = render(
      <FocusTrap active={false} focusFirstElement={false}>
        <div class="child-element">hello</div>
      </FocusTrap>
    );

    expect(component.container.querySelectorAll("div")[0].querySelector(".child-element")).toBeTruthy();
  });

  it(`should focus first focusable element if focusFirstElement is true`, async () => {
    const component = render(
      <FocusTrap active={true} focusFirstElement={true}>
        <div class="child-element">
          <button>hi</button>
          <button>hi2</button>
        </div>
      </FocusTrap>
    );
    const trapContainer = component.container.querySelectorAll("div")[0];
    const buttonEl = trapContainer.querySelectorAll("button")[0];
    await delay(500);
    expect(buttonEl == document.activeElement).toBeTruthy();
  });

  it(`should focus to first element in container tab is pressed`, async () => {
    const DummyWrapper = () => (
      <div class="wrapper-element">
        <button>dummy1</button>
        <button>dummy2</button>
        <button>dummy3</button>
        <FocusTrap active={true} focusFirstElement={false}>
          <div class="child-element">
            <button>first</button>
            <button>second</button>
            <button>third</button>
          </div>
        </FocusTrap>
        ,
      </div>
    );
    const component = render(<DummyWrapper />);
    const getButtonEl = (index: number) => trapContainer.querySelectorAll("button")[index];
    const trapContainer = component.container.querySelector(".child-element");
    await userEvent.tab();
    expect(getButtonEl(0)).toHaveFocus();
  });
  it(`should focus to third element in container if shift+tab is pressed`, async () => {
    const DummyWrapper = () => (
      <div class="wrapper-element">
        <button>dummy1</button>
        <button>dummy2</button>
        <button>dummy3</button>
        <FocusTrap active={true} focusFirstElement={false}>
          <div class="child-element">
            <button>first</button>
            <button>second</button>
            <button>third</button>
          </div>
        </FocusTrap>
        ,
      </div>
    );
    const component = render(<DummyWrapper />);
    const getButtonEl = (index: number) => trapContainer.querySelectorAll("button")[index];
    const trapContainer = component.container.querySelector(".child-element");
    getButtonEl(0).focus();
    await userEvent.tab({ shift: true });
    expect(getButtonEl(2)).toHaveFocus();
  });
  it(`should focus to first element in container if tab is pressed and we are on third elemenet`, async () => {
    const DummyWrapper = () => (
      <div class="wrapper-element">
        <button>dummy1</button>
        <button>dummy2</button>
        <button>dummy3</button>
        <FocusTrap active={true} focusFirstElement={false}>
          <div class="child-element">
            <button>first</button>
            <button>second</button>
            <button>third</button>
          </div>
        </FocusTrap>
        ,
      </div>
    );
    const component = render(<DummyWrapper />);
    const getButtonEl = (index: number) => trapContainer.querySelectorAll("button")[index];
    const trapContainer = component.container.querySelector(".child-element");
    getButtonEl(2).focus();
    await userEvent.tab();
    expect(getButtonEl(0)).toHaveFocus();
  });

  it(`should focus to second element in container if shift+tab is pressed and we are on third elemenet`, async () => {
    const DummyWrapper = () => (
      <div class="wrapper-element">
        <button>dummy1</button>
        <button>dummy2</button>
        <button>dummy3</button>
        <FocusTrap active={true} focusFirstElement={false}>
          <div class="child-element">
            <button>first</button>
            <button>second</button>
            <button>third</button>
          </div>
        </FocusTrap>
        ,
      </div>
    );
    const component = render(<DummyWrapper />);
    const getButtonEl = (index: number) => trapContainer.querySelectorAll("button")[index];
    const trapContainer = component.container.querySelector(".child-element");
    getButtonEl(2).focus();
    await userEvent.tab({ shift: true });
    expect(getButtonEl(1)).toHaveFocus();
  });

  it(`should focus to second element in container tab is pressed`, async () => {
    const DummyWrapper = () => (
      <div class="wrapper-element">
        <button>dummy1</button>
        <button>dummy2</button>
        <button>dummy3</button>
        <FocusTrap active={true} focusFirstElement={false}>
          <div class="child-element">
            {/* eslint-disable-next-line jsx-a11y/no-autofocus */}
            <button autoFocus>first</button>
            <button>second</button>
            <button>third</button>
          </div>
        </FocusTrap>
        ,
      </div>
    );
    const component = render(<DummyWrapper />);
    const getButtonEl = (index: number) => trapContainer.querySelectorAll("button")[index];
    const trapContainer = component.container.querySelector(".child-element");
    getButtonEl(0).focus();
    await userEvent.tab();
    expect(getButtonEl(1)).toHaveFocus();
  });

  it(`should have focus on same element in trap container if there is only 1 focusable element`, async () => {
    const DummyWrapper = () => (
      <div class="wrapper-element">
        <button>dummy1</button>
        <button>dummy2</button>
        <button>dummy3</button>
        <FocusTrap active={true} focusFirstElement={false}>
          <div class="child-element">
            <button>first</button>
          </div>
        </FocusTrap>
        ,
      </div>
    );
    const component = render(<DummyWrapper />);
    const getButtonEl = (index: number) => trapContainer.querySelectorAll("button")[index];
    const trapContainer = component.container.querySelector(".child-element");

    await userEvent.tab();
    await userEvent.tab();
    expect(getButtonEl(0)).toHaveFocus();
  });

  it(`should focus outside of focus trap if its not active`, async () => {
    const DummyWrapper = () => (
      <div class="wrapper-element">
        <button>dummy1</button>
        <button>dummy2</button>
        <button>dummy3</button>
        <FocusTrap active={false} focusFirstElement={false}>
          <div class="child-element">
            <button>first</button>
          </div>
        </FocusTrap>
        ,
      </div>
    );
    const component = render(<DummyWrapper />);
    const dummyButtonEl = component.container.querySelector("button")
    await userEvent.tab();
    expect(dummyButtonEl).toHaveFocus();
  });
});
