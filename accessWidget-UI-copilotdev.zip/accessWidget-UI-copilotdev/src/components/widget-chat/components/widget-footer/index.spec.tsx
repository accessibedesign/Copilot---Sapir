import { h } from "preact";
import { render } from "~/utils/test-utils";
import { WidgetChatFooter } from "./index";
describe("Tests `WidgetFooter` component functionality", () => {
  it(`should show default footer content if no 'content' prop is received`, () => {
    const component = render(<WidgetChatFooter />);
    const customContent = component.queryByTestId("custom-footer-content");
    const defaultContent = component.queryByTestId("base-footer-content");
    expect(customContent).toBeFalsy();
    expect(defaultContent).toBeTruthy();
  });
  it(`should render 'content' string if received`, () => {
    const component = render(<WidgetChatFooter content="<b>hello</b>" />);
    const customContent = component.queryByTestId("custom-footer-content");
    const defaultContent = component.queryByTestId("base-footer-content");
    expect(customContent).toBeTruthy();
    expect(defaultContent).toBeFalsy();
  });
});
