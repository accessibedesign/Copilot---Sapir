import { h, VNode, Fragment } from "preact";
import BaseIcon from "~/components/base-icon";
import styles from "./style.scss";
import logo from "./assets/logomono.svg";
import chevronUp from "~/components/widget-chat/assets/icons/chevron_up.svg";
import {sanitizeHtmlString} from "~/utils/sanitize-html-string";

import { useTranslation } from "~/hooks/useTranslation";
import {useStylesheet} from "~/hooks/useStylesheet";

interface Props {
  content?: string;
}

export function WidgetChatFooter({ content }: Props): VNode {
  const { t } = useTranslation();
  useStylesheet(styles);

  return (
    <Fragment>
      <footer class="widget-footer">
        {content && (
          <div
            data-testid="custom-footer-content"
            // the content of the footer is provided by the website owner and is not user-generated content, so it's safe here.
            // eslint-disable-next-line react/no-danger
            dangerouslySetInnerHTML={{
              __html: sanitizeHtmlString(content),
            }}
          />
        )}

        {!content && (
          <a
            data-testid="base-footer-content"
            class="widget-footer__link"
            rel="noopener noreferrer"
            href={`https://${t("DEVELOPER_LINK")}?utm_medium=link&utm_source=widget`}
            target="_blank"
          >
            <div class="footer-link__developer">
              {t("FOOTER_DEVELOPED_BY")}
              <BaseIcon class="developer__logo" variant="img" alt="accessiBe">
                {logo}
              </BaseIcon>
            </div>
            <div class="developer__cta">
              {t("LEARN_MORE")}
              <BaseIcon class="icon">{chevronUp}</BaseIcon>
            </div>
          </a>
        )}
      </footer>
    </Fragment>
  );
}
