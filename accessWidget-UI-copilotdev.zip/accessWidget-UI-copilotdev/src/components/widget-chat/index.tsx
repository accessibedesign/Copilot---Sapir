import { h, VNode } from "preact";
import { WidgetChatHeader } from "./components/header";
import { WIDGET_OPERATION_BUTTON_MAP } from "./components/actions/components/chat/components/chat-button";
import styles from "./style.scss";
import { Hero, HeroButtonName } from "./components/hero";
import { WidgetChatFooter } from "./components/widget-footer";
import { ModalContext } from "../../context/modal-context";
import useModal from "../../hooks/useModal";
import { BaseModal } from "./components/base-modal";
import { WidgetChatEventEmitter } from "./context/event-emitter";
import defaultDictionary from "~/components/widget-chat/locale/en.json";
import { Loader } from "./components/loader";
import { Overlay } from "./components/overlay";
import {
  HideComponentsEnum,
  StatementVariant,
  WidgetChatEventData,
  WidgetChatEventDataLanguageChange,
  WidgetChatEventDataStateChange,
  WidgetChatEventType,
  WidgetChatPosition,
} from "./types";
import { useTranslation } from "~/hooks/useTranslation";
import { useEffect, useRef } from "preact/hooks";
import { FocusTrap } from "./components/focus-trap";
import { useKeyPress } from "~/hooks/useKeyPress";
import { defaultData as defaultLanguageState, LanguageOptions, LanguageStateProvider } from "./context/language-state";
import { AIToolType } from "./components/actions/components/ai-tools/types";
import { useStylesheet } from "~/hooks/useStylesheet";
import { BoxElementName } from "./components/actions/types";
import { StatementVariantContext } from "~/components/widget-chat/context/statement-variant";
import { ChatMessage, MessageRole, ChatButton } from './components/actions/components/chat/types';
import {Chat} from "~/components/widget-chat/components/actions/components/chat";

/**
 * export types for controller project
 */
export {
  WidgetChatEventData,
  WidgetChatEventType,
  WidgetChatPosition,
  WidgetChatEventDataStateChange,
  WidgetChatEventDataLanguageChange,
  WIDGET_OPERATION_BUTTON_MAP,
  BoxElementName,
  ChatMessage,
  MessageRole,
  ChatButton,
  // LanguageOptions,
  // ProfileType,
  // AIToolType,
  // ActiveActions,
  // ActionBoxName
};

type Options = {
  hide: boolean;
};

export type WidgetChatOptions = {
  [K in HideComponentsEnum]?: Options;
} & {
  adjustments?: Partial<Record<BoxElementName, Options>>;
  aiTools?: Partial<Record<AIToolType, Options>>;
  chat?: {
    hide?: boolean;
    onSendMessage?: (msg: string) => void;
  };
};

export interface WidgetChatProps {
  languageOptions?: LanguageOptions;
  options?: WidgetChatOptions;
  visible: boolean;
  statementLink?: string;
  statementVariant?: StatementVariant;
  hasTransition?: boolean;
  loading: boolean;
  leadColor: string;
  footerContent: string;
  onEvent: (_data: WidgetChatEventData) => void;
  state: WidgetChatEventDataStateChange;
  position?: WidgetChatPosition;
}

WidgetChat.defaultProps = {
  position: WidgetChatPosition.LEFT,
  hasTransition: true,
  options: {},
} as WidgetChatProps;

// export import {Chat, ChatProps} from "./components/widget/components/actions/components/chat";

export function WidgetChat({
  visible,
  onEvent,
  state,
  options,
  loading,
  position,
  footerContent,
  leadColor,
  languageOptions,
  hasTransition,
  statementLink,
  statementVariant,
}: WidgetChatProps): VNode {
  const { t, direction } = useTranslation(defaultDictionary);
  const modal = useModal();
  const isEscapePressed = useKeyPress({ targetKey: "Escape" });

  /**
   * this logic removes modal from the page and scrolls back to top once use closes the widget
   */
  const ref = useRef(null);
  useEffect(() => {
    if (!visible) {
      const el = ref.current as HTMLDivElement;
      el.scrollTop = 0;
      modal.toggle({ value: false });
    }
  }, [visible, modal]);

  useEffect(() => {
    // TODO: toggleing the modal off shouldnt be handled here but in the base-modal,
    // this is done temporarily till i apply the fix to stop propogation from useKeyPress hook, so it can be used in multiple places in the DOM.
    if (modal.isOpen) {
      modal.toggle({ value: false });
    } else if (isEscapePressed) {
      onEvent({ type: WidgetChatEventType.Close });
    }
  }, [isEscapePressed]);

  useStylesheet(styles, { "lead-color": leadColor });

  return (
    <div
      dir={direction}
      class={`widget-container widget-container--position-${position} ${visible ? `widget-container--visible` : ""} ${
        hasTransition ? "widget-container--transition" : ""
      }`}
    >
      <WidgetChatEventEmitter.Provider value={onEvent}>
        <LanguageStateProvider value={{ ...defaultLanguageState, ...languageOptions }}>
          <ModalContext.Provider value={modal}>
            <Overlay show={visible} onClick={() => onEvent({ type: WidgetChatEventType.Close })} styles={{ opacity: 0 }}>
              <FocusTrap class="widget-container__trap" active={visible} focusFirstElement={false}>
                <StatementVariantContext.Provider value={statementVariant}>
                <div
                  tabIndex={-1}
                  class={`widget-container__main`}
                  role="dialog"
                  aria-label={t("HERO_TITLE")}
                  aria-modal="true"
                  aria-hidden={!visible}
                >
                  <Overlay show={loading} styles={{ opacity: 0 }}>
                       <Loader show={loading} />
                  </Overlay>
                  <div class='main is-chat' ref={ref}>
                    <WidgetChatHeader options={options} />

                    <Hero
                      links={{ statement: statementLink }}
                      options={{ [HeroButtonName.Statement]: { hide: options.accessibilityStatement?.hide } }}
                    />

                    <div class="main-options">
                            <Chat
                                messages={state.chat?.messages || []}
                                onSendMessage={options.chat?.onSendMessage || (() => {})}
                                loading={state.chat?.loading || false}
                                actions={state.actions}
                            />
                    </div>
                  </div>
                  <WidgetChatFooter content={footerContent} />
                  <BaseModal
                    isOpen={modal.isOpen}
                    close={() => {
                      modal.toggle({ value: false });
                    }}
                  >
                    {modal.content}
                  </BaseModal>
                </div>
                </StatementVariantContext.Provider>
              </FocusTrap>
            </Overlay>
          </ModalContext.Provider>
        </LanguageStateProvider>
      </WidgetChatEventEmitter.Provider>
    </div>
  );
}
