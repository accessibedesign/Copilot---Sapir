import widgetChatConfig from "~/mock/widget-chat-config";
import { WidgetChat, WidgetChatEventType } from ".";
import { WidgetChatPosition } from "./types";
import { render } from "~/utils/test-utils";
import { fireEvent } from "@testing-library/preact";
import { ShadowRootStateProvider } from "~/hooks/useStylesheet";
import { h } from "preact";

describe("Tests `Widget` component functionality", () => {
  for (const position of Object.values(WidgetChatPosition)) {
    it(`should received position as css class, position: ${position}`, async () => {
      const component = render(<WidgetChat {...widgetChatConfig.data} position={position} />);
      const widgetEl = component.container.querySelector(".widget-container");

      expect(widgetEl.classList.contains(`widget-container--position-${position}`)).toBeTruthy();
    });
  }
  for (const hasTransition of [false, true]) {
    it(`should set widget--transition class according to hasTransition: ${hasTransition}`, async () => {
      const component = render(<WidgetChat {...widgetChatConfig.data} hasTransition={hasTransition} />);
      const widgetEl = component.container.querySelector(".widget-container");

      expect(widgetEl.classList.contains(`widget-container--transition`)).toBe(hasTransition);
    });
  }
  it(`should show the widget if it receives 'visible: true'`, async () => {
    const component = render(<WidgetChat {...widgetChatConfig.data} visible={true} />);
    const widgetEl = await component.findByRole("dialog");
    expect(widgetEl).toBeInTheDocument();
  });
  it(`should not show the widget if it recieves 'visible: false'`, async () => {
    const component = render(<WidgetChat {...widgetChatConfig.data} visible={false} />);
    const widgetEl = component.queryByRole("dialog");
    expect(widgetEl).not.toBeInTheDocument();
  });

  it(`should close modal and scroll to top when receiving 'visible' false`, async () => {
    const component = render(<WidgetChat {...widgetChatConfig.data} />);
    const widgetEl = await component.findByRole("dialog");
    const mainEl = widgetEl.querySelector(".main");

    // mimick user scrolling down and have modal open
    mainEl.scrollTop = 200;
    const laguageButton = await component.findByTestId("language-selection-button");
    fireEvent.click(laguageButton);

    const props = {
      ...widgetChatConfig.data,
      visible: false,
    };
    component.rerender(
      <ShadowRootStateProvider shadowRoot={document as unknown as ShadowRoot}>
        <WidgetChat {...props} />
      </ShadowRootStateProvider>
    );

    const isModalOpen = component.queryAllByRole("dialog").length > 1;
    expect(widgetEl.scrollTop === 0).toBe(true);
    expect(isModalOpen).toBeFalsy();
  });

  it(`should emit widget close event on escape keypress`, async () => {
    const onEvent = jest.fn();
    const component = render(<WidgetChat {...widgetChatConfig.data} onEvent={onEvent} />);

    const widgetEl = await component.findByRole("dialog");
    fireEvent.keyDown(widgetEl, { key: "Escape" });

    expect(onEvent).toHaveBeenCalledWith({ type: WidgetChatEventType.Close });
  });

  it(`should close modal on escape keypress`, async () => {
    const onEvent = jest.fn();
    const component = render(<WidgetChat {...widgetChatConfig.data} onEvent={onEvent} />);

    const widgetEl = await component.findByRole("dialog");
    const laguageButton = await component.findByTestId("language-selection-button");
    fireEvent.click(laguageButton);
    fireEvent.keyDown(widgetEl, { key: "Escape" });
    const isModalOpen = component.queryAllByRole("dialog").length > 1;

    expect(isModalOpen).toBeFalsy();
  });

  it(`should send close widget event on overlay click`, () => {
    const onEvent = jest.fn();
    const component = render(<WidgetChat {...widgetChatConfig.data} onEvent={onEvent} />);
    fireEvent.click(component.container.querySelector(".overlay"));
    expect(onEvent).toHaveBeenCalledWith({ type: WidgetChatEventType.Close });
  });

  it(`should close modal when receiving close callback from basemodal`, async () => {
    const component = render(<WidgetChat {...widgetChatConfig.data} />);

    const laguageButton = await component.findByTestId("language-selection-button");
    fireEvent.click(laguageButton);

    const closeButton = await component.findByLabelText("Close");
    fireEvent.click(closeButton);

    const isModalOpen = component.container.querySelector(".base-modal--active");
    expect(isModalOpen).toBeFalsy();
  });
});
