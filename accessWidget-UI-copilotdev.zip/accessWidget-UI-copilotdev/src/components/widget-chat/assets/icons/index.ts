import accessibility from "./accessibility.svg";
import vibrate from "./vibrate.svg";
import chevronDown from "./chevron_down.svg";
import chevronUp from "./chevron_up.svg";
import close from "./close.svg";
import hide from "./hide.svg";
import reset from "./reset.svg";
import bookmark from "./bookmark.svg";
import search from "./search.svg";
import eye from "./eye.svg";
import chain from "./chain.svg";
import target from "./target.svg";
import saturation from "./saturation.svg";
import bullhorn from "./bullhorn.svg";
import invert from "./invert.svg";
import keyboard from "./keyboard.svg";
import sides from "./sides.svg";
import checkmark from "./checkmark.svg";
import letter from "./letter.svg";
import size from "./size.svg";
import space from "./space.svg";
import light from "./light.svg";
import lineHeight from "./line_height.svg";
import link from "./link.svg";
import textCenter from "./text_center.svg";
import contrast from "./contrast.svg";
import links from "./links.svg";
import textJustify from "./text_justify.svg";
import cursor from "./cursor.svg";
import magnifier from "./magnifier.svg";
import textLeft from "./text_left.svg";
import cursorFull from "./cursor_full.svg";
import monochrome from "./monochrome.svg";
import textRight from "./text_right.svg";
import dark from "./dark.svg";
import mouse from "./mouse.svg";
import thought from "./thought.svg";
import focus from "./focus.svg";
import mute from "./mute.svg";
import navigation from "./navigation.svg";
import voice from "./voice.svg";
import font from "./font.svg";
import overlay from "./overlay.svg";
import wordSpacing from "./word_spacing.svg";
import heading from "./heading.svg";
import print from "./print.svg";
import zoom from "./zoom.svg";
import help from "./help.svg";
import question from "./question.svg";
import reading from "./reading.svg";
import image from "./image.svg";
import textSimplifierOff from "./text_simplifier_off.svg";
import textSimplifierOn from "./text_simplifier_on.svg";
import send from "./send.svg";

export {
  accessibility,
  image,
  reset,
  bookmark,
  saturation,
  bullhorn,
  invert,
  search,
  chain,
  keyboard,
  sides,
  checkmark,
  letter,
  size,
  chevronDown,
  light,
  space,
  chevronUp,
  lineHeight,
  target,
  close,
  link,
  textCenter,
  contrast,
  links,
  textJustify,
  cursor,
  magnifier,
  textLeft,
  cursorFull,
  monochrome,
  textRight,
  dark,
  mouse,
  thought,
  eye,
  mute,
  vibrate,
  focus,
  navigation,
  voice,
  font,
  overlay,
  wordSpacing,
  heading,
  print,
  zoom,
  help,
  question,
  hide,
  reading,
  textSimplifierOff,
  textSimplifierOn,
  send,
};
