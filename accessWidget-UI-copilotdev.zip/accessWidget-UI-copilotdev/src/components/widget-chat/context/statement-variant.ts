import { createContext } from "preact";
import { StatementVariant } from "../types";

export const StatementVariantContext = createContext<StatementVariant>(StatementVariant.DEFAULT);