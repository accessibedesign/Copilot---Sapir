import { createContext } from "preact";
import { WidgetChatEventData } from "../types";

export type WidgetChatEventCallback = (_eventData: WidgetChatEventData) => void;

export const WidgetChatEventEmitter = createContext<WidgetChatEventCallback>(null);
