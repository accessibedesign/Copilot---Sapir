import { ComponentChildren, createContext, h, VNode } from "preact";
import { SupportedFlagCode, SupportedLanguageCode } from "~/types";
import { useMemo } from "preact/hooks";
import svgFlags from "./assets/flags";

export type LanguageOptions = {
  [key in SupportedLanguageCode]?: {
    flag?: SupportedFlagCode;
    hidden?: boolean;
  };
};

export type FlagIconsMapping = { [key in SupportedFlagCode]: string };
export type LanguageToFlagMapping = { [key: string]: string };

export const useMergedFlags = (langs: LanguageOptions): LanguageToFlagMapping => {
  const mergedFlags = useMemo(() => {
    const languageToFlagMap: LanguageToFlagMapping = {};
    
    // Map language codes (enum values) to their flag SVGs
    // Object.entries on LanguageOptions gives us enum values as keys (e.g., "en", "en_gb", "en_ca")
    Object.entries(langs).forEach(([languageCode, config]) => {
      if (config?.flag) {
        // languageCode is already the enum value (e.g., "en")
        languageToFlagMap[languageCode] = svgFlags[config.flag];
      }
    });

    return languageToFlagMap;
  }, [langs]);
  
  return mergedFlags;
};

export const defaultData: LanguageOptions = {
  [SupportedLanguageCode.EN]: { flag: SupportedFlagCode.US }, // Default English (US English)
  [SupportedLanguageCode["en-GB"]]: { flag: SupportedFlagCode.GB },
  [SupportedLanguageCode["en-CA"]]: { flag: SupportedFlagCode.CA },
  [SupportedLanguageCode.ES]: { flag: SupportedFlagCode.ES },
  [SupportedLanguageCode.DE]: { flag: SupportedFlagCode.DE },
  [SupportedLanguageCode.PT]: { flag: SupportedFlagCode.PT },
  [SupportedLanguageCode.FR]: { flag: SupportedFlagCode.FR },
  [SupportedLanguageCode.IT]: { flag: SupportedFlagCode.IT },
  [SupportedLanguageCode.HE]: { flag: SupportedFlagCode.IL },
  [SupportedLanguageCode.TW]: { flag: SupportedFlagCode.TW },
  [SupportedLanguageCode.RU]: { flag: SupportedFlagCode.RU },
  [SupportedLanguageCode.AR]: { flag: SupportedFlagCode.JO },
  [SupportedLanguageCode.UA]: { flag: SupportedFlagCode.AE },
  [SupportedLanguageCode.NL]: { flag: SupportedFlagCode.NL },
  [SupportedLanguageCode.ZH]: { flag: SupportedFlagCode.CN },
  [SupportedLanguageCode.JA]: { flag: SupportedFlagCode.JP },
  [SupportedLanguageCode.PL]: { flag: SupportedFlagCode.PL },
  [SupportedLanguageCode.TR]: { flag: SupportedFlagCode.TR },
  [SupportedLanguageCode.SL]: { flag: SupportedFlagCode.SI },
  [SupportedLanguageCode.CS]: { flag: SupportedFlagCode.CZ },
  [SupportedLanguageCode.HU]: { flag: SupportedFlagCode.HU },
  [SupportedLanguageCode.SK]: { flag: SupportedFlagCode.SK },
  [SupportedLanguageCode.NO]: { flag: SupportedFlagCode.NO },
  [SupportedLanguageCode.SV]: { flag: SupportedFlagCode.SV },
  [SupportedLanguageCode.FI]: { flag: SupportedFlagCode.FI },
  [SupportedLanguageCode.UK]: { flag: SupportedFlagCode.UK },
  [SupportedLanguageCode.RO]: { flag: SupportedFlagCode.RO },
  [SupportedLanguageCode.GA]: { flag: SupportedFlagCode.IE },
  [SupportedLanguageCode.EL]: { flag: SupportedFlagCode.GR },
  [SupportedLanguageCode.SR]: { flag: SupportedFlagCode.RS },
  [SupportedLanguageCode.BS]: { flag: SupportedFlagCode.BA },
  [SupportedLanguageCode.HR]: { flag: SupportedFlagCode.HR },
  [SupportedLanguageCode.LB]: { flag: SupportedFlagCode.LU },
  [SupportedLanguageCode.SQ]: { flag: SupportedFlagCode.AL },
  [SupportedLanguageCode.DA]: { flag: SupportedFlagCode.DK },
};
export type LanguageStateContextValue = {
  flags: LanguageToFlagMapping;
  availableLanguages: { [k: string]: SupportedLanguageCode };
};

export const LanguageStateContext = createContext<LanguageStateContextValue>(undefined);

export const LanguageStateProvider = ({
  children,
  value,
}: {
  children: ComponentChildren;
  value: LanguageOptions;
}): VNode => {
  // merged the received language options with the default language options object
  const mergedLanguageData = Object.fromEntries(
    Object.entries(defaultData).map(([key, val]) => [key, { ...val, ...value[key] }])
  );
  const flags = useMergedFlags(mergedLanguageData);

  const filteredLanguages = Object.fromEntries(
    Object.entries(SupportedLanguageCode).filter(([_, language]) => !value[language].hidden)
  );
  return (
    <LanguageStateContext.Provider value={{ flags, availableLanguages: filteredLanguages }}>
      {children}
    </LanguageStateContext.Provider>
  );
};
