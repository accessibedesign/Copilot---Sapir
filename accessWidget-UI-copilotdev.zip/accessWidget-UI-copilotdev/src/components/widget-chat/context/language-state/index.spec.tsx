import { useMergedFlags, LanguageOptions } from "./index";
import { SupportedLanguageCode, SupportedFlagCode } from "~/types";

// Mock the svgFlags module
jest.mock("./assets/flags", () => ({
  __esModule: true,
  default: {
    us: "<svg>US Flag</svg>",
    gb: "<svg>GB Flag</svg>",
    ca: "<svg>CA Flag</svg>",
    es: "<svg>ES Flag</svg>",
  },
}));

// Mock useMemo to return the computed value directly
jest.mock("preact/hooks", () => ({
  useMemo: (fn: () => any) => fn(),
}));

describe("useMergedFlags", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("should map language codes to flag SVGs when config.flag exists", () => {
    const langs: LanguageOptions = {
      [SupportedLanguageCode.EN]: { flag: SupportedFlagCode.US },
      [SupportedLanguageCode["en-GB"]]: { flag: SupportedFlagCode.GB },
      [SupportedLanguageCode.ES]: { flag: SupportedFlagCode.ES },
    };

    const result = useMergedFlags(langs);

    expect(result[SupportedLanguageCode.EN]).toBe("<svg>US Flag</svg>");
    expect(result[SupportedLanguageCode["en-GB"]]).toBe("<svg>GB Flag</svg>");
    expect(result[SupportedLanguageCode.ES]).toBe("<svg>ES Flag</svg>");
  });

  it("should not include language codes when config.flag is undefined", () => {
    const langs: LanguageOptions = {
      [SupportedLanguageCode.EN]: { flag: SupportedFlagCode.US },
      [SupportedLanguageCode["en-GB"]]: { flag: undefined },
      [SupportedLanguageCode.ES]: { hidden: true },
    };

    const result = useMergedFlags(langs);

    expect(result[SupportedLanguageCode.EN]).toBe("<svg>US Flag</svg>");
    expect(result[SupportedLanguageCode["en-GB"]]).toBeUndefined();
    expect(result[SupportedLanguageCode.ES]).toBeUndefined();
  });

  it("should not include language codes when config is undefined", () => {
    const langs: LanguageOptions = {
      [SupportedLanguageCode.EN]: { flag: SupportedFlagCode.US },
      [SupportedLanguageCode["en-GB"]]: undefined,
    };

    const result = useMergedFlags(langs);

    expect(result[SupportedLanguageCode.EN]).toBe("<svg>US Flag</svg>");
    expect(result[SupportedLanguageCode["en-GB"]]).toBeUndefined();
  });

  it("should not include language codes when config is null", () => {
    const langs: LanguageOptions = {
      [SupportedLanguageCode.EN]: { flag: SupportedFlagCode.US },
      [SupportedLanguageCode["en-GB"]]: null as any,
    };

    const result = useMergedFlags(langs);

    expect(result[SupportedLanguageCode.EN]).toBe("<svg>US Flag</svg>");
    expect(result[SupportedLanguageCode["en-GB"]]).toBeUndefined();
  });

  it("should handle empty language options", () => {
    const langs: LanguageOptions = {};

    const result = useMergedFlags(langs);

    expect(Object.keys(result)).toHaveLength(0);
  });

  it("should handle language options with only hidden flags", () => {
    const langs: LanguageOptions = {
      [SupportedLanguageCode.EN]: { hidden: true },
      [SupportedLanguageCode["en-GB"]]: { hidden: true, flag: undefined },
    };

    const result = useMergedFlags(langs);

    expect(Object.keys(result)).toHaveLength(0);
  });

  it("should handle mixed scenarios with flags, undefined flags, and undefined configs", () => {
    const langs: LanguageOptions = {
      [SupportedLanguageCode.EN]: { flag: SupportedFlagCode.US },
      [SupportedLanguageCode["en-GB"]]: { flag: undefined },
      [SupportedLanguageCode["en-CA"]]: { flag: SupportedFlagCode.CA },
      [SupportedLanguageCode.ES]: undefined,
      [SupportedLanguageCode.DE]: { hidden: true },
    };

    const result = useMergedFlags(langs);

    expect(result[SupportedLanguageCode.EN]).toBe("<svg>US Flag</svg>");
    expect(result[SupportedLanguageCode["en-CA"]]).toBe("<svg>CA Flag</svg>");
    expect(result[SupportedLanguageCode["en-GB"]]).toBeUndefined();
    expect(result[SupportedLanguageCode.ES]).toBeUndefined();
    expect(result[SupportedLanguageCode.DE]).toBeUndefined();
    expect(Object.keys(result)).toHaveLength(2);
  });
});

