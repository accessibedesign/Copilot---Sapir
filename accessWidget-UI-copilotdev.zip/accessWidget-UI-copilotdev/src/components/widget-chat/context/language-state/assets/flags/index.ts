import jo from "./jo.svg";
import de from "./de.svg";
import us from "./us.svg";
import gb from "./gb.svg";
import ca from "./ca.svg";
import es from "./es.svg";
import fr from "./fr.svg";
import il from "./il.svg";
import it from "./it.svg";
import jp from "./jp.svg";
import nl from "./nl.svg";
import pl from "./pl.svg";
import pt from "./pt.svg";
import br from "./br.svg";
import ru from "./ru.svg";
import tr from "./tr.svg";
import tw from "./tw.svg";
import ae from "./ae.svg";
import cn from "./cn.svg";
import cz from "./cz.svg";
import si from "./si.svg";
import hu from "./hu.svg";
import sk from "./sk.svg";
import no from "./no.svg";
import sv from "./sv.svg";
import fi from "./fi.svg";
import uk from "./uk.svg";
import ro from "./ro.svg";
import ie from "./ie.svg";
import gr from "./gr.svg";
import rs from "./rs.svg";
import ba from "./ba.svg";
import hr from "./hr.svg";
import lu from "./lu.svg";
import al from "./al.svg";
import dk from "./dk.svg";


export default {
  us,
  gb,
  ca,
  il,
  jp,
  br,
  ae,
  cn,
  jo,
  de,
  es,
  fr,
  it,
  nl,
  pl,
  pt,
  ru,
  tr,
  tw,
  cz,
  si,
  hu,
  sk,
  no,
  sv,
  fi,
  uk,
  ro,
  ie,
  gr,
  rs,
  ba,
  hr,
  lu,
  al,
  dk,
};
