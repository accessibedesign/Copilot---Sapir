import { ComponentChildren, h, VNode, Fragment, JSX } from "preact";
import styles from "./style.scss";
import {useStylesheet} from "~/hooks/useStylesheet";

type Props = {
  class?: string;
  children?: ComponentChildren;
} & JSX.HTMLAttributes<HTMLButtonElement>;

const defaultProps = {
  tabIndex: 0,
};

export const BaseButton = (props: Props): VNode => {
  useStylesheet(styles);
  return (
    <Fragment>
      <button {...props}>{props.children}</button>
    </Fragment>
  );
};

BaseButton.defaultProps = defaultProps;
