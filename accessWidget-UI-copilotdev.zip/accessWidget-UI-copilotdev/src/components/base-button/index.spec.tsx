/* eslint-disable @typescript-eslint/no-empty-function */
import { h } from "preact";
import { render } from "~/utils/test-utils";
import { BaseButton } from "./index";
import { fireEvent } from "@testing-library/preact";

describe("Tests `BaseButton` component functionality", () => {
  it(`should call onClick callback button click`, async () => {
    const onClick = jest.fn();

    const component = render(<BaseButton onClick={onClick} />);
    const button = await component.findByRole("button");
    fireEvent.click(button);

    expect(onClick).toHaveBeenCalled();
  });

  it(`should render children inside the button`, async () => {
    const children = <div class="test-child">hi</div>;
    const component = render(<BaseButton onClick={() => {}}>{children}</BaseButton>);
    const button = await component.findByRole("button");
    const childrenEl = button.querySelector("div.test-child");

    expect(childrenEl).toBeTruthy();
  });
});
