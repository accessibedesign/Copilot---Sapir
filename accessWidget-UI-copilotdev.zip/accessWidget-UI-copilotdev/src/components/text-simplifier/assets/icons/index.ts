import textSimplifierLogo from "./text_simplifier_logo.svg";
import closeButton from "./close_button.svg";
import accessibe from "./accessibe.svg";
import thumbsUp from "./thumbs_up.svg";
import thumbsUpPressed from "./thumbs_up_pressed.svg";
import thumbsDown from "./thumbs_down.svg";
import backArrow from "./back_arrow.svg";
import submitArrow from "./submit_arrow.svg";
import error from "./error.svg";

export {
  textSimplifierLogo,
  closeButton,
  accessibe,
  thumbsUp,
  thumbsUpPressed,
  thumbsDown,
  backArrow,
  submitArrow,
  error,
};
