import { h } from "preact";
import { render } from "~/utils/test-utils";
import { TextSimplifierHeader } from "./index";
import { fireEvent } from "@testing-library/preact";

describe("Tests `Header` component functionality", () => {
  it(`should send an event of Close when close button is pressed`, () => {
    const onEventMock = jest.fn();
    const component = render(<TextSimplifierHeader onEvent={onEventMock} leadColor="#ff" />);

    const closeButton = component.getByTestId("close-button");
    fireEvent.click(closeButton);

    expect(onEventMock).toHaveBeenCalledTimes(1);
    expect(onEventMock).toHaveBeenCalledWith({ type: "Close" });
  });
});
