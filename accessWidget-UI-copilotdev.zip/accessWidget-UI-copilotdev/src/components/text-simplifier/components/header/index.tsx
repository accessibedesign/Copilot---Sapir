import BaseIcon from "~/components/base-icon";
import * as icons from "~/components/text-simplifier/assets/icons";
import { BaseButton } from "~/components/base-button";
import { h } from "preact";
import style from "./style.scss";
import { useStylesheet } from "~/hooks/useStylesheet";
import { useTranslation } from "~/hooks/useTranslation";
import { TextSimplifierEventData, TextSimplifierEventType } from "~/components/text-simplifier";

export type TextSimplifierHeaderProps = {
  onEvent: (event: TextSimplifierEventData) => void;
  leadColor: string;
};

export function TextSimplifierHeader({ onEvent, leadColor }: TextSimplifierHeaderProps) {
  useStylesheet(style, { "lead-color": leadColor });
  const { t } = useTranslation();

  return (
    <div class="text-simplifier-header">
      <div class="text-simplifier-header__title">
        <BaseIcon>{icons.textSimplifierLogo}</BaseIcon>
        <span class="text-simplifier-header__text">{t("TEXT_SIMPLIFIER_TITLE")}</span>
      </div>
      <BaseButton
        data-testid="close-button"
        class="text-simplifier-header__close"
        onClick={() => onEvent({ type: TextSimplifierEventType.Close })}
      >
        <BaseIcon>{icons.closeButton}</BaseIcon>
      </BaseButton>
    </div>
  );
}
