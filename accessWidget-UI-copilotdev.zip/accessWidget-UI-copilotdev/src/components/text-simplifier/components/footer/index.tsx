import BaseIcon from "~/components/base-icon";
import * as icons from "~/components/text-simplifier/assets/icons";
import { h } from "preact";
import style from "./style.scss";
import { useStylesheet } from "~/hooks/useStylesheet";
import { useTranslation } from "~/hooks/useTranslation";


export function TextSimplifierFooter() {
  useStylesheet(style);
  const { t, direction } = useTranslation();

  return (
    <div class="text-simplifier-footer" dir={"ltr"}>
      <span class="text-simplifier-footer__branding">
        By <BaseIcon>{icons.accessibe}</BaseIcon>
      </span>
      <span dir={direction} class="text-simplifier-footer__disclaimer">
        {t("TEXT_SIMPLIFIER_WARNING")}
      </span>
    </div>
  );
}
