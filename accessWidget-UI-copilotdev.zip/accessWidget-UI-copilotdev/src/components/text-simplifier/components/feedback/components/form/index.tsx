import { TextSimplifierEventData, TextSimplifierEventType } from "~/components/text-simplifier";
import BaseIcon from "~/components/base-icon";
import * as icons from "~/components/text-simplifier/assets/icons";
import { h } from "preact";
import { useTranslation } from "~/hooks/useTranslation";
import { useStylesheet } from "~/hooks/useStylesheet";
import style from "./style.scss";

export type TextSimplifierFeedbackFormProps = {
  onEvent: (event: TextSimplifierEventData) => void;
};

export function TextSimplifierFeedbackForm({ onEvent }: TextSimplifierFeedbackFormProps) {
  useStylesheet(style);
  const { t } = useTranslation();

  const handleSubmit = (event: Event) => {
    event.preventDefault();
    const data = new FormData(event.target as HTMLFormElement);
    const content = data.get("feedback-content").toString();
    onEvent({ type: TextSimplifierEventType.Submit, content });
  };

  return (
    <form
      class="text-simplifier-feedback-form"
      data-testid="feedback-state"
      onSubmit={handleSubmit}
    >
      <div class="text-simplifier-feedback-form__textarea">
        <div class="text-simplifier-feedback-form__title">
          <div>{t("TEXT_SIMPLIFIER_FEEDBACK_TITLE")}</div>
          <div class="text-simplifier-feedback-form__optional">{t("TEXT_SIMPLIFIER_FEEDBACK_TITLE_OPTIONAL")}</div>
        </div>

        <textarea
          data-testid="feedback-content"
          name={"feedback-content"}
          placeholder={t("TEXT_SIMPLIFIER_FEEDBACK_PLACEHOLDER")}
        />
      </div>
      <div class="text-simplifier-feedback-form__buttons">
        <button
          data-testid="cancel-button"
          type={"button"}
          className="text-simplifier-feedback-form__cancel"
          onClick={() => onEvent({ type: TextSimplifierEventType.Cancel })}
        >
          {t("TEXT_SIMPLIFIER_FEEDBACK_CANCEL")}
        </button>
        <button data-testid="submit-button" className="text-simplifier-feedback-form__submit" type={"submit"}>
          {t("TEXT_SIMPLIFIER_FEEDBACK_SUBMIT")}
          <BaseIcon class="text-simplifier-feedback-form__submit-icon">{icons.submitArrow}</BaseIcon>
        </button>
      </div>
    </form>
  );
}
