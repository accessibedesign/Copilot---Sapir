import BaseIcon from "~/components/base-icon";
import * as icons from "~/components/text-simplifier/assets/icons";
import { h } from "preact";
import style from "./style.scss";
import { useStylesheet } from "~/hooks/useStylesheet";
import { useTranslation } from "~/hooks/useTranslation";
import { TextSimplifierEventData, TextSimplifierEventType } from "~/components/text-simplifier";
import { TextSimplifierFeedbackForm } from "~/components/text-simplifier/components/feedback/components/form";

export type TextSimplifierFeedbackProps = {
  onEvent: (event: TextSimplifierEventData) => void;
  leadColor: string;
};

export function TextSimplifierFeedback({ onEvent, leadColor }: TextSimplifierFeedbackProps) {
  useStylesheet(style, { "lead-color": leadColor });
  const { t, direction } = useTranslation();

  return (
    <div class="text-simplifier-feedback" dir={direction}>
      <span class="text-simplifier-feedback__separator" />
      <button
        data-testid="back-button"
        className="text-simplifier-feedback__back"
        onClick={() => onEvent({ type: TextSimplifierEventType.Back })}
      >
        <BaseIcon class={"text-simplifier-feedback__backarrow"}>{icons.backArrow}</BaseIcon> {t("TEXT_SIMPLIFIER_BACK")}
      </button>
      <TextSimplifierFeedbackForm onEvent={onEvent} />
    </div>
  );
}
