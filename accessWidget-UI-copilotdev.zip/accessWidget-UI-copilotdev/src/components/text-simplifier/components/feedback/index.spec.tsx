import { h } from "preact";
import { render } from "~/utils/test-utils";
import { TextSimplifierFeedback } from "./index";
import { fireEvent } from "@testing-library/preact";

describe("Tests `ThumbsDownFeedback` component functionality", () => {
  it(`should send an event of type 'Cancel' when 'Cancel' is clicked`, () => {
    const onEventMock = jest.fn();

    const component = render(<TextSimplifierFeedback leadColor={"#ffffff"} onEvent={onEventMock} />);

    const closeButton = component.getByTestId("cancel-button");
    fireEvent.click(closeButton);

    expect(onEventMock).toHaveBeenCalledTimes(1);
    expect(onEventMock).toHaveBeenCalledWith({ type: "Cancel" });
  });

  it(`should send an event when 'Back' is clicked`, () => {
    const onEventMock = jest.fn();
    const component = render(<TextSimplifierFeedback leadColor={"#ffffff"} onEvent={onEventMock} />);
    const backButton = component.getByTestId("back-button");
    fireEvent.click(backButton);

    expect(onEventMock).toHaveBeenCalledTimes(1);
    expect(onEventMock).toHaveBeenCalledWith({ type: "Back" });
  });

  it(`should send an event when 'Submit' is clicked`, () => {
    const onEventMock = jest.fn();
    const component = render(<TextSimplifierFeedback leadColor={"#ffffff"} onEvent={onEventMock} />);
    const backButton = component.getByTestId("submit-button");
    const feedbackTexarea = component.getByTestId("feedback-content");
    feedbackTexarea.textContent = 'This is a test feedback';
    fireEvent.click(backButton);

    expect(onEventMock).toHaveBeenCalledTimes(1);
    expect(onEventMock).toHaveBeenCalledWith({ type: "Submit", content: 'This is a test feedback' });
  });
});
