import { h } from "preact";
import style from "./style.scss";
import { useStylesheet } from "~/hooks/useStylesheet";
import { Skeleton } from "~/components/skeleton";

export function TextSimplifierSkeleton() {
  useStylesheet(style);

  return (
    <div class="text-simplifier-skeleton" data-testid="loading-state">
      <Skeleton className={"text-simplifier-skeleton__line"} variant="text" height={"22px"} width={"100%"} />
      <Skeleton className={"text-simplifier-skeleton__line"} variant="text" height={"22px"} width={"50%"} />
    </div>
  );
}
