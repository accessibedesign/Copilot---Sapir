import { h } from "preact";
import { render } from "~/utils/test-utils";
import { TextSimplifierContent } from "./index";
import { fireEvent } from "@testing-library/preact";
import { FeedbackOption } from "~/components/text-simplifier";

describe("Tests `SimplifiedVersionContent` component functionality", () => {
  let onEvent: jest.Mock;

  const setup = (isThumbsUpPressed = false) => {
    return render(
      <TextSimplifierContent
        onEvent={onEvent}
        feedback={isThumbsUpPressed ? FeedbackOption.ThumbsUp : FeedbackOption.ThumbsDown}
        simplifiedText="Test"
        leadColor="#ff"
      />,
    );
  };

  beforeEach(() => {
    onEvent = jest.fn();
  });

  it("should send event of thumbs-up if thumbs-up is pressed", () => {
    const component = setup(false);

    const thumbsUpButton = component.getByTestId("thumbs-up-button");
    fireEvent.click(thumbsUpButton);

    expect(onEvent).toHaveBeenCalledTimes(1);
    expect(onEvent).toHaveBeenCalledWith({ type: "ThumbsUp" });
  });

  it("should send event of thumbs-down if thumbs-down is pressed", () => {
    const component = setup(false);

    const thumbsUpButton = component.getByTestId("thumbs-down-button");
    fireEvent.click(thumbsUpButton);

    expect(onEvent).toHaveBeenCalledTimes(1);
    expect(onEvent).toHaveBeenCalledWith({ type: "ThumbsDown" });
  });

  it("should show the thank-you message on the screen if thumbs-up is pressed", () => {
    const component = setup(true);

    expect(component.getByTestId("thank-you-message")).toBeInTheDocument();
  });
});
