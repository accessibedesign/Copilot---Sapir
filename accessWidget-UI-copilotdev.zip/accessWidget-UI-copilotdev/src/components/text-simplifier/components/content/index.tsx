import { h } from "preact";
import style from "./style.scss";
import { useStylesheet } from "~/hooks/useStylesheet";
import { TextSimplifierFooter } from "~/components/text-simplifier/components/footer";
import { FeedbackOption, TextSimplifierEventData } from "~/components/text-simplifier";
import { TextSimplifierSimplifiedVersion } from "~/components/text-simplifier/components/content/components/simplified-version";
import { useTranslation } from "~/hooks/useTranslation";

export type TextSimplifierContentProps = {
  leadColor: string;
  simplifiedText: string;
  feedback: FeedbackOption;
  onEvent: (event: TextSimplifierEventData) => void;
};

export function TextSimplifierContent({
  leadColor,
  simplifiedText,
  feedback,
  onEvent,
}: TextSimplifierContentProps) {
  useStylesheet(style, { "lead-color": leadColor });
  useTranslation();

  return (
    <div class="text-simplifier-content" data-testid="content-state">
      <TextSimplifierSimplifiedVersion simplifiedText={simplifiedText} feedback={feedback} onEvent={onEvent} />
      <TextSimplifierFooter />
    </div>
  );
}
