import { FeedbackOption, TextSimplifierEventData, TextSimplifierEventType } from "~/components/text-simplifier";
import { h } from "preact";
import { useTranslation } from "~/hooks/useTranslation";
import { useStylesheet } from "~/hooks/useStylesheet";
import style from "./style.scss";
import { TextSimplifierRatingButton } from "./components/button";
import BaseIcon from "~/components/base-icon";
import * as icons from "~/components/text-simplifier/assets/icons";
import { BaseButton } from "~/components/base-button";

export type TextSimplifierRatingProps = {
  feedback: FeedbackOption;
  onEvent: (event: TextSimplifierEventData) => void;
};

export function TextSimplifierRating({ feedback, onEvent }: TextSimplifierRatingProps) {
  const { t } = useTranslation();
  useStylesheet(style);

  return (
    <div class="text-simplifier-feedback-buttons">
      <TextSimplifierRatingButton tooltipText={t("TEXT_SIMPLIFIER_FEEDBACK_TOOLTIP_POSITIVE")}>
        <BaseButton data-testid="thumbs-up-button" onClick={() => onEvent({ type: TextSimplifierEventType.ThumbsUp })}>
          {feedback === FeedbackOption.ThumbsUp ? (
            <BaseIcon>{icons.thumbsUpPressed}</BaseIcon>
          ) : (
            <BaseIcon>{icons.thumbsUp}</BaseIcon>
          )}
        </BaseButton>
      </TextSimplifierRatingButton>

      <TextSimplifierRatingButton tooltipText={t("TEXT_SIMPLIFIER_FEEDBACK_TOOLTIP_NEGATIVE")}>
        <BaseButton
          data-testid="thumbs-down-button"
          onClick={() => onEvent({ type: TextSimplifierEventType.ThumbsDown })}
        >
          <BaseIcon>{icons.thumbsDown}</BaseIcon>
        </BaseButton>
      </TextSimplifierRatingButton>

      {feedback === FeedbackOption.ThumbsUp && (
        <span data-testid="thank-you-message" class="text-simplifier-feedback-buttons__thanks">
          {t("TEXT_SIMPLIFIER_THANK_YOU")}
        </span>
      )}
    </div>
  );
}
