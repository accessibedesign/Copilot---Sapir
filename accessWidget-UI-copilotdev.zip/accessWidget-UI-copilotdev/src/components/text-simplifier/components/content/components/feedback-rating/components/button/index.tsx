import { ComponentChildren, h } from "preact";
import { useStylesheet } from "~/hooks/useStylesheet";
import style from "./style.scss";

export type TextSimplifierFeedbackButtonProps = {
  children: ComponentChildren;
  tooltipText: string;
};

export function TextSimplifierRatingButton({ children, tooltipText }: TextSimplifierFeedbackButtonProps) {
  useStylesheet(style);
  return (
    <div class="text-simplifier-feedback-button">
      <div class="text-simplifier-feedback-button__tooltip">{tooltipText}</div>
      {children}
    </div>
  );
}
