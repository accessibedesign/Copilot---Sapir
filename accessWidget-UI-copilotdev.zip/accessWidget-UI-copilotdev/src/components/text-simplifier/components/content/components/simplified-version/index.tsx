import { FeedbackOption, TextSimplifierEventData } from "~/components/text-simplifier";
import { h } from "preact";
import { useTranslation } from "~/hooks/useTranslation";
import { useStylesheet } from "~/hooks/useStylesheet";
import style from "./style.scss";
import { TextSimplifierRating } from "~/components/text-simplifier/components/content/components/feedback-rating/";

export type TextSimplifierFeedbackProps = {
  simplifiedText: string;
  feedback: FeedbackOption;
  onEvent: (event: TextSimplifierEventData) => void;
};

export function TextSimplifierSimplifiedVersion({ simplifiedText, feedback, onEvent }: TextSimplifierFeedbackProps) {
  const { t } = useTranslation();
  useStylesheet(style);

  return (
    <div class="text-simplifier-version">
      <span class="text-simplifier-version__title">{t("TEXT_SIMPLIFIER_SIMPLIFIED_VERSION")}</span>
      <div class="text-simplifier-version__content">
        <span class="text-simplifier-version__line" />
        <div class="text-simplifier-version__text">{simplifiedText}</div>
      </div>
      <TextSimplifierRating feedback={feedback} onEvent={onEvent} />
    </div>
  );
}
