import BaseIcon from "~/components/base-icon";
import * as icons from "~/components/text-simplifier/assets/icons";
import { h, VNode } from "preact";
import style from "./style.scss";
import { useStylesheet } from "~/hooks/useStylesheet";
import { useTranslation } from "~/hooks/useTranslation";
import { TextSimplifierErrorType } from "./types";

export type TextSimplifierErrorProps = {
  errorType?: TextSimplifierErrorType;
};

export function TextSimplifierError({ errorType = TextSimplifierErrorType.GENERAL }: TextSimplifierErrorProps): VNode {
  useStylesheet(style);
  const { t, direction } = useTranslation();

  const titleKey = `TEXT_SIMPLIFIER_${errorType}_ERROR_TITLE`;
  const messageKey = `TEXT_SIMPLIFIER_${errorType}_ERROR_MESSAGE`;

  return (
    <div id="error-state" class="text-simplifier-error" dir={direction} role="alert">
      <BaseIcon>{icons.error}</BaseIcon>
      <div class="text-simplifier-error__content">
        <span class="text-simplifier-error__title">{t(titleKey)}</span>
        <span class="text-simplifier-error__message">{t(messageKey)}</span>
      </div>
    </div>
  );
}
