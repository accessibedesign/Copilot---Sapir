export enum TextSimplifierErrorType {
  GENERAL = "GENERAL",
  LIMIT = "LIMIT",
}
