export enum TextSimplifierEventType {
  Close = "Close",
  Cancel = "Cancel",
  Back = "Back",
  Submit = "Submit",
  ThumbsUp = "ThumbsUp",
  ThumbsDown = "ThumbsDown",
}

export interface TextSimplifierEventData  {
  type: TextSimplifierEventType,
  content?: string;
}
