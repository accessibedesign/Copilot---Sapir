import { h } from "preact";
import { render } from "~/utils/test-utils";
import { FeedbackOption, TextSimplifier } from "./index";

describe("Tests `TextSimplifier` component functionality", () => {
  it(`should not show if isVisible is set to false`, () => {
    const component = render(
      <TextSimplifier
        state={"content"}
        isVisible={false}
        feedback={FeedbackOption.NoFeedback}
        onEvent={jest.fn()}
        top={100}
        left={100}
        width={400}
      />,
    );
    expect(component.queryByTestId("text-simplifier")).not.toBeVisible();
  });

  it(`should show the loading state`, () => {
    const component = render(
      <TextSimplifier
        state={"loading"}
        isVisible={true}
        feedback={FeedbackOption.NoFeedback}
        onEvent={jest.fn()}
        top={100}
        left={100}
        width={400}
      />,
    );
    expect(component.getByTestId("loading-state")).toBeInTheDocument();
  });

  it(`should show the main content state`, () => {
    const component = render(
      <TextSimplifier
        state={"content"}
        isVisible={true}
        feedback={FeedbackOption.NoFeedback}
        onEvent={jest.fn()}
        top={100}
        left={100}
        width={400}
        simplifiedText={"Test Case"}
      />,
    );
    expect(component.getByTestId("content-state")).toBeInTheDocument();
  });

  it(`should show the feedback state when clicking thumbs-down`, () => {
    const component = render(
      <TextSimplifier
        state={"feedback"}
        isVisible={true}
        feedback={FeedbackOption.ThumbsDown}
        onEvent={jest.fn()}
        top={100}
        left={100}
        width={400}
        simplifiedText={"Test Case"}
      />,
    );
    expect(component.getByTestId("feedback-state")).toBeInTheDocument();
  });

  it(`should show the error state`, () => {
    const component = render(
      <TextSimplifier
        state={"error"}
        isVisible={true}
        feedback={FeedbackOption.NoFeedback}
        onEvent={jest.fn()}
        top={100}
        left={100}
        width={400}
        simplifiedText={"Test Case"}
      />,
    );
    expect(component.getByRole("alert")).toBeInTheDocument();
  });
});
