import { h, JSX, VNode } from "preact";
import styles from "./style.scss";

import { useStylesheet } from "~/hooks/useStylesheet";
import { TextSimplifierSkeleton } from "~/components/text-simplifier/components/skeleton";
import { TextSimplifierHeader } from "~/components/text-simplifier/components/header";
import { TextSimplifierFeedback } from "~/components/text-simplifier/components/feedback";
import { TextSimplifierContent } from "~/components/text-simplifier/components/content";
import { TextSimplifierError } from "~/components/text-simplifier/components/error";
import { useTranslation } from "~/hooks/useTranslation";
import defaultDictionary from "~/components/text-simplifier/locale/en.json";
import { TextSimplifierEventData, TextSimplifierEventType } from "./types";
import { TextSimplifierErrorType } from "~/components/text-simplifier/components/error/types";

export { TextSimplifierEventData, TextSimplifierEventType, TextSimplifierErrorType };

export enum FeedbackOption {
  ThumbsUp = "ThumbsUp",
  ThumbsDown = "ThumbsDown",
  NoFeedback = "NoFeedback",
}

export type TextSimplifierState = "loading" | "content" | "feedback" | "error";

export interface TextSimplifierProps {
  isVisible: boolean;
  leadColor?: string;
  state: TextSimplifierState;
  simplifiedText?: string;
  top: number;
  left: number;
  width: number;
  onEvent: (event: TextSimplifierEventData) => void;
  feedback: FeedbackOption;
  errorType?: TextSimplifierErrorType;
}

export function TextSimplifier({
  isVisible,
  leadColor = "#1136EF8",
  state,
  top,
  left,
  width,
  simplifiedText,
  onEvent,
  feedback,
  errorType,
}: TextSimplifierProps): VNode {
  useStylesheet(styles, { "lead-color": leadColor });
  const { direction } = useTranslation(defaultDictionary);
  let content: JSX.Element;

  switch (state) {
    case "loading":
      content = <TextSimplifierSkeleton />;
      break;
    case "content":
      content = (
        <TextSimplifierContent
          leadColor={leadColor}
          simplifiedText={simplifiedText}
          feedback={feedback}
          onEvent={onEvent}
        />
      );
      break;
    case "feedback":
      content = <TextSimplifierFeedback onEvent={onEvent} leadColor={leadColor} />;
      break;
    case "error":
      content = <TextSimplifierError errorType={errorType} />;
      break;
  }

  return (
    <div
      data-testid="text-simplifier"
      className="text-simplifier"
      dir={direction}
      style={{ top: `${top}px`, left: `${left}px`, width: `${width}px`, display: isVisible ? "" : "none" }}
    >
      <TextSimplifierHeader onEvent={onEvent} leadColor={leadColor} />
      {content}
    </div>
  );
}
