/** @jsx h */
import { h } from "preact";
import { FeedbackOption, TextSimplifier, TextSimplifierErrorType, TextSimplifierProps } from "./index";
import { Meta, StoryFn } from "@storybook/preact";
import { SupportedLanguageCode } from "~/types";

export default {
  title: "Example/TextSimplifier",
  component: TextSimplifier,
  args: {
    leadColor: "#136EF8",
  },
  argTypes: {
    language: { control: "select", options: Object.values(SupportedLanguageCode) },
    onEvent: { action: "onEvent" },
  },
} as Meta<typeof TextSimplifier>;

const TemplateTextSimplifier: StoryFn<typeof TextSimplifier> = (args) => <TextSimplifier {...(args as any)} />;
const DEFAULT_ARGUMENTS = {
  left: 100,
  top: 200,
  width: 600,
  state: "content",
  isVisible: true,
  feedback: FeedbackOption.NoFeedback,
  simplifiedText:
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam laoreet enim felis. Fusce iaculis felis quis arcu pharetra eleifend. Suspendisse sodales consectetur augue et cursus. Aliquam aliquam venenatis maximus.",
} as Partial<TextSimplifierProps>;

const DEFAULT_ARGUMENTS_RTL = {
  ...DEFAULT_ARGUMENTS,
  language: SupportedLanguageCode.HE,
  simplifiedText:
    "לורם איפסום דולור סיט אמט, קונסקטורר אדיפיסינג אלית גולר מונפרר סוברט לורם שבצק יהול, לכנוץ בעריר גק ליץ, להאמית קרהשק סכעיט דז מא, מנכם למטכין נשואי",
} as Partial<TextSimplifierProps>;

export const Loading = TemplateTextSimplifier.bind({});
Loading.args = { ...DEFAULT_ARGUMENTS, state: "loading" };

export const LoadingRTL = TemplateTextSimplifier.bind({});
LoadingRTL.args = { ...DEFAULT_ARGUMENTS_RTL, state: "loading" };

export const MainContent = TemplateTextSimplifier.bind({});
MainContent.args = DEFAULT_ARGUMENTS;

export const MainContentDifferentColor = TemplateTextSimplifier.bind({});
MainContentDifferentColor.args = { ...DEFAULT_ARGUMENTS, leadColor: "#c42525" };

export const MainContentRTL = TemplateTextSimplifier.bind({});
MainContentRTL.args = DEFAULT_ARGUMENTS_RTL;

export const ThumbsUpPressed = TemplateTextSimplifier.bind({});
ThumbsUpPressed.args = { ...DEFAULT_ARGUMENTS, feedback: FeedbackOption.ThumbsUp };

export const ThumbsDownPressedDifferentColor = TemplateTextSimplifier.bind({});
ThumbsDownPressedDifferentColor.args = {
  ...DEFAULT_ARGUMENTS,
  leadColor: "#c42525",
  state: "feedback",
  feedback: FeedbackOption.ThumbsDown,
};

export const ThumbsDownPressedRTL = TemplateTextSimplifier.bind({});
ThumbsDownPressedRTL.args = { ...DEFAULT_ARGUMENTS_RTL, state: "feedback", feedback: FeedbackOption.ThumbsDown };

export const ShortWidth = TemplateTextSimplifier.bind({});
ShortWidth.args = { ...DEFAULT_ARGUMENTS, width: 500 };

export const ErrorGeneral = TemplateTextSimplifier.bind({});
ErrorGeneral.args = { ...DEFAULT_ARGUMENTS, state: "error", errorType: TextSimplifierErrorType.GENERAL };

export const ErrorLimit = TemplateTextSimplifier.bind({});
ErrorLimit.args = { ...DEFAULT_ARGUMENTS, state: "error", errorType: TextSimplifierErrorType.LIMIT };

export const ErrorRTL = TemplateTextSimplifier.bind({});
ErrorRTL.args = { ...DEFAULT_ARGUMENTS_RTL, state: "error" };

export const NotVisible = TemplateTextSimplifier.bind({});
NotVisible.args = { ...DEFAULT_ARGUMENTS, isVisible: false };
